# SkillSwap — Peer-to-Peer Skill Exchange Platform

A Java desktop application where university students exchange skills without money.
Teach Python → Learn Graphic Design. Earn credits for every session you teach.

---

## Quick Start

### Prerequisites
- Java 17+ (JDK installed, `java` on PATH)
- Maven 3.8+ (or use the bundled JAR directly)

### Run the Application

**Option A — Run the fat JAR directly (no Maven needed):**
```
java -jar target/skillswap-1.0.0.jar
```

**Option B — Build and run from source:**
```
mvn package -DskipTests
java -jar target/skillswap-1.0.0.jar
```

The SQLite database (`skillswap.db`) is created automatically on first run.  
Demo data (10 students, sessions, feedback) is seeded on the first launch.

---

## Demo Login Credentials

| Role    | Email              | Password    |
|---------|--------------------|-------------|
| Student | aarav@uni.edu      | password123 |
| Student | priya@uni.edu      | password123 |
| Student | rahul@uni.edu      | password123 |
| Student | sneha@uni.edu      | password123 |
| Student | vikram@uni.edu     | password123 |
| Student | ananya@uni.edu     | password123 |
| Student | karan@uni.edu      | password123 |
| Student | divya@uni.edu      | password123 |
| Student | arjun@uni.edu      | password123 |
| Admin   | admin@uni.edu      | admin123    |

---

## Run Tests

```
mvn test
```

All 37 tests run against a temporary file-based SQLite DB (`target/test-skillswap.db`).  
The real `skillswap.db` is never touched by tests.

---

## Project Structure

```
src/main/java/skillswap/
├── Main.java                  — Entry point
├── model/                     — OOP model classes
│   ├── User.java              — Abstract class (Encapsulation, Abstraction)
│   ├── Student.java           — Extends User (Inheritance, Overriding)
│   ├── Administrator.java     — Extends User (Inheritance, Overriding)
│   ├── SessionBooking.java    — Implements Rateable + Cancellable (Interfaces)
│   ├── BookingStatus.java     — Enum with canTransitionTo() logic
│   ├── Skill.java, SkillListing.java, Feedback.java
│   ├── CreditTransaction.java, MatchResult.java
│   ├── Rateable.java          — Interface
│   └── Cancellable.java       — Interface
├── dao/                       — Database Access (PreparedStatements only)
│   ├── UserDAO.java
│   ├── SkillDAO.java
│   ├── BookingDAO.java
│   ├── CreditDAO.java
│   └── FeedbackDAO.java
├── service/                   — Business Logic
│   ├── AuthService.java       — BCrypt hashing, DuplicateUserException
│   ├── MatchingService.java   — Method Overloading (3 findMatches() overloads)
│   ├── BookingService.java    — Status transitions, conflict detection
│   ├── CreditService.java     — Idempotent credit awarding
│   ├── FeedbackService.java   — Rating validation
│   └── UserService.java
├── ui/
│   ├── MainFrame.java         — Main window (CardLayout, SidebarNav)
│   ├── components/            — Reusable UI components
│   │   ├── UIConstants.java, ThemeManager.java
│   │   ├── RoundedPanel.java, StyledButton.java, AvatarCircle.java
│   │   ├── StatusPill.java, StarRatingPanel.java, SkillChip.java
│   │   ├── Toast.java, CompatibilityBar.java, SidebarNav.java
│   │   ├── TopBar.java, FormField.java, PasswordField.java
│   │   ├── StatCard.java, LoadingOverlay.java, ConfirmDialog.java
│   └── screens/               — All application screens
│       ├── LoginScreen.java, RegisterScreen.java
│       ├── DashboardScreen.java, MySkillsScreen.java
│       ├── FindMatchesScreen.java, ProfileScreen.java
│       ├── BookingHistoryScreen.java, CreditsScreen.java
│       ├── FeedbackScreen.java, AdminScreen.java
└── util/
    ├── DatabaseManager.java   — Singleton, schema bootstrap
    ├── AppPreferences.java, ValidationUtils.java
    └── Custom Exceptions: DatabaseException, InvalidBookingException,
        DuplicateUserException, InvalidRatingException, DuplicateFeedbackException
```

---

## OOP Concepts Demonstrated

| Concept | Where |
|---------|-------|
| Abstract Class | `User.java` — `displayDashboard()` is abstract |
| Inheritance | `Student` and `Administrator` extend `User` |
| Method Overriding | `displayDashboard()` in Student vs Administrator |
| Interfaces | `Rateable`, `Cancellable` implemented by `SessionBooking` |
| Encapsulation | Private fields + validated setters in all model classes |
| Method Overloading | `MatchingService.findMatches()` — 3 overloads |
| Polymorphism | `User` reference holds Student or Administrator at runtime |
| Enum | `BookingStatus` with `canTransitionTo()` state machine |
| Collections | `ArrayList`, `HashMap` in MatchingService and Student |
| Custom Exceptions | 5 custom exception classes with try-catch-finally |
| Composition | `SessionBooking` HAS-A `Skill`; services HAS-A DAOs |
| Singleton | `DatabaseManager` |

---

## Tech Stack

| Component | Library |
|-----------|---------|
| GUI | Java Swing + FlatLaf 3.4 |
| Layout | MigLayout 5.3 |
| Database | SQLite via sqlite-jdbc 3.45 |
| Password hashing | jBCrypt 0.4 (BCrypt) |
| Icons/Emoji | Unicode emoji (built-in) |
| Testing | JUnit 5.10 |
| Build | Maven 3.9 + Shade plugin (fat JAR) |
