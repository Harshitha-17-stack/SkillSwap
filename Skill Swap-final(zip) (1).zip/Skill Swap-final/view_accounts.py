import sqlite3
from pathlib import Path

db_path = Path("skillswap.db")

if not db_path.exists():
    print("ERROR: skillswap.db not found!")
    print("Check that you are in the correct project folder.")
    exit()

conn = sqlite3.connect(
    f"file:{db_path.resolve().as_posix()}?mode=ro",
    uri=True
)

cursor = conn.cursor()

cursor.execute("""
    SELECT user_id, name, email, role
    FROM users
    ORDER BY user_id
""")

accounts = cursor.fetchall()

print("\n===== SKILLSWAP ACCOUNTS =====")
print("Total Registered Accounts:", len(accounts))

for user in accounts:
    print("-------------------------")
    print("User ID:", user[0])
    print("Name:", user[1])
    print("Email:", user[2])
    print("Role:", user[3])

conn.close()
