package skillswap;

import org.junit.jupiter.api.*;
import skillswap.model.*;
import skillswap.service.*;
import skillswap.util.DuplicateUserException;
import skillswap.util.InvalidBookingException;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Tests for the credits system.
 *
 * Covers:
 *   ✓ 10 credits awarded to provider after completion
 *   ✓ Credits awarded exactly ONCE (idempotency)
 *   ✓ Cancelled session earns zero credits
 *   ✓ Requester (learner) receives no credits
 *   ✓ Balance reflects cumulative transactions
 */
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
class CreditsTest {

    private final AuthService    authService    = new AuthService();
    private final SkillService   skillService   = new SkillService();
    private final BookingService bookingService = new BookingService();
    private final CreditService  creditService  = new CreditService();

    private Student aarav;   // teacher / provider
    private Student priya;   // learner / requester
    private Skill   python;

    private static final LocalDate DATE = LocalDate.now().plusDays(3);
    private static final LocalTime TIME = LocalTime.of(14, 0);

    @BeforeEach
    void setUp() throws DuplicateUserException {
        TestDatabaseHelper.resetDatabase();
        aarav  = authService.register("Aarav", "aarav@c.edu", "pass123", "CS", 2, null);
        priya  = authService.register("Priya", "priya@c.edu", "pass123", "Design", 3, null);
        python = skillService.findOrCreateSkill("Python", "Programming");
    }

    // ----------------------------------------------------------------
    @Test
    @Order(1)
    @DisplayName("Provider earns exactly 10 credits after session is COMPLETED")
    void testProviderEarns10Credits() throws InvalidBookingException {
        SessionBooking booking = createAndCompleteBooking();

        creditService.awardCredits(booking.getBookingId());

        int balance = creditService.getBalance(aarav.getUserId());
        assertEquals(10, balance,
            "Provider should have exactly 10 credits after one completed session");
    }

    // ----------------------------------------------------------------
    @Test
    @Order(2)
    @DisplayName("Credits are awarded exactly ONCE — idempotent awardCredits()")
    void testCreditsAwardedOnlyOnce() throws InvalidBookingException {
        SessionBooking booking = createAndCompleteBooking();

        // Call awardCredits() TWICE — second call must be a no-op
        creditService.awardCredits(booking.getBookingId());
        creditService.awardCredits(booking.getBookingId());   // <-- must not double-award

        int balance = creditService.getBalance(aarav.getUserId());
        assertEquals(10, balance,
            "Calling awardCredits() twice must NOT double the credits — idempotency required");

        List<skillswap.model.CreditTransaction> txList =
            creditService.getTransactionHistory(aarav.getUserId());
        assertEquals(1, txList.size(),
            "Exactly one transaction record should exist in the DB");
    }

    // ----------------------------------------------------------------
    @Test
    @Order(3)
    @DisplayName("Cannot award credits for a non-COMPLETED (REQUESTED) session")
    void testCannotAwardForNonCompleted() throws InvalidBookingException {
        // Create booking but do NOT complete it
        SessionBooking booking = bookingService.createBooking(
            priya.getUserId(), aarav.getUserId(),
            python, DATE, TIME, 60);

        assertThrows(InvalidBookingException.class, () ->
            creditService.awardCredits(booking.getBookingId()),
            "Should throw InvalidBookingException for a REQUESTED booking");
    }

    // ----------------------------------------------------------------
    @Test
    @Order(4)
    @DisplayName("Cancelled session earns zero credits")
    void testCancelledSessionEarnsNoCredits() throws InvalidBookingException {
        SessionBooking booking = bookingService.createBooking(
            priya.getUserId(), aarav.getUserId(),
            python, DATE, TIME, 60);

        bookingService.cancelBooking(booking.getBookingId(), "Schedule conflict");

        // Trying to award credits should throw (not COMPLETED)
        assertThrows(InvalidBookingException.class, () ->
            creditService.awardCredits(booking.getBookingId()),
            "Cancelled sessions must not earn credits");

        assertEquals(0, creditService.getBalance(aarav.getUserId()),
            "Provider balance should remain 0 after a cancelled session");
    }

    // ----------------------------------------------------------------
    @Test
    @Order(5)
    @DisplayName("Requester (learner) receives no credits — only provider earns")
    void testLearnerEarnsNoCredits() throws InvalidBookingException {
        SessionBooking booking = createAndCompleteBooking();
        creditService.awardCredits(booking.getBookingId());

        // Priya is the REQUESTER (learner) — she should get nothing
        int priyaBalance = creditService.getBalance(priya.getUserId());
        assertEquals(0, priyaBalance,
            "Learner (requester) should earn 0 credits — only the teacher earns");

        // Aarav is the PROVIDER (teacher) — he earns 10
        int aaravBalance = creditService.getBalance(aarav.getUserId());
        assertEquals(10, aaravBalance,
            "Teacher (provider) should earn 10 credits");
    }

    // ----------------------------------------------------------------
    @Test
    @Order(6)
    @DisplayName("Balance accumulates correctly across multiple sessions")
    void testBalanceAccumulates() throws InvalidBookingException {
        // First session
        SessionBooking b1 = createAndCompleteBooking(LocalTime.of(10, 0));
        creditService.awardCredits(b1.getBookingId());

        // Second session (different time, no conflict)
        SessionBooking b2 = createAndCompleteBooking(LocalTime.of(14, 0));
        creditService.awardCredits(b2.getBookingId());

        int balance = creditService.getBalance(aarav.getUserId());
        assertEquals(20, balance, "Two completed sessions = 20 credits");
    }

    // ----------------------------------------------------------------
    // Helpers
    // ----------------------------------------------------------------

    private SessionBooking createAndCompleteBooking() throws InvalidBookingException {
        return createAndCompleteBooking(TIME);
    }

    private SessionBooking createAndCompleteBooking(LocalTime time) throws InvalidBookingException {
        SessionBooking booking = bookingService.createBooking(
            priya.getUserId(), aarav.getUserId(), python, DATE, time, 60);
        bookingService.confirmBooking(booking.getBookingId());
        bookingService.completeBooking(booking.getBookingId());
        return booking;
    }
}
