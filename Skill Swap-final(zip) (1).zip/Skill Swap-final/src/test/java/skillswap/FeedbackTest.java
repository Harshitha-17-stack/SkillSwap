package skillswap;

import org.junit.jupiter.api.*;
import skillswap.model.*;
import skillswap.service.*;
import skillswap.util.DuplicateUserException;
import skillswap.util.InvalidBookingException;
import skillswap.util.InvalidRatingException;
import skillswap.util.DuplicateFeedbackException;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Tests for the feedback / rating system.
 *
 * Covers:
 *   ✓ Valid feedback (rating 1–5) is accepted for COMPLETED sessions
 *   ✓ Rating below 1 is rejected (InvalidRatingException)
 *   ✓ Rating above 5 is rejected (InvalidRatingException)
 *   ✓ Feedback on a CANCELLED session is rejected
 *   ✓ Feedback on a REQUESTED session is rejected
 *   ✓ Duplicate review throws DuplicateFeedbackException
 *   ✓ Average rating is computed correctly
 */
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
class FeedbackTest {

    private final AuthService     authService     = new AuthService();
    private final SkillService    skillService    = new SkillService();
    private final BookingService  bookingService  = new BookingService();
    private final FeedbackService feedbackService = new FeedbackService();

    private Student aarav;
    private Student priya;
    private Skill   python;

    private static final LocalDate DATE = LocalDate.now().plusDays(7);

    @BeforeEach
    void setUp() throws DuplicateUserException {
        TestDatabaseHelper.resetDatabase();
        aarav  = authService.register("Aarav", "aarav@f.edu", "pass123", "CS", 2, null);
        priya  = authService.register("Priya", "priya@f.edu", "pass123", "Design", 3, null);
        python = skillService.findOrCreateSkill("Python", "Programming");
    }

    // ----------------------------------------------------------------
    @Test
    @Order(1)
    @DisplayName("Valid rating (1–5) is accepted for a COMPLETED session")
    void testValidRatingAccepted() throws Exception {
        SessionBooking booking = createAndCompleteBooking(LocalTime.of(10, 0));

        // Priya (learner) rates Aarav (teacher) — rating 5
        Feedback fb = feedbackService.submitFeedback(
            booking.getBookingId(), priya.getUserId(), aarav.getUserId(),
            5, "Excellent teacher!");

        assertNotNull(fb);
        assertTrue(fb.getFeedbackId() > 0);
        assertEquals(5, fb.getRating());
        assertEquals("Excellent teacher!", fb.getComment());
    }

    // ----------------------------------------------------------------
    @Test
    @Order(2)
    @DisplayName("Rating of 0 (below 1) throws InvalidRatingException")
    void testRatingBelowRangeRejected() throws Exception {
        SessionBooking booking = createAndCompleteBooking(LocalTime.of(10, 0));

        assertThrows(InvalidRatingException.class, () ->
            feedbackService.submitFeedback(
                booking.getBookingId(), priya.getUserId(), aarav.getUserId(),
                0, "zero is invalid"),
            "Rating 0 should throw InvalidRatingException");
    }

    // ----------------------------------------------------------------
    @Test
    @Order(3)
    @DisplayName("Rating of 6 (above 5) throws InvalidRatingException")
    void testRatingAboveRangeRejected() throws Exception {
        SessionBooking booking = createAndCompleteBooking(LocalTime.of(10, 0));

        assertThrows(InvalidRatingException.class, () ->
            feedbackService.submitFeedback(
                booking.getBookingId(), priya.getUserId(), aarav.getUserId(),
                6, "six is invalid"),
            "Rating 6 should throw InvalidRatingException");
    }

    // ----------------------------------------------------------------
    @Test
    @Order(4)
    @DisplayName("Cannot submit feedback for a CANCELLED session")
    void testFeedbackOnCancelledSessionRejected() throws Exception {
        SessionBooking booking = bookingService.createBooking(
            priya.getUserId(), aarav.getUserId(),
            python, DATE, LocalTime.of(10, 0), 60);

        bookingService.cancelBooking(booking.getBookingId(), "Cancelled for test");

        // SessionBooking.submitRating() throws InvalidRatingException for non-COMPLETED
        assertThrows(InvalidRatingException.class, () ->
            feedbackService.submitFeedback(
                booking.getBookingId(), priya.getUserId(), aarav.getUserId(),
                4, "Should not work"),
            "Cannot rate a CANCELLED session");
    }

    // ----------------------------------------------------------------
    @Test
    @Order(5)
    @DisplayName("Cannot submit feedback for a REQUESTED (not completed) session")
    void testFeedbackOnRequestedSessionRejected() throws Exception {
        SessionBooking booking = bookingService.createBooking(
            priya.getUserId(), aarav.getUserId(),
            python, DATE, LocalTime.of(10, 0), 60);
        // Status is REQUESTED — not completed

        // SessionBooking.submitRating() throws InvalidRatingException for non-COMPLETED
        assertThrows(InvalidRatingException.class, () ->
            feedbackService.submitFeedback(
                booking.getBookingId(), priya.getUserId(), aarav.getUserId(),
                4, "Should not work"),
            "Cannot rate a REQUESTED session");
    }

    // ----------------------------------------------------------------
    @Test
    @Order(6)
    @DisplayName("Duplicate feedback throws DuplicateFeedbackException")
    void testDuplicateFeedbackRejected() throws Exception {
        SessionBooking booking = createAndCompleteBooking(LocalTime.of(10, 0));

        // First review — should succeed
        feedbackService.submitFeedback(
            booking.getBookingId(), priya.getUserId(), aarav.getUserId(),
            4, "Good session");

        // Second review for the same booking by same reviewer — must fail
        // OOP CONCEPT: DuplicateFeedbackException (custom exception)
        assertThrows(DuplicateFeedbackException.class, () ->
            feedbackService.submitFeedback(
                booking.getBookingId(), priya.getUserId(), aarav.getUserId(),
                5, "Changed my mind"),
            "A reviewer can only submit one review per booking (DuplicateFeedbackException)");
    }

    // ----------------------------------------------------------------
    @Test
    @Order(7)
    @DisplayName("Average rating is computed correctly from multiple reviews")
    void testAverageRatingCalculation() throws Exception {
        // Complete two sessions and rate both
        SessionBooking b1 = createAndCompleteBooking(LocalTime.of(10, 0));
        SessionBooking b2 = createAndCompleteBooking(LocalTime.of(14, 0));

        // Priya rates Aarav: 4 and 2 → average = 3.0
        feedbackService.submitFeedback(
            b1.getBookingId(), priya.getUserId(), aarav.getUserId(), 4, "Good");
        feedbackService.submitFeedback(
            b2.getBookingId(), priya.getUserId(), aarav.getUserId(), 2, "Needs improvement");

        double avg = feedbackService.getAverageRating(aarav.getUserId());
        assertEquals(3.0, avg, 0.01,
            "Average of ratings 4 and 2 should be 3.0");
    }

    // ----------------------------------------------------------------
    @Test
    @Order(8)
    @DisplayName("hasReviewed() returns false before and true after submitting")
    void testHasReviewedFlag() throws Exception {
        SessionBooking booking = createAndCompleteBooking(LocalTime.of(10, 0));

        assertFalse(feedbackService.hasReviewed(booking.getBookingId(), priya.getUserId()),
            "Should be false before review is submitted");

        feedbackService.submitFeedback(
            booking.getBookingId(), priya.getUserId(), aarav.getUserId(),
            5, "Great!");

        assertTrue(feedbackService.hasReviewed(booking.getBookingId(), priya.getUserId()),
            "Should be true after review is submitted");
    }

    // ----------------------------------------------------------------
    // Helpers
    // ----------------------------------------------------------------
    private SessionBooking createAndCompleteBooking(LocalTime time)
            throws InvalidBookingException {
        SessionBooking b = bookingService.createBooking(
            priya.getUserId(), aarav.getUserId(), python, DATE, time, 60);
        bookingService.confirmBooking(b.getBookingId());
        bookingService.completeBooking(b.getBookingId());
        return b;
    }
}
