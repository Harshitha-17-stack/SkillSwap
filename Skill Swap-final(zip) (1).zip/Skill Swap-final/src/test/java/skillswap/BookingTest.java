package skillswap;

import org.junit.jupiter.api.*;
import skillswap.model.*;
import skillswap.model.SkillListing.ListingType;
import skillswap.model.SkillListing.Proficiency;
import skillswap.service.*;
import skillswap.util.DuplicateUserException;
import skillswap.util.InvalidBookingException;

import java.time.LocalDate;
import java.time.LocalTime;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Tests for booking business rules.
 *
 * Covers:
 *   ✓ Valid booking creation succeeds
 *   ✓ Booking with a past date is rejected
 *   ✓ Self-booking is rejected
 *   ✓ Conflicting CONFIRMED sessions are rejected
 *   ✓ Status transitions: REQUESTED → CONFIRMED → COMPLETED
 *   ✓ COMPLETED booking cannot be cancelled (terminal state)
 *   ✓ Cancellation stores the reason
 */
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
class BookingTest {

    private final AuthService    authService    = new AuthService();
    private final SkillService   skillService   = new SkillService();
    private final BookingService bookingService = new BookingService();

    private Student aarav;
    private Student priya;
    private Skill   python;

    private static final LocalDate FUTURE_DATE = LocalDate.now().plusDays(5);
    private static final LocalTime SESSION_TIME = LocalTime.of(10, 0);

    @BeforeEach
    void setUp() throws DuplicateUserException {
        TestDatabaseHelper.resetDatabase();
        aarav  = authService.register("Aarav", "aarav@b.edu", "pass123", "CS", 2, null);
        priya  = authService.register("Priya", "priya@b.edu", "pass123", "Design", 3, null);
        python = skillService.findOrCreateSkill("Python", "Programming");
    }

    // ----------------------------------------------------------------
    @Test
    @Order(1)
    @DisplayName("Valid booking creation returns a booking with REQUESTED status")
    void testValidBookingCreation() throws InvalidBookingException {
        SessionBooking booking = bookingService.createBooking(
            priya.getUserId(), aarav.getUserId(),
            python, FUTURE_DATE, SESSION_TIME, 60);

        assertNotNull(booking);
        assertTrue(booking.getBookingId() > 0, "Should have a DB-assigned ID");
        assertEquals(BookingStatus.REQUESTED, booking.getStatus());
        assertEquals(aarav.getUserId(), booking.getProviderId());
        assertEquals(priya.getUserId(), booking.getRequesterId());
        assertEquals(60, booking.getDurationMinutes());
    }

    // ----------------------------------------------------------------
    @Test
    @Order(2)
    @DisplayName("Booking with a past date throws InvalidBookingException")
    void testPastDateRejected() {
        LocalDate yesterday = LocalDate.now().minusDays(1);

        assertThrows(InvalidBookingException.class, () ->
            bookingService.createBooking(
                priya.getUserId(), aarav.getUserId(),
                python, yesterday, SESSION_TIME, 60),
            "Past-date booking should throw InvalidBookingException");
    }

    // ----------------------------------------------------------------
    @Test
    @Order(3)
    @DisplayName("Self-booking (requester == provider) throws InvalidBookingException")
    void testSelfBookingRejected() {
        assertThrows(InvalidBookingException.class, () ->
            bookingService.createBooking(
                aarav.getUserId(), aarav.getUserId(),   // same user!
                python, FUTURE_DATE, SESSION_TIME, 60),
            "Self-booking should throw InvalidBookingException");
    }

    // ----------------------------------------------------------------
    @Test
    @Order(4)
    @DisplayName("Zero or negative duration throws InvalidBookingException")
    void testInvalidDurationRejected() {
        assertThrows(InvalidBookingException.class, () ->
            bookingService.createBooking(
                priya.getUserId(), aarav.getUserId(),
                python, FUTURE_DATE, SESSION_TIME, 0),
            "Zero duration should be rejected");

        assertThrows(InvalidBookingException.class, () ->
            bookingService.createBooking(
                priya.getUserId(), aarav.getUserId(),
                python, FUTURE_DATE, SESSION_TIME, -30),
            "Negative duration should be rejected");
    }

    // ----------------------------------------------------------------
    @Test
    @Order(5)
    @DisplayName("Scheduling conflict: overlapping CONFIRMED sessions rejected")
    void testConflictingSessionRejected() throws InvalidBookingException {
        // Create and CONFIRM booking 10:00–11:00
        SessionBooking first = bookingService.createBooking(
            priya.getUserId(), aarav.getUserId(),
            python, FUTURE_DATE, LocalTime.of(10, 0), 60);
        bookingService.confirmBooking(first.getBookingId());

        // Attempt overlapping 10:30–11:30 — should be rejected
        assertThrows(InvalidBookingException.class, () ->
            bookingService.createBooking(
                priya.getUserId(), aarav.getUserId(),
                python, FUTURE_DATE, LocalTime.of(10, 30), 60),
            "Overlapping confirmed session should throw InvalidBookingException");
    }

    // ----------------------------------------------------------------
    @Test
    @Order(6)
    @DisplayName("Non-overlapping sessions on the same day are both accepted")
    void testNonOverlappingSessionsAccepted() throws InvalidBookingException {
        // 10:00–11:00 → confirm
        SessionBooking first = bookingService.createBooking(
            priya.getUserId(), aarav.getUserId(),
            python, FUTURE_DATE, LocalTime.of(10, 0), 60);
        bookingService.confirmBooking(first.getBookingId());

        // 11:30–12:30 → no overlap — should succeed
        assertDoesNotThrow(() ->
            bookingService.createBooking(
                priya.getUserId(), aarav.getUserId(),
                python, FUTURE_DATE, LocalTime.of(11, 30), 60),
            "Non-overlapping sessions on the same day should both be accepted");
    }

    // ----------------------------------------------------------------
    @Test
    @Order(7)
    @DisplayName("Status transitions: REQUESTED → CONFIRMED → COMPLETED")
    void testStatusTransitions() throws InvalidBookingException {
        SessionBooking booking = bookingService.createBooking(
            priya.getUserId(), aarav.getUserId(),
            python, FUTURE_DATE, SESSION_TIME, 60);

        assertEquals(BookingStatus.REQUESTED, booking.getStatus());

        bookingService.confirmBooking(booking.getBookingId());
        SessionBooking confirmed = bookingService.getBookingById(booking.getBookingId());
        assertEquals(BookingStatus.CONFIRMED, confirmed.getStatus());

        bookingService.completeBooking(booking.getBookingId());
        SessionBooking completed = bookingService.getBookingById(booking.getBookingId());
        assertEquals(BookingStatus.COMPLETED, completed.getStatus());
    }

    // ----------------------------------------------------------------
    @Test
    @Order(8)
    @DisplayName("Cannot cancel a COMPLETED session (terminal state)")
    void testCannotCancelCompleted() throws InvalidBookingException {
        SessionBooking booking = bookingService.createBooking(
            priya.getUserId(), aarav.getUserId(),
            python, FUTURE_DATE, SESSION_TIME, 60);

        bookingService.confirmBooking(booking.getBookingId());
        bookingService.completeBooking(booking.getBookingId());

        // OOP CONCEPT: BookingStatus.canTransitionTo() rejects COMPLETED → CANCELLED
        assertThrows(InvalidBookingException.class, () ->
            bookingService.cancelBooking(booking.getBookingId(), "Changed my mind"),
            "Cannot cancel a COMPLETED session");
    }

    // ----------------------------------------------------------------
    @Test
    @Order(9)
    @DisplayName("Cancellation without a reason throws InvalidBookingException")
    void testCancelWithoutReasonRejected() throws InvalidBookingException {
        SessionBooking booking = bookingService.createBooking(
            priya.getUserId(), aarav.getUserId(),
            python, FUTURE_DATE, SESSION_TIME, 60);

        assertThrows(InvalidBookingException.class, () ->
            bookingService.cancelBooking(booking.getBookingId(), ""),
            "Cancelling without a reason should be rejected");

        assertThrows(InvalidBookingException.class, () ->
            bookingService.cancelBooking(booking.getBookingId(), null),
            "Cancelling with null reason should be rejected");
    }

    // ----------------------------------------------------------------
    @Test
    @Order(10)
    @DisplayName("Cancelled booking stores the cancel reason")
    void testCancelReasonStored() throws InvalidBookingException {
        SessionBooking booking = bookingService.createBooking(
            priya.getUserId(), aarav.getUserId(),
            python, FUTURE_DATE, SESSION_TIME, 60);

        bookingService.cancelBooking(booking.getBookingId(), "Schedule conflict");

        SessionBooking loaded = bookingService.getBookingById(booking.getBookingId());
        assertEquals(BookingStatus.CANCELLED, loaded.getStatus());
        assertEquals("Schedule conflict", loaded.getCancelReason());
    }
}
