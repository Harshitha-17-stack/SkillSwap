package skillswap;

import skillswap.util.DatabaseManager;

import java.sql.Statement;

/**
 * Resets the test database before each test method.
 * Truncates all tables with FK checks OFF, then resets auto-increment counters.
 */
public final class TestDatabaseHelper {

    private TestDatabaseHelper() {}

    public static void resetDatabase() {
        DatabaseManager db = DatabaseManager.getInstance();
        db.initializeSchema();   // CREATE TABLE IF NOT EXISTS — safe to call every time

        try (Statement stmt = db.getConnection().createStatement()) {
            stmt.execute("PRAGMA foreign_keys = OFF");
            stmt.execute("DELETE FROM feedback");
            stmt.execute("DELETE FROM credit_transactions");
            stmt.execute("DELETE FROM bookings");
            stmt.execute("DELETE FROM skill_listings");
            stmt.execute("DELETE FROM skills");
            stmt.execute("DELETE FROM users");
            // Reset AUTOINCREMENT counters so user_id always starts at 1 in each test
            stmt.execute("DELETE FROM sqlite_sequence WHERE name IN " +
                "('feedback','credit_transactions','bookings','skill_listings','skills','users')");
            stmt.execute("PRAGMA foreign_keys = ON");
        } catch (Exception e) {
            throw new RuntimeException("resetDatabase failed: " + e.getMessage(), e);
        }
    }
}
