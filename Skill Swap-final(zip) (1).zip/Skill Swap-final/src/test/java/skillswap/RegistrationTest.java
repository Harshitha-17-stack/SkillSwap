package skillswap;

import org.junit.jupiter.api.*;
import skillswap.model.Student;
import skillswap.service.AuthService;
import skillswap.util.DuplicateUserException;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Tests for user registration.
 *
 * Covers:
 *   ✓ Successful registration creates a student with correct fields
 *   ✓ Duplicate email throws DuplicateUserException
 *   ✓ Invalid email format is rejected
 *   ✓ Password too short is rejected
 *   ✓ Blank name is rejected
 */
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
class RegistrationTest {

    private final AuthService authService = new AuthService();

    @BeforeEach
    void setUp() {
        TestDatabaseHelper.resetDatabase();
    }

    // ----------------------------------------------------------------
    @Test
    @Order(1)
    @DisplayName("Successful registration returns Student with correct fields")
    void testSuccessfulRegistration() throws DuplicateUserException {
        Student student = authService.register(
            "Aarav Sharma", "aarav@test.edu", "password123",
            "Computer Science", 2, "I love Python");

        assertNotNull(student, "Returned Student should not be null");
        assertTrue(student.getUserId() > 0, "userId should be a positive DB-assigned integer");
        assertEquals("aarav@test.edu", student.getEmail());
        assertEquals("Aarav Sharma",   student.getName());
        assertEquals("Computer Science", student.getDepartment());
        assertEquals(2,  student.getYearOfStudy());
        assertEquals(0,  student.getCreditBalance(), "New students start with 0 credits");
        assertNotEquals("password123", student.getPasswordHash(),
            "Password must be stored as a BCrypt hash, never plain text");
        assertTrue(student.getPasswordHash().startsWith("$2"),
            "Hash should be a BCrypt hash starting with $2");
    }

    // ----------------------------------------------------------------
    @Test
    @Order(2)
    @DisplayName("Registering with a duplicate email throws DuplicateUserException")
    void testDuplicateEmailThrows() throws DuplicateUserException {
        // Register first time — should succeed
        authService.register("Priya Patel", "priya@test.edu",
            "password123", "Design", 3, null);

        // Register again with same email — should throw
        // OOP CONCEPT: Custom exception (DuplicateUserException) verified
        assertThrows(DuplicateUserException.class, () ->
            authService.register("Priya Clone", "priya@test.edu",
                "differentpass", "Design", 1, null),
            "A second registration with the same email should throw DuplicateUserException");
    }

    // ----------------------------------------------------------------
    @Test
    @Order(3)
    @DisplayName("Invalid email format is rejected with IllegalArgumentException")
    void testInvalidEmailRejected() {
        assertThrows(IllegalArgumentException.class, () ->
            authService.register("Bad User", "not-an-email",
                "password123", "CS", 1, null),
            "Malformed email should throw IllegalArgumentException");
    }

    // ----------------------------------------------------------------
    @Test
    @Order(4)
    @DisplayName("Password shorter than 6 characters is rejected")
    void testShortPasswordRejected() {
        assertThrows(IllegalArgumentException.class, () ->
            authService.register("Short Pass", "short@test.edu",
                "abc", "CS", 1, null),
            "Password under 6 chars should be rejected");
    }

    // ----------------------------------------------------------------
    @Test
    @Order(5)
    @DisplayName("Blank name is rejected with IllegalArgumentException")
    void testBlankNameRejected() {
        assertThrows(IllegalArgumentException.class, () ->
            authService.register("  ", "blank@test.edu",
                "password123", "CS", 1, null),
            "Blank/whitespace-only name should be rejected");
    }

    // ----------------------------------------------------------------
    @Test
    @Order(6)
    @DisplayName("Login succeeds after registration and returns the same user")
    void testLoginAfterRegistration() throws DuplicateUserException {
        authService.register("Rahul Verma", "rahul@test.edu",
            "mypassword", "Maths", 1, null);

        // Login should work
        var user = authService.login("rahul@test.edu", "mypassword");
        assertNotNull(user);
        assertEquals("Rahul Verma", user.getName());

        // Wrong password should fail
        assertThrows(IllegalArgumentException.class, () ->
            authService.login("rahul@test.edu", "wrongpassword"));
    }
}
