package skillswap;

import org.junit.jupiter.api.*;
import skillswap.model.*;
import skillswap.model.SkillListing.ListingType;
import skillswap.model.SkillListing.Proficiency;
import skillswap.service.AuthService;
import skillswap.service.MatchingService;
import skillswap.service.SkillService;
import skillswap.util.DuplicateUserException;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Tests for the matching algorithm.
 *
 * Covers:
 *   ✓ Mutual match detected as STRONG
 *   ✓ One-way match detected as PARTIAL
 *   ✓ No match when there's no skill overlap
 *   ✓ Skill-name filter (findMatches overload 2) works
 *   ✓ Skill + level filter (findMatches overload 3) works
 *   ✓ STRONG match has higher score than PARTIAL
 *   ✓ Cannot match with yourself
 */
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
class MatchingTest {

    private final AuthService    authService    = new AuthService();
    private final SkillService   skillService   = new SkillService();
    private final MatchingService matchingService = new MatchingService();

    private Student aarav;
    private Student priya;
    private Student divya;   // no overlap with aarav

    @BeforeEach
    void setUp() throws DuplicateUserException {
        TestDatabaseHelper.resetDatabase();

        // Create two students with a MUTUAL match:
        // Aarav offers Python, wants Graphic Design
        // Priya offers Graphic Design, wants Python
        aarav = authService.register("Aarav Sharma", "aarav@test.edu",
            "password", "CS", 2, null);
        priya = authService.register("Priya Patel", "priya@test.edu",
            "password", "Design", 3, null);
        // Divya offers French, wants Python  → PARTIAL (she wants Python, but Aarav won't find her
        //                                       as offering what he wants)
        // Actually for Aarav's perspective: Divya offers French (Aarav doesn't want French),
        // so there will be no match from Aarav's side to Divya.
        divya = authService.register("Divya Nair", "divya@test.edu",
            "password", "Languages", 2, null);

        // Seed skills
        Skill python   = skillService.findOrCreateSkill("Python", "Programming");
        Skill design   = skillService.findOrCreateSkill("Graphic Design", "Design");
        Skill french   = skillService.findOrCreateSkill("French", "Languages");

        // Aarav: offers Python (ADVANCED), wants Graphic Design
        skillService.addListing(aarav.getUserId(), python, ListingType.OFFER,
            Proficiency.ADVANCED, "Advanced Python");
        skillService.addListing(aarav.getUserId(), design, ListingType.WANT,
            Proficiency.BEGINNER, "Want to learn design");

        // Priya: offers Graphic Design (ADVANCED), wants Python
        skillService.addListing(priya.getUserId(), design, ListingType.OFFER,
            Proficiency.ADVANCED, "Professional designer");
        skillService.addListing(priya.getUserId(), python, ListingType.WANT,
            Proficiency.BEGINNER, "Want to learn Python");

        // Divya: offers French (ADVANCED), wants Python
        skillService.addListing(divya.getUserId(), french, ListingType.OFFER,
            Proficiency.ADVANCED, "Native French speaker");
        skillService.addListing(divya.getUserId(), python, ListingType.WANT,
            Proficiency.BEGINNER, "Learning Python");
    }

    // ----------------------------------------------------------------
    @Test
    @Order(1)
    @DisplayName("Mutual skill exchange is detected as STRONG match")
    void testMutualMatchIsStrong() {
        // OOP CONCEPT: findMatches(int) — Overload 1
        List<MatchResult> results = matchingService.findMatches(aarav.getUserId());

        // Should find Priya as a STRONG match (mutual Python ↔ Graphic Design)
        MatchResult priyaMatch = results.stream()
            .filter(r -> r.getMatchedStudent().getUserId() == priya.getUserId())
            .findFirst()
            .orElse(null);

        assertNotNull(priyaMatch, "Priya should appear in Aarav's matches");
        assertEquals(MatchResult.MatchType.STRONG, priyaMatch.getMatchType(),
            "Python ↔ Graphic Design should be a STRONG (mutual) match");
        assertTrue(priyaMatch.getCompatibilityScore() >= 90,
            "Strong mutual match should have score ≥ 90");
    }

    // ----------------------------------------------------------------
    @Test
    @Order(2)
    @DisplayName("One-way skill match is detected as PARTIAL")
    void testOneWayMatchIsPartial() {
        // From PRIYA's perspective: Divya wants Python (which Priya doesn't offer),
        // and Divya offers French (which Priya doesn't want) — no match.
        // From DIVYA's perspective: Aarav offers Python (Divya wants it) → PARTIAL
        // (Aarav doesn't want French, so it's one-way)
        List<MatchResult> results = matchingService.findMatches(divya.getUserId());

        MatchResult aaravMatch = results.stream()
            .filter(r -> r.getMatchedStudent().getUserId() == aarav.getUserId())
            .findFirst()
            .orElse(null);

        assertNotNull(aaravMatch, "Aarav should appear in Divya's matches (he teaches Python)");
        assertEquals(MatchResult.MatchType.PARTIAL, aaravMatch.getMatchType(),
            "Since Aarav doesn't want French, this should be PARTIAL");
        assertTrue(aaravMatch.getCompatibilityScore() < 90,
            "Partial match score should be below 90");
    }

    // ----------------------------------------------------------------
    @Test
    @Order(3)
    @DisplayName("No match returned when there is no skill overlap")
    void testNoMatchWhenNoOverlap() throws DuplicateUserException {
        // Create a student who offers guitar and wants music theory — no overlap with anyone
        Student sneha = authService.register("Sneha Gupta", "sneha@test.edu",
            "password", "Music", 3, null);
        Skill guitar = skillService.findOrCreateSkill("Guitar", "Music");
        skillService.addListing(sneha.getUserId(), guitar,
            ListingType.OFFER, Proficiency.ADVANCED, "Expert guitarist");
        // Sneha wants Calculus — nobody offers it
        Skill calculus = skillService.findOrCreateSkill("Calculus", "Mathematics");
        skillService.addListing(sneha.getUserId(), calculus,
            ListingType.WANT, Proficiency.BEGINNER, "Need calculus help");

        List<MatchResult> results = matchingService.findMatches(sneha.getUserId());
        assertTrue(results.isEmpty(),
            "No matches should be returned when there is no skill overlap");
    }

    // ----------------------------------------------------------------
    @Test
    @Order(4)
    @DisplayName("findMatches(userId, skillName) filters by skill name — OOP Overload 2")
    void testFindMatchesWithSkillNameFilter() {
        // OOP CONCEPT: findMatches(int, String) — Overload 2
        List<MatchResult> allResults      = matchingService.findMatches(aarav.getUserId());
        List<MatchResult> filteredResults = matchingService.findMatches(
            aarav.getUserId(), "Graphic Design");

        // Filtered should be subset of all
        assertFalse(filteredResults.isEmpty(), "Filter for 'Graphic Design' should return results");
        assertTrue(filteredResults.stream()
            .allMatch(r -> r.getTheyOffer().toLowerCase().contains("graphic design")),
            "All filtered results should involve Graphic Design");
    }

    // ----------------------------------------------------------------
    @Test
    @Order(5)
    @DisplayName("findMatches(userId, skill, level) filters by skill + level — OOP Overload 3")
    void testFindMatchesWithSkillAndLevelFilter() {
        // OOP CONCEPT: findMatches(int, String, String) — Overload 3
        List<MatchResult> advanced = matchingService.findMatches(
            aarav.getUserId(), "Graphic Design", "ADVANCED");
        List<MatchResult> beginner = matchingService.findMatches(
            aarav.getUserId(), "Graphic Design", "BEGINNER");

        // Priya offers Graphic Design at ADVANCED → appears in advanced filter
        assertFalse(advanced.isEmpty(), "ADVANCED filter should find Priya's Graphic Design");
        // No one offers Graphic Design at BEGINNER
        assertTrue(beginner.isEmpty(), "BEGINNER filter should return no results here");
    }

    // ----------------------------------------------------------------
    @Test
    @Order(6)
    @DisplayName("STRONG match has higher compatibility score than PARTIAL match")
    void testStrongScoreHigherThanPartial() {
        List<MatchResult> aaravResults = matchingService.findMatches(aarav.getUserId());
        List<MatchResult> divyaResults = matchingService.findMatches(divya.getUserId());

        int strongScore = aaravResults.stream()
            .filter(r -> r.getMatchType() == MatchResult.MatchType.STRONG)
            .mapToInt(MatchResult::getCompatibilityScore).max().orElse(0);

        int partialScore = divyaResults.stream()
            .filter(r -> r.getMatchType() == MatchResult.MatchType.PARTIAL)
            .mapToInt(MatchResult::getCompatibilityScore).max().orElse(0);

        assertTrue(strongScore > partialScore,
            "STRONG match score (" + strongScore + ") should exceed PARTIAL score (" + partialScore + ")");
    }

    // ----------------------------------------------------------------
    @Test
    @Order(7)
    @DisplayName("A student does not appear as their own match")
    void testNoSelfMatch() {
        List<MatchResult> results = matchingService.findMatches(aarav.getUserId());
        results.forEach(r ->
            assertNotEquals(aarav.getUserId(), r.getMatchedStudent().getUserId(),
                "A student must never appear as their own match"));
    }
}
