-- ============================================================
-- SkillSwap Database Schema
-- SQLite — auto-created on first application run
-- ============================================================

PRAGMA foreign_keys = ON;

-- -------------------------------------------------------
-- users
-- Abstract User hierarchy: Student / Administrator
-- -------------------------------------------------------
CREATE TABLE IF NOT EXISTS users (
    user_id      INTEGER PRIMARY KEY AUTOINCREMENT,
    name         TEXT    NOT NULL,
    email        TEXT    NOT NULL UNIQUE,
    password_hash TEXT   NOT NULL,          -- BCrypt hash, never plain text
    role         TEXT    NOT NULL CHECK(role IN ('STUDENT','ADMIN')),
    department   TEXT,
    year_of_study INTEGER,
    bio          TEXT,
    credit_balance INTEGER NOT NULL DEFAULT 0,
    access_level  INTEGER DEFAULT 1,        -- Admins only
    created_at   DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- -------------------------------------------------------
-- skills  (master catalogue)
-- -------------------------------------------------------
CREATE TABLE IF NOT EXISTS skills (
    skill_id    INTEGER PRIMARY KEY AUTOINCREMENT,
    name        TEXT    NOT NULL UNIQUE,
    category    TEXT    NOT NULL,           -- e.g. Programming, Design, Music
    created_at  DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- -------------------------------------------------------
-- skill_listings  (a student offers or wants a skill)
-- -------------------------------------------------------
CREATE TABLE IF NOT EXISTS skill_listings (
    listing_id   INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id      INTEGER NOT NULL REFERENCES users(user_id) ON DELETE CASCADE,
    skill_id     INTEGER NOT NULL REFERENCES skills(skill_id) ON DELETE CASCADE,
    listing_type TEXT    NOT NULL CHECK(listing_type IN ('OFFER','WANT')),
    proficiency  TEXT    NOT NULL CHECK(proficiency IN ('BEGINNER','INTERMEDIATE','ADVANCED')),
    description  TEXT,
    created_at   DATETIME DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(user_id, skill_id, listing_type)   -- prevent duplicate offer/want entries
);

-- -------------------------------------------------------
-- bookings
-- -------------------------------------------------------
CREATE TABLE IF NOT EXISTS bookings (
    booking_id      INTEGER PRIMARY KEY AUTOINCREMENT,
    requester_id    INTEGER NOT NULL REFERENCES users(user_id),
    provider_id     INTEGER NOT NULL REFERENCES users(user_id),
    skill_id        INTEGER NOT NULL REFERENCES skills(skill_id),
    session_date    TEXT    NOT NULL,       -- ISO-8601 date:  YYYY-MM-DD
    session_time    TEXT    NOT NULL,       -- HH:MM
    duration_minutes INTEGER NOT NULL CHECK(duration_minutes > 0),
    status          TEXT    NOT NULL DEFAULT 'REQUESTED'
                    CHECK(status IN ('REQUESTED','CONFIRMED','COMPLETED','CANCELLED')),
    cancel_reason   TEXT,
    created_at      DATETIME DEFAULT CURRENT_TIMESTAMP,
    CHECK(requester_id != provider_id)      -- cannot book yourself
);

-- -------------------------------------------------------
-- credit_transactions
-- UNIQUE on booking_id prevents double-awarding credits
-- -------------------------------------------------------
CREATE TABLE IF NOT EXISTS credit_transactions (
    tx_id       INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id     INTEGER NOT NULL REFERENCES users(user_id),
    booking_id  INTEGER UNIQUE REFERENCES bookings(booking_id),  -- one award per session
    amount      INTEGER NOT NULL,
    reason      TEXT    NOT NULL,
    created_at  DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- -------------------------------------------------------
-- feedback
-- UNIQUE(booking_id, reviewer_id) prevents duplicate reviews
-- -------------------------------------------------------
CREATE TABLE IF NOT EXISTS feedback (
    feedback_id  INTEGER PRIMARY KEY AUTOINCREMENT,
    booking_id   INTEGER NOT NULL REFERENCES bookings(booking_id),
    reviewer_id  INTEGER NOT NULL REFERENCES users(user_id),
    reviewee_id  INTEGER NOT NULL REFERENCES users(user_id),
    rating       INTEGER NOT NULL CHECK(rating BETWEEN 1 AND 5),
    comment      TEXT,
    created_at   DATETIME DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(booking_id, reviewer_id)          -- one review per reviewer per booking
);
