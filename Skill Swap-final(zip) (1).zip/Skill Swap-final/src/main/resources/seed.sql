-- ============================================================
-- SkillSwap Seed Data — Demo presentation data
-- Passwords are all BCrypt hashes of "password123"
-- Admin password hash is for "admin123"
-- ============================================================

-- Clear existing data (safe for demo reset)
DELETE FROM feedback;
DELETE FROM credit_transactions;
DELETE FROM bookings;
DELETE FROM skill_listings;
DELETE FROM skills;
DELETE FROM users;

-- Reset auto-increment counters
DELETE FROM sqlite_sequence;

-- -------------------------------------------------------
-- USERS  (9 students + 1 admin)
-- All student passwords: password123
-- Admin password:        admin123
-- -------------------------------------------------------
INSERT INTO users (name, email, password_hash, role, department, year_of_study, bio, credit_balance)
VALUES
  ('Aarav Sharma',    'aarav@uni.edu',   '$2a$10$CIK32VXjN4IOUB/WkkZTBe4LYNChQNu.BnHDZoCDRhlgrXA/5hsIy', 'STUDENT', 'Computer Science',    2, 'Passionate about Python and machine learning.',  20),
  ('Priya Patel',     'priya@uni.edu',   '$2a$10$CIK32VXjN4IOUB/WkkZTBe4LYNChQNu.BnHDZoCDRhlgrXA/5hsIy', 'STUDENT', 'Design',               3, 'Graphic designer who loves Figma and Photoshop.', 10),
  ('Rahul Verma',     'rahul@uni.edu',   '$2a$10$CIK32VXjN4IOUB/WkkZTBe4LYNChQNu.BnHDZoCDRhlgrXA/5hsIy', 'STUDENT', 'Computer Science',    1, 'First-year learning web development.',           0),
  ('Sneha Gupta',     'sneha@uni.edu',   '$2a$10$CIK32VXjN4IOUB/WkkZTBe4LYNChQNu.BnHDZoCDRhlgrXA/5hsIy', 'STUDENT', 'Music',               3, 'Guitar teacher and music theory enthusiast.',    30),
  ('Vikram Singh',    'vikram@uni.edu',  '$2a$10$CIK32VXjN4IOUB/WkkZTBe4LYNChQNu.BnHDZoCDRhlgrXA/5hsIy', 'STUDENT', 'Mathematics',         4, 'Math tutor specialising in calculus and stats.', 50),
  ('Ananya Reddy',    'ananya@uni.edu',  '$2a$10$CIK32VXjN4IOUB/WkkZTBe4LYNChQNu.BnHDZoCDRhlgrXA/5hsIy', 'STUDENT', 'Photography',         2, 'Photography and video editing are my passions.', 10),
  ('Karan Mehta',     'karan@uni.edu',   '$2a$10$CIK32VXjN4IOUB/WkkZTBe4LYNChQNu.BnHDZoCDRhlgrXA/5hsIy', 'STUDENT', 'Computer Science',    3, 'Full-stack developer learning graphic design.',  20),
  ('Divya Nair',      'divya@uni.edu',   '$2a$10$CIK32VXjN4IOUB/WkkZTBe4LYNChQNu.BnHDZoCDRhlgrXA/5hsIy', 'STUDENT', 'Languages',           2, 'French and Spanish teacher, wants to learn coding.', 0),
  ('Arjun Das',       'arjun@uni.edu',   '$2a$10$CIK32VXjN4IOUB/WkkZTBe4LYNChQNu.BnHDZoCDRhlgrXA/5hsIy', 'STUDENT', 'Business',            4, 'Excel and finance wizard.',                      40),
  ('Admin User',      'admin@uni.edu',   '$2a$10$.YotJFWOqVx4QgvQ2Yt5pu93Ucet/nQar4HSerG6iGIGT5JoYiQzC', 'ADMIN',   'Administration',      0, NULL, 0);

-- Update admin access_level
UPDATE users SET access_level = 5 WHERE role = 'ADMIN';

-- -------------------------------------------------------
-- SKILLS (master catalogue)
-- -------------------------------------------------------
INSERT INTO skills (name, category) VALUES
  ('Python',            'Programming'),
  ('JavaScript',        'Programming'),
  ('Java',              'Programming'),
  ('HTML/CSS',          'Programming'),
  ('Graphic Design',    'Design'),
  ('Photoshop',         'Design'),
  ('Figma',             'Design'),
  ('Guitar',            'Music'),
  ('Music Theory',      'Music'),
  ('Photography',       'Arts'),
  ('Video Editing',     'Arts'),
  ('Calculus',          'Mathematics'),
  ('Statistics',        'Mathematics'),
  ('French',            'Languages'),
  ('Spanish',           'Languages'),
  ('Excel',             'Business'),
  ('Public Speaking',   'Soft Skills');

-- -------------------------------------------------------
-- SKILL LISTINGS
-- -------------------------------------------------------
-- Aarav (user_id=1): offers Python, wants Graphic Design  → mutual match with Priya
INSERT INTO skill_listings (user_id, skill_id, listing_type, proficiency, description) VALUES
  (1, 1,  'OFFER', 'ADVANCED',     'I can teach Python from basics to OOP and data science.'),
  (1, 5,  'WANT',  'BEGINNER',     'I want to learn graphic design principles.'),
  (1, 12, 'WANT',  'INTERMEDIATE', 'Brushing up on calculus.');

-- Priya (user_id=2): offers Graphic Design + Photoshop + Figma, wants Python
INSERT INTO skill_listings (user_id, skill_id, listing_type, proficiency, description) VALUES
  (2, 5,  'OFFER', 'ADVANCED',     'Professional-level graphic design and branding.'),
  (2, 6,  'OFFER', 'ADVANCED',     'Photoshop photo editing and compositing.'),
  (2, 7,  'OFFER', 'INTERMEDIATE', 'Figma for UI prototyping.'),
  (2, 1,  'WANT',  'BEGINNER',     'Want to automate my design workflow with Python.');

-- Rahul (user_id=3): offers HTML/CSS, wants JavaScript + Python
INSERT INTO skill_listings (user_id, skill_id, listing_type, proficiency, description) VALUES
  (3, 4,  'OFFER', 'INTERMEDIATE', 'Good at building responsive HTML/CSS layouts.'),
  (3, 2,  'WANT',  'BEGINNER',     'Learning JavaScript for front-end interaction.'),
  (3, 1,  'WANT',  'BEGINNER',     'Interested in Python for scripting.');

-- Sneha (user_id=4): offers Guitar + Music Theory, wants Photography
INSERT INTO skill_listings (user_id, skill_id, listing_type, proficiency, description) VALUES
  (4, 8,  'OFFER', 'ADVANCED',     'Acoustic and electric guitar, 6 years experience.'),
  (4, 9,  'OFFER', 'INTERMEDIATE', 'Basic to intermediate music theory.'),
  (4, 10, 'WANT',  'BEGINNER',     'Want to learn portrait photography.');

-- Vikram (user_id=5): offers Calculus + Statistics, wants Excel
INSERT INTO skill_listings (user_id, skill_id, listing_type, proficiency, description) VALUES
  (5, 12, 'OFFER', 'ADVANCED',     'Engineering-level calculus and real analysis.'),
  (5, 13, 'OFFER', 'ADVANCED',     'Probability, hypothesis testing, and regression.'),
  (5, 16, 'WANT',  'INTERMEDIATE', 'Want to use Excel for data analysis.');

-- Ananya (user_id=6): offers Photography + Video Editing, wants Guitar
INSERT INTO skill_listings (user_id, skill_id, listing_type, proficiency, description) VALUES
  (6, 10, 'OFFER', 'ADVANCED',     'DSLR photography, composition, and lighting.'),
  (6, 11, 'OFFER', 'INTERMEDIATE', 'Adobe Premiere Pro and Lightroom editing.'),
  (6, 8,  'WANT',  'BEGINNER',     'Always wanted to learn guitar!');

-- Karan (user_id=7): offers JavaScript + Java, wants Graphic Design + Figma
INSERT INTO skill_listings (user_id, skill_id, listing_type, proficiency, description) VALUES
  (7, 2,  'OFFER', 'ADVANCED',     'React, Node.js, and vanilla JS.'),
  (7, 3,  'OFFER', 'INTERMEDIATE', 'Core Java and Spring Boot basics.'),
  (7, 5,  'WANT',  'INTERMEDIATE', 'Want to improve UI design for my apps.'),
  (7, 7,  'WANT',  'BEGINNER',     'Learning Figma for prototyping.');

-- Divya (user_id=8): offers French + Spanish, wants Python + HTML/CSS
INSERT INTO skill_listings (user_id, skill_id, listing_type, proficiency, description) VALUES
  (8, 14, 'OFFER', 'ADVANCED',     'Native French speaker, C2 level.'),
  (8, 15, 'OFFER', 'INTERMEDIATE', 'B2 Spanish, conversational and written.'),
  (8, 1,  'WANT',  'BEGINNER',     'Complete beginner, want to learn Python basics.'),
  (8, 4,  'WANT',  'BEGINNER',     'Want to build a personal website.');

-- Arjun (user_id=9): offers Excel + Public Speaking, wants Statistics
INSERT INTO skill_listings (user_id, skill_id, listing_type, proficiency, description) VALUES
  (9, 16, 'OFFER', 'ADVANCED',     'Advanced Excel: macros, pivot tables, Power BI.'),
  (9, 17, 'OFFER', 'INTERMEDIATE', 'Public speaking and presentation coaching.'),
  (9, 13, 'WANT',  'INTERMEDIATE', 'Need statistics for my business research.');

-- -------------------------------------------------------
-- BOOKINGS  (demonstrate full lifecycle)
-- -------------------------------------------------------
-- 1. Completed: Aarav taught Python to Priya
INSERT INTO bookings (requester_id, provider_id, skill_id, session_date, session_time, duration_minutes, status)
VALUES (2, 1, 1, '2026-10-01', '10:00', 60, 'COMPLETED');

-- 2. Completed: Priya taught Graphic Design to Aarav
INSERT INTO bookings (requester_id, provider_id, skill_id, session_date, session_time, duration_minutes, status)
VALUES (1, 2, 5, '2026-10-03', '14:00', 90, 'COMPLETED');

-- 3. Completed: Sneha taught Guitar to Ananya
INSERT INTO bookings (requester_id, provider_id, skill_id, session_date, session_time, duration_minutes, status)
VALUES (6, 4, 8, '2026-10-15', '11:00', 60, 'COMPLETED');

-- 4. Completed: Vikram taught Statistics to Arjun
INSERT INTO bookings (requester_id, provider_id, skill_id, session_date, session_time, duration_minutes, status)
VALUES (9, 5, 13, '2026-10-20', '09:00', 90, 'COMPLETED');

-- 5. Confirmed: Karan teaching JavaScript to Rahul (upcoming)
INSERT INTO bookings (requester_id, provider_id, skill_id, session_date, session_time, duration_minutes, status)
VALUES (3, 7, 2, '2026-11-12', '15:00', 60, 'CONFIRMED');

-- 6. Requested: Arjun wants Calculus from Vikram
INSERT INTO bookings (requester_id, provider_id, skill_id, session_date, session_time, duration_minutes, status)
VALUES (9, 5, 12, '2026-11-15', '10:00', 60, 'REQUESTED');

-- 7. Cancelled: Divya's Python request (with reason)
INSERT INTO bookings (requester_id, provider_id, skill_id, session_date, session_time, duration_minutes, status, cancel_reason)
VALUES (8, 1, 1, '2026-10-10', '13:00', 45, 'CANCELLED', 'Schedule conflict — will reschedule.');

-- -------------------------------------------------------
-- CREDIT TRANSACTIONS  (only for completed bookings)
-- -------------------------------------------------------
-- Aarav earned credits for teaching Python (booking_id=1)
INSERT INTO credit_transactions (user_id, booking_id, amount, reason)
VALUES (1, 1, 10, 'Taught Python to Priya Patel');

-- Priya earned credits for teaching Graphic Design (booking_id=2)
INSERT INTO credit_transactions (user_id, booking_id, amount, reason)
VALUES (2, 2, 10, 'Taught Graphic Design to Aarav Sharma');

-- Sneha earned credits for teaching Guitar (booking_id=3)
INSERT INTO credit_transactions (user_id, booking_id, amount, reason)
VALUES (4, 3, 10, 'Taught Guitar to Ananya Reddy');

-- Vikram earned credits for teaching Statistics (booking_id=4)
INSERT INTO credit_transactions (user_id, booking_id, amount, reason)
VALUES (5, 4, 10, 'Taught Statistics to Arjun Das');

-- -------------------------------------------------------
-- FEEDBACK  (only for completed bookings)
-- -------------------------------------------------------
-- Priya rates Aarav's Python session
INSERT INTO feedback (booking_id, reviewer_id, reviewee_id, rating, comment)
VALUES (1, 2, 1, 5, 'Aarav explained everything so clearly. Highly recommend!');

-- Aarav rates Priya's Design session
INSERT INTO feedback (booking_id, reviewer_id, reviewee_id, rating, comment)
VALUES (2, 1, 2, 5, 'Priya is a fantastic teacher, very patient and creative.');

-- Ananya rates Sneha's Guitar session
INSERT INTO feedback (booking_id, reviewer_id, reviewee_id, rating, comment)
VALUES (3, 6, 4, 4, 'Great session, learned the basic chords. A bit fast-paced.');

-- Arjun rates Vikram's Statistics session
INSERT INTO feedback (booking_id, reviewer_id, reviewee_id, rating, comment)
VALUES (4, 9, 5, 5, 'Vikram made statistics feel easy. Excellent communicator.');
