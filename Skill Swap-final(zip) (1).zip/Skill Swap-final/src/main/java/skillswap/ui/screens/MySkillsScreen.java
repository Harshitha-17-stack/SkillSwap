package skillswap.ui.screens;

import skillswap.model.*;
import skillswap.model.SkillListing.ListingType;
import skillswap.model.SkillListing.Proficiency;
import skillswap.service.SkillService;
import skillswap.ui.components.*;

import javax.swing.*;
import java.awt.*;
import java.util.List;

/**
 * My Skills screen — two columns:
 *   LEFT:  "I can teach" — offered skills with chip cards
 *   RIGHT: "I want to learn" — wanted skills with chip cards
 *
 * Add / Edit / Remove dialogs for each column.
 */
public class MySkillsScreen extends JPanel {

    private final Student      student;
    private final SkillService skillService = new SkillService();
    private final JFrame       parentFrame;

    private JPanel offerPanel;
    private JPanel wantPanel;

    // ----------------------------------------------------------------
    public MySkillsScreen(Student student, JFrame parentFrame) {
        this.student     = student;
        this.parentFrame = parentFrame;

        setLayout(new BorderLayout());
        setOpaque(false);
        setBorder(BorderFactory.createEmptyBorder(
            UIConstants.PAD_LG, UIConstants.PAD_LG,
            UIConstants.PAD_LG, UIConstants.PAD_LG));

        // Header
        JPanel header = new JPanel(new BorderLayout());
        header.setOpaque(false);
        JLabel title = new JLabel("My Skills");
        title.setFont(UIConstants.FONT_H2);
        header.add(title, BorderLayout.WEST);
        JLabel hint = new JLabel("Add skills you can teach and skills you want to learn.");
        hint.setFont(UIConstants.FONT_SMALL);
        hint.setForeground(ThemeManager.resolve(
            UIConstants.TEXT_MUTED_LIGHT, UIConstants.TEXT_MUTED_DARK));
        JPanel titleCol = new JPanel();
        titleCol.setOpaque(false);
        titleCol.setLayout(new BoxLayout(titleCol, BoxLayout.Y_AXIS));
        titleCol.add(title);
        titleCol.add(hint);
        header.add(titleCol, BorderLayout.WEST);
        add(header, BorderLayout.NORTH);
        header.setBorder(BorderFactory.createEmptyBorder(0, 0, 20, 0));

        // Two-column layout
        JPanel columns = new JPanel(new GridLayout(1, 2, 20, 0));
        columns.setOpaque(false);

        columns.add(buildColumn("📚 Skills I Can Teach", ListingType.OFFER,
                                new Color(0x6C5CE7)));
        columns.add(buildColumn("🎯 Skills I Want to Learn", ListingType.WANT,
                                new Color(0x00B894)));

        add(columns, BorderLayout.CENTER);
        refresh();
    }

    // ----------------------------------------------------------------
    private JPanel buildColumn(String title, ListingType type, Color accent) {
        JPanel col = new JPanel(new BorderLayout());
        col.setOpaque(false);

        // Column title + Add button
        JPanel colHeader = new JPanel(new BorderLayout());
        colHeader.setOpaque(false);
        colHeader.setBorder(BorderFactory.createEmptyBorder(0, 0, 12, 0));

        JLabel colTitle = new JLabel(title);
        colTitle.setFont(UIConstants.FONT_H3);
        colHeader.add(colTitle, BorderLayout.WEST);

        StyledButton addBtn = new StyledButton("+ Add", StyledButton.Variant.OUTLINE);
        addBtn.addActionListener(e -> showAddDialog(type));
        colHeader.add(addBtn, BorderLayout.EAST);
        col.add(colHeader, BorderLayout.NORTH);

        // Scroll pane for skill cards
        JPanel listPanel = new JPanel();
        listPanel.setOpaque(false);
        listPanel.setLayout(new BoxLayout(listPanel, BoxLayout.Y_AXIS));
        if (type == ListingType.OFFER) offerPanel = listPanel;
        else                           wantPanel  = listPanel;

        JScrollPane scroll = new JScrollPane(listPanel);
        scroll.setOpaque(false);
        scroll.getViewport().setOpaque(false);
        scroll.setBorder(BorderFactory.createEmptyBorder());
        col.add(scroll, BorderLayout.CENTER);

        return col;
    }

    // ----------------------------------------------------------------
    public void refresh() {
        SwingWorker<List<SkillListing>[], Void> worker = new SwingWorker<>() {
            @Override
            protected List<SkillListing>[] doInBackground() {
                @SuppressWarnings("unchecked")
                List<SkillListing>[] result = new List[2];
                result[0] = skillService.getOfferedSkills(student.getUserId());
                result[1] = skillService.getWantedSkills(student.getUserId());
                return result;
            }
            @Override
            protected void done() {
                try {
                    var data = get();
                    renderList(offerPanel, data[0], ListingType.OFFER, new Color(0x6C5CE7));
                    renderList(wantPanel,  data[1], ListingType.WANT,  new Color(0x00B894));
                } catch (Exception ex) { ex.printStackTrace(); }
            }
        };
        worker.execute();
    }

    private void renderList(JPanel panel, List<SkillListing> listings,
                            ListingType type, Color accent) {
        panel.removeAll();
        if (listings.isEmpty()) {
            JLabel empty = new JLabel("No skills added yet. Click '+ Add' to begin.");
            empty.setFont(UIConstants.FONT_SMALL);
            empty.setForeground(ThemeManager.resolve(
                UIConstants.TEXT_MUTED_LIGHT, UIConstants.TEXT_MUTED_DARK));
            empty.setBorder(BorderFactory.createEmptyBorder(8, 0, 0, 0));
            panel.add(empty);
        } else {
            for (SkillListing listing : listings) {
                panel.add(buildSkillCard(listing, accent));
                panel.add(Box.createVerticalStrut(8));
            }
        }
        panel.revalidate();
        panel.repaint();
    }

    private JPanel buildSkillCard(SkillListing listing, Color accent) {
        RoundedPanel card = new RoundedPanel(12, null, false);
        card.setLayout(new BorderLayout(8, 0));
        card.setBorder(BorderFactory.createEmptyBorder(12, 16, 12, 16));
        card.setMaximumSize(new Dimension(Integer.MAX_VALUE, 90));

        // Left: skill info
        JPanel info = new JPanel();
        info.setOpaque(false);
        info.setLayout(new BoxLayout(info, BoxLayout.Y_AXIS));

        JLabel name = new JLabel(listing.getSkill().getName());
        name.setFont(UIConstants.FONT_BOLD);
        info.add(name);

        JLabel cat = new JLabel(listing.getSkill().getCategory()
                              + "  •  " + listing.getProficiency().name());
        cat.setFont(UIConstants.FONT_SMALL);
        cat.setForeground(ThemeManager.resolve(
            UIConstants.TEXT_MUTED_LIGHT, UIConstants.TEXT_MUTED_DARK));
        info.add(cat);

        if (listing.getDescription() != null && !listing.getDescription().isBlank()) {
            JLabel desc = new JLabel("<html><i>" + listing.getDescription() + "</i></html>");
            desc.setFont(UIConstants.FONT_CAPTION);
            info.add(desc);
        }
        card.add(info, BorderLayout.CENTER);

        // Right: proficiency chip + action buttons
        JPanel right = new JPanel(new FlowLayout(FlowLayout.RIGHT, 6, 0));
        right.setOpaque(false);
        right.add(new SkillChip(listing.getProficiency().name(), accent));

        StyledButton editBtn = new StyledButton("Edit", StyledButton.Variant.GHOST);
        editBtn.setFont(UIConstants.FONT_SMALL);
        editBtn.addActionListener(e -> showEditDialog(listing));
        right.add(editBtn);

        StyledButton delBtn = new StyledButton("Remove", StyledButton.Variant.DANGER);
        delBtn.setFont(UIConstants.FONT_SMALL);
        delBtn.addActionListener(e -> {
            if (ConfirmDialog.show(parentFrame,
                    "Remove Skill",
                    "Remove <b>" + listing.getSkill().getName() + "</b> from your listings?")) {
                skillService.removeListing(listing.getListingId());
                refresh();
                Toast.success(parentFrame, "Skill removed.");
            }
        });
        right.add(delBtn);
        card.add(right, BorderLayout.EAST);

        return card;
    }

    // ----------------------------------------------------------------
    private void showAddDialog(ListingType type) {
        JDialog dialog = new JDialog(parentFrame,
            type == ListingType.OFFER ? "Add a Skill I Can Teach"
                                      : "Add a Skill I Want to Learn",
            true);
        dialog.setSize(440, 480);
        dialog.setResizable(false);
        dialog.setLocationRelativeTo(parentFrame);

        // Use GridBagLayout so button is always at bottom
        JPanel content = new JPanel(new GridBagLayout());
        content.setBorder(BorderFactory.createEmptyBorder(20, 24, 20, 24));
        GridBagConstraints gc = new GridBagConstraints();
        gc.fill      = GridBagConstraints.HORIZONTAL;
        gc.insets    = new Insets(4, 0, 4, 0);
        gc.gridx     = 0;
        gc.weightx   = 1.0;
        int row      = 0;

        // Skill Name
        gc.gridy = row++;
        JLabel n1 = new JLabel("Skill Name *");
        n1.setFont(UIConstants.FONT_SMALL); n1.setForeground(UIConstants.TEXT_MUTED_LIGHT);
        content.add(n1, gc);

        gc.gridy = row++;
        JTextField skillNameField = new JTextField();
        skillNameField.setFont(UIConstants.FONT_BODY);
        skillNameField.setPreferredSize(new Dimension(380, 34));
        skillNameField.putClientProperty("JTextField.placeholderText", "e.g. Python, Photoshop");
        content.add(skillNameField, gc);

        // Category
        gc.gridy = row++;
        JLabel n2 = new JLabel("Category *");
        n2.setFont(UIConstants.FONT_SMALL); n2.setForeground(UIConstants.TEXT_MUTED_LIGHT);
        content.add(n2, gc);

        gc.gridy = row++;
        JTextField categoryField = new JTextField();
        categoryField.setFont(UIConstants.FONT_BODY);
        categoryField.setPreferredSize(new Dimension(380, 34));
        categoryField.putClientProperty("JTextField.placeholderText", "e.g. Programming, Design, Music");
        content.add(categoryField, gc);

        // Proficiency
        gc.gridy = row++;
        JLabel n3 = new JLabel("Proficiency Level");
        n3.setFont(UIConstants.FONT_SMALL); n3.setForeground(UIConstants.TEXT_MUTED_LIGHT);
        content.add(n3, gc);

        gc.gridy = row++;
        JComboBox<Proficiency> profBox = new JComboBox<>(Proficiency.values());
        profBox.setFont(UIConstants.FONT_BODY);
        profBox.setPreferredSize(new Dimension(380, 34));
        content.add(profBox, gc);

        // Description
        gc.gridy = row++;
        JLabel n4 = new JLabel("Description (optional)");
        n4.setFont(UIConstants.FONT_SMALL); n4.setForeground(UIConstants.TEXT_MUTED_LIGHT);
        content.add(n4, gc);

        gc.gridy = row++;
        JTextField descField = new JTextField();
        descField.setFont(UIConstants.FONT_BODY);
        descField.setPreferredSize(new Dimension(380, 34));
        descField.putClientProperty("JTextField.placeholderText", "Brief description...");
        content.add(descField, gc);

        // Error label
        gc.gridy = row++;
        JLabel errLbl = new JLabel(" ");
        errLbl.setFont(UIConstants.FONT_SMALL);
        errLbl.setForeground(UIConstants.DANGER);
        content.add(errLbl, gc);

        // Add Skill button
        gc.gridy  = row++;
        gc.insets = new Insets(12, 0, 0, 0);
        JButton saveBtn = new JButton("Add Skill");
        saveBtn.setFont(UIConstants.FONT_BOLD);
        saveBtn.setBackground(UIConstants.ACCENT);
        saveBtn.setForeground(Color.WHITE);
        saveBtn.setOpaque(true);
        saveBtn.setBorderPainted(false);
        saveBtn.setPreferredSize(new Dimension(380, 40));
        saveBtn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        saveBtn.addActionListener(e -> {
            String sName = skillNameField.getText().trim();
            String sCat  = categoryField.getText().trim();
            if (sName.isBlank()) { errLbl.setText("Skill name is required."); return; }
            if (sCat.isBlank())  { errLbl.setText("Category is required.");   return; }
            try {
                Skill skill = skillService.findOrCreateSkill(sName, sCat);
                skillService.addListing(
                    student.getUserId(), skill, type,
                    (Proficiency) profBox.getSelectedItem(),
                    descField.getText().trim());
                dialog.dispose();
                refresh();
                Toast.success(parentFrame, "Skill added successfully!");
            } catch (Exception ex) {
                errLbl.setText(ex.getMessage() != null ? ex.getMessage() : "Error adding skill.");
            }
        });
        content.add(saveBtn, gc);

        dialog.add(content);
        dialog.setVisible(true);
    }

    private void showEditDialog(SkillListing listing) {
        JDialog dialog = new JDialog(parentFrame, "Edit Skill Listing", true);
        dialog.setSize(400, 280);
        dialog.setLocationRelativeTo(parentFrame);

        JPanel content = new JPanel();
        content.setLayout(new BoxLayout(content, BoxLayout.Y_AXIS));
        content.setBorder(BorderFactory.createEmptyBorder(24, 28, 24, 28));

        JLabel titleLbl = new JLabel("Editing: " + listing.getSkill().getName());
        titleLbl.setFont(UIConstants.FONT_H3);
        titleLbl.setAlignmentX(LEFT_ALIGNMENT);
        content.add(titleLbl);
        content.add(Box.createVerticalStrut(16));

        JLabel profLbl = new JLabel("Proficiency Level");
        profLbl.setFont(UIConstants.FONT_SMALL);
        profLbl.setForeground(UIConstants.TEXT_MUTED_LIGHT);
        profLbl.setAlignmentX(LEFT_ALIGNMENT);
        content.add(profLbl);
        content.add(Box.createVerticalStrut(4));

        JComboBox<Proficiency> profBox = new JComboBox<>(Proficiency.values());
        profBox.setSelectedItem(listing.getProficiency());
        profBox.setMaximumSize(new Dimension(Integer.MAX_VALUE, 36));
        profBox.setAlignmentX(LEFT_ALIGNMENT);
        content.add(profBox);
        content.add(Box.createVerticalStrut(12));

        FormField desc = new FormField("Description", listing.getDescription() != null
                                        ? listing.getDescription() : "");
        desc.setMaximumSize(new Dimension(Integer.MAX_VALUE, 80));
        desc.setAlignmentX(LEFT_ALIGNMENT);
        content.add(desc);
        content.add(Box.createVerticalStrut(16));

        StyledButton saveBtn = new StyledButton("Save Changes");
        saveBtn.setMaximumSize(new Dimension(Integer.MAX_VALUE, 38));
        saveBtn.setAlignmentX(LEFT_ALIGNMENT);
        saveBtn.addActionListener(e -> {
            skillService.updateListing(listing.getListingId(),
                (Proficiency) profBox.getSelectedItem(), desc.getText().trim());
            dialog.dispose();
            refresh();
            Toast.success(parentFrame, "Skill listing updated.");
        });
        content.add(saveBtn);
        dialog.add(content);
        dialog.setVisible(true);
    }
}
