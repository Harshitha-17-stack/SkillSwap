package skillswap.ui.screens;

import skillswap.model.*;
import skillswap.service.*;
import skillswap.ui.components.*;

import javax.swing.*;
import java.awt.*;
import java.util.List;

/**
 * Student Profile screen — name, dept/year, bio, skills, average rating,
 * and received feedback list.
 *
 * Can be used in two modes:
 *   ownProfile = true  → editable fields (Edit Profile button)
 *   ownProfile = false → read-only public view (for match cards)
 */
public class ProfileScreen extends JPanel {

    private final int          userId;
    private final JFrame       parentFrame;
    private final boolean      ownProfile;
    private final UserService  userService     = new UserService();
    private final FeedbackService feedbackService = new FeedbackService();

    // ----------------------------------------------------------------
    public ProfileScreen(int userId, JFrame parentFrame, boolean ownProfile) {
        this.userId      = userId;
        this.parentFrame = parentFrame;
        this.ownProfile  = ownProfile;

        setLayout(new BorderLayout());
        setOpaque(false);
        setBorder(BorderFactory.createEmptyBorder(
            UIConstants.PAD_LG, UIConstants.PAD_LG,
            UIConstants.PAD_LG, UIConstants.PAD_LG));

        JLabel loading = new JLabel("Loading profile…");
        loading.setFont(UIConstants.FONT_BODY);
        loading.setHorizontalAlignment(SwingConstants.CENTER);
        add(loading, BorderLayout.CENTER);

        loadProfile();
    }

    private void loadProfile() {
        SwingWorker<Object[], Void> worker = new SwingWorker<>() {
            @Override
            protected Object[] doInBackground() {
                Student student = (Student) userService.getStudentWithSkills(userId)
                    .orElse(null);
                double avgRating = userService.getAverageRating(userId);
                List<Feedback> feedback = feedbackService.getReceivedFeedback(userId);
                return new Object[]{student, avgRating, feedback};
            }
            @Override
            protected void done() {
                try {
                    Object[] data = get();
                    Student student = (Student) data[0];
                    double  avg     = (double) data[1];
                    @SuppressWarnings("unchecked")
                    List<Feedback> feedback = (List<Feedback>) data[2];
                    if (student != null) buildUI(student, avg, feedback);
                } catch (Exception ex) { ex.printStackTrace(); }
            }
        };
        worker.execute();
    }

    @SuppressWarnings("unchecked")
    private void buildUI(Student student, double avgRating, List<Feedback> feedbackList) {
        removeAll();

        JPanel main = new JPanel(new BorderLayout(0, 16));
        main.setOpaque(false);

        // ============================================================
        // TOP: Avatar + name + rating + bio
        // ============================================================
        RoundedPanel header = new RoundedPanel(UIConstants.ARC_CARD, null, true);
        header.setLayout(new BorderLayout(16, 0));
        header.setBorder(BorderFactory.createEmptyBorder(20, 24, 20, 24));

        AvatarCircle av = new AvatarCircle(student.getName(), 64);
        header.add(av, BorderLayout.WEST);

        JPanel info = new JPanel();
        info.setOpaque(false);
        info.setLayout(new BoxLayout(info, BoxLayout.Y_AXIS));

        JLabel name = new JLabel(student.getName());
        name.setFont(UIConstants.FONT_H2);
        info.add(name);

        String dept = student.getDepartment() != null ? student.getDepartment() : "Unknown Dept";
        JLabel deptYear = new JLabel(dept + " · Year " + student.getYearOfStudy());
        deptYear.setFont(UIConstants.FONT_SMALL);
        deptYear.setForeground(ThemeManager.resolve(
            UIConstants.TEXT_MUTED_LIGHT, UIConstants.TEXT_MUTED_DARK));
        info.add(deptYear);
        info.add(Box.createVerticalStrut(6));

        // Star rating
        JPanel ratingRow = new JPanel(new FlowLayout(FlowLayout.LEFT, 6, 0));
        ratingRow.setOpaque(false);
        ratingRow.add(new StarRatingPanel(avgRating, false, null));
        ratingRow.add(new JLabel(String.format("%.1f / 5.0", avgRating)
            + " (" + feedbackList.size() + " reviews)"));
        info.add(ratingRow);
        info.add(Box.createVerticalStrut(6));

        if (student.getBio() != null && !student.getBio().isBlank()) {
            JLabel bio = new JLabel("<html><i>" + student.getBio() + "</i></html>");
            bio.setFont(UIConstants.FONT_BODY);
            info.add(bio);
        }

        header.add(info, BorderLayout.CENTER);

        // Edit button (own profile only)
        if (ownProfile) {
            StyledButton editBtn = new StyledButton("Edit Profile", StyledButton.Variant.OUTLINE);
            editBtn.addActionListener(e -> showEditDialog(student));
            JPanel editWrap = new JPanel(new FlowLayout(FlowLayout.RIGHT, 0, 0));
            editWrap.setOpaque(false);
            editWrap.add(editBtn);
            header.add(editWrap, BorderLayout.EAST);
        }
        main.add(header, BorderLayout.NORTH);

        // ============================================================
        // MIDDLE: Skills
        // ============================================================
        JPanel skillsSection = new JPanel(new GridLayout(1, 2, 16, 0));
        skillsSection.setOpaque(false);

        skillsSection.add(buildSkillsPanel("📚 Teaching",
            student.getOfferedSkills(), new Color(0x6C5CE7)));
        skillsSection.add(buildSkillsPanel("🎯 Learning",
            student.getWantedSkills(),  new Color(0x00B894)));
        main.add(skillsSection, BorderLayout.CENTER);

        // ============================================================
        // BOTTOM: Feedback received
        // ============================================================
        JPanel feedbackSection = new JPanel(new BorderLayout());
        feedbackSection.setOpaque(false);

        JLabel fbTitle = new JLabel("Reviews Received");
        fbTitle.setFont(UIConstants.FONT_H3);
        fbTitle.setBorder(BorderFactory.createEmptyBorder(0, 0, 10, 0));
        feedbackSection.add(fbTitle, BorderLayout.NORTH);

        JPanel fbList = new JPanel();
        fbList.setOpaque(false);
        fbList.setLayout(new BoxLayout(fbList, BoxLayout.Y_AXIS));

        if (feedbackList.isEmpty()) {
            fbList.add(new JLabel("No reviews yet."));
        } else {
            for (Feedback fb : feedbackList) {
                fbList.add(buildFeedbackRow(fb));
                fbList.add(Box.createVerticalStrut(6));
            }
        }
        JScrollPane fbScroll = new JScrollPane(fbList);
        fbScroll.setOpaque(false);
        fbScroll.getViewport().setOpaque(false);
        fbScroll.setBorder(BorderFactory.createEmptyBorder());
        fbScroll.setPreferredSize(new Dimension(0, 150));
        feedbackSection.add(fbScroll, BorderLayout.CENTER);
        main.add(feedbackSection, BorderLayout.SOUTH);

        add(main, BorderLayout.CENTER);
        revalidate();
        repaint();
    }

    private JPanel buildSkillsPanel(String title, List<SkillListing> listings, Color accent) {
        RoundedPanel panel = new RoundedPanel(12, null, false);
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
        panel.setBorder(BorderFactory.createEmptyBorder(14, 16, 14, 16));

        JLabel lbl = new JLabel(title);
        lbl.setFont(UIConstants.FONT_H3);
        lbl.setAlignmentX(LEFT_ALIGNMENT);
        panel.add(lbl);
        panel.add(Box.createVerticalStrut(8));

        if (listings.isEmpty()) {
            JLabel none = new JLabel("None added yet.");
            none.setFont(UIConstants.FONT_SMALL);
            none.setForeground(ThemeManager.resolve(
                UIConstants.TEXT_MUTED_LIGHT, UIConstants.TEXT_MUTED_DARK));
            none.setAlignmentX(LEFT_ALIGNMENT);
            panel.add(none);
        } else {
            JPanel chipPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 6, 4));
            chipPanel.setOpaque(false);
            for (SkillListing sl : listings) {
                chipPanel.add(new SkillChip(sl.getSkill().getName(), accent));
            }
            chipPanel.setAlignmentX(LEFT_ALIGNMENT);
            panel.add(chipPanel);
        }
        return panel;
    }

    private JPanel buildFeedbackRow(Feedback fb) {
        RoundedPanel row = new RoundedPanel(10, null, false);
        row.setLayout(new BorderLayout(8, 0));
        row.setBorder(BorderFactory.createEmptyBorder(10, 14, 10, 14));
        row.setMaximumSize(new Dimension(Integer.MAX_VALUE, 70));

        JPanel left = new JPanel();
        left.setOpaque(false);
        left.setLayout(new BoxLayout(left, BoxLayout.Y_AXIS));

        String reviewer = fb.getReviewerName() != null ? fb.getReviewerName() : "Anonymous";
        JLabel revLbl = new JLabel(reviewer);
        revLbl.setFont(UIConstants.FONT_BOLD);
        left.add(revLbl);
        left.add(new StarRatingPanel(fb.getRating(), false, null));
        if (fb.getComment() != null && !fb.getComment().isBlank()) {
            JLabel comment = new JLabel("<html><i>\"" + fb.getComment() + "\"</i></html>");
            comment.setFont(UIConstants.FONT_SMALL);
            left.add(comment);
        }
        row.add(left, BorderLayout.CENTER);
        return row;
    }

    private void showEditDialog(Student student) {
        JDialog dlg = new JDialog(parentFrame, "Edit Profile", true);
        dlg.setSize(420, 360);
        dlg.setLocationRelativeTo(parentFrame);

        JPanel content = new JPanel();
        content.setLayout(new BoxLayout(content, BoxLayout.Y_AXIS));
        content.setBorder(BorderFactory.createEmptyBorder(24, 28, 24, 28));

        FormField nameF = new FormField("Full Name", student.getName());
        nameF.withValidator(t -> !t.isBlank(), "Name is required");
        nameF.setMaximumSize(new Dimension(Integer.MAX_VALUE, 80));
        nameF.setAlignmentX(LEFT_ALIGNMENT);
        content.add(nameF);
        content.add(Box.createVerticalStrut(8));

        FormField deptF = new FormField("Department",
            student.getDepartment() != null ? student.getDepartment() : "");
        deptF.setMaximumSize(new Dimension(Integer.MAX_VALUE, 80));
        deptF.setAlignmentX(LEFT_ALIGNMENT);
        content.add(deptF);
        content.add(Box.createVerticalStrut(8));

        JLabel yearLbl = new JLabel("Year of Study");
        yearLbl.setFont(UIConstants.FONT_SMALL);
        yearLbl.setForeground(UIConstants.TEXT_MUTED_LIGHT);
        yearLbl.setAlignmentX(LEFT_ALIGNMENT);
        content.add(yearLbl);
        JSpinner yearSpin = new JSpinner(new SpinnerNumberModel(
            student.getYearOfStudy(), 1, 10, 1));
        yearSpin.setMaximumSize(new Dimension(Integer.MAX_VALUE, 36));
        yearSpin.setAlignmentX(LEFT_ALIGNMENT);
        content.add(yearSpin);
        content.add(Box.createVerticalStrut(8));

        JLabel bioLbl = new JLabel("Bio");
        bioLbl.setFont(UIConstants.FONT_SMALL);
        bioLbl.setForeground(UIConstants.TEXT_MUTED_LIGHT);
        bioLbl.setAlignmentX(LEFT_ALIGNMENT);
        content.add(bioLbl);
        JTextArea bioArea = new JTextArea(student.getBio() != null ? student.getBio() : "", 3, 30);
        bioArea.setLineWrap(true); bioArea.setWrapStyleWord(true);
        JScrollPane bioScroll = new JScrollPane(bioArea);
        bioScroll.setMaximumSize(new Dimension(Integer.MAX_VALUE, 80));
        bioScroll.setAlignmentX(LEFT_ALIGNMENT);
        content.add(bioScroll);
        content.add(Box.createVerticalStrut(16));

        StyledButton saveBtn = new StyledButton("Save Changes");
        saveBtn.setMaximumSize(new Dimension(Integer.MAX_VALUE, 38));
        saveBtn.setAlignmentX(LEFT_ALIGNMENT);
        saveBtn.addActionListener(e -> {
            try {
                new UserService().updateProfile(
                    student.getUserId(),
                    nameF.getText().trim(),
                    deptF.getText().trim(),
                    (Integer) yearSpin.getValue(),
                    bioArea.getText().trim());
                dlg.dispose();
                Toast.success(parentFrame, "Profile updated successfully!");
                loadProfile();
            } catch (Exception ex) {
                Toast.error(parentFrame, ex.getMessage());
            }
        });
        content.add(saveBtn);
        dlg.add(content);
        dlg.setVisible(true);
    }
}
