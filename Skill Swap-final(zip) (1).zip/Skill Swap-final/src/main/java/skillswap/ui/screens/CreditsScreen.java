package skillswap.ui.screens;

import skillswap.model.*;
import skillswap.service.CreditService;
import skillswap.ui.components.*;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.time.format.DateTimeFormatter;
import java.util.List;

/**
 * Credits screen — large balance display + full transaction history table.
 *
 * OOP CONCEPT: CreditService.getBalance() aggregates all transactions —
 * demonstrates the service layer isolating business logic from the UI.
 */
public class CreditsScreen extends JPanel {

    private final Student       student;
    private final CreditService creditService = new CreditService();
    private final JLabel        balanceLabel;

    private static final DateTimeFormatter FMT =
        DateTimeFormatter.ofPattern("dd MMM yyyy, HH:mm");

    // ----------------------------------------------------------------
    public CreditsScreen(Student student) {
        this.student = student;

        setLayout(new BorderLayout());
        setOpaque(false);
        setBorder(BorderFactory.createEmptyBorder(
            UIConstants.PAD_LG, UIConstants.PAD_LG,
            UIConstants.PAD_LG, UIConstants.PAD_LG));

        // ============================================================
        // TOP — balance card
        // ============================================================
        RoundedPanel balanceCard = new RoundedPanel(UIConstants.ARC_CARD, null, true);
        balanceCard.setLayout(new BorderLayout());
        balanceCard.setBorder(BorderFactory.createEmptyBorder(32, 40, 32, 40));
        balanceCard.setMaximumSize(new Dimension(Integer.MAX_VALUE, 140));

        JPanel balInner = new JPanel();
        balInner.setOpaque(false);
        balInner.setLayout(new BoxLayout(balInner, BoxLayout.Y_AXIS));

        JLabel balTitle = new JLabel("⭐  Your Credit Balance");
        balTitle.setFont(UIConstants.FONT_H3);
        balTitle.setAlignmentX(LEFT_ALIGNMENT);
        balInner.add(balTitle);
        balInner.add(Box.createVerticalStrut(8));

        balanceLabel = new JLabel(student.getCreditBalance() + " pts");
        balanceLabel.setFont(new Font("Segoe UI", Font.BOLD, 52));
        balanceLabel.setForeground(UIConstants.WARNING);
        balanceLabel.setAlignmentX(LEFT_ALIGNMENT);
        balInner.add(balanceLabel);

        JLabel note = new JLabel("Earn 10 credits by completing a teaching session.");
        note.setFont(UIConstants.FONT_SMALL);
        note.setForeground(ThemeManager.resolve(
            UIConstants.TEXT_MUTED_LIGHT, UIConstants.TEXT_MUTED_DARK));
        note.setAlignmentX(LEFT_ALIGNMENT);
        balInner.add(Box.createVerticalStrut(6));
        balInner.add(note);

        balanceCard.add(balInner, BorderLayout.WEST);

        // ============================================================
        // BOTTOM — transaction history table
        // ============================================================
        JPanel historyPanel = new JPanel(new BorderLayout());
        historyPanel.setOpaque(false);
        historyPanel.setBorder(BorderFactory.createEmptyBorder(20, 0, 0, 0));

        JLabel histTitle = new JLabel("Transaction History");
        histTitle.setFont(UIConstants.FONT_H3);
        histTitle.setBorder(BorderFactory.createEmptyBorder(0, 0, 12, 0));
        historyPanel.add(histTitle, BorderLayout.NORTH);

        String[] cols = {"Date", "Reason", "Points", "Linked Booking"};
        DefaultTableModel tableModel = new DefaultTableModel(cols, 0) {
            @Override public boolean isCellEditable(int r, int c) { return false; }
        };

        JTable table = new JTable(tableModel);
        table.setFont(UIConstants.FONT_SMALL);
        table.setRowHeight(36);
        table.getTableHeader().setFont(UIConstants.FONT_BOLD);
        table.setShowGrid(false);
        table.setIntercellSpacing(new Dimension(0, 4));
        table.setFillsViewportHeight(true);

        // Colour the Points column green
        table.getColumnModel().getColumn(2).setCellRenderer(
            (t, value, sel, foc, row, col) -> {
                JLabel lbl = new JLabel("+" + value);
                lbl.setFont(UIConstants.FONT_BOLD);
                lbl.setForeground(UIConstants.SUCCESS);
                lbl.setHorizontalAlignment(SwingConstants.CENTER);
                return lbl;
            });

        int[] widths = {160, 280, 80, 120};
        for (int c = 0; c < widths.length; c++) {
            table.getColumnModel().getColumn(c).setPreferredWidth(widths[c]);
        }

        JScrollPane scroll = new JScrollPane(table);
        scroll.setOpaque(false);
        scroll.getViewport().setOpaque(false);
        scroll.setBorder(BorderFactory.createEmptyBorder());
        historyPanel.add(scroll, BorderLayout.CENTER);

        // Main layout
        JPanel main = new JPanel(new BorderLayout(0, 0));
        main.setOpaque(false);
        main.add(balanceCard,   BorderLayout.NORTH);
        main.add(historyPanel,  BorderLayout.CENTER);
        add(main, BorderLayout.CENTER);

        // Load data
        loadTransactions(tableModel);
    }

    // ----------------------------------------------------------------
    private void loadTransactions(DefaultTableModel tableModel) {
        SwingWorker<List<CreditTransaction>, Void> worker = new SwingWorker<>() {
            @Override
            protected List<CreditTransaction> doInBackground() {
                return creditService.getTransactionHistory(student.getUserId());
            }
            @Override
            protected void done() {
                try {
                    List<CreditTransaction> txList = get();
                    tableModel.setRowCount(0);
                    for (CreditTransaction tx : txList) {
                        String date = tx.getCreatedAt() != null
                            ? tx.getCreatedAt().format(FMT) : "N/A";
                        String booking = tx.getBookingId() > 0
                            ? "#" + tx.getBookingId() : "-";
                        tableModel.addRow(new Object[]{
                            date, tx.getReason(), tx.getAmount(), booking
                        });
                    }
                    // Recalculate balance from transactions
                    int balance = txList.stream()
                        .mapToInt(CreditTransaction::getAmount).sum();
                    balanceLabel.setText(balance + " pts");
                    student.setCreditBalance(balance);
                } catch (Exception ex) { ex.printStackTrace(); }
            }
        };
        worker.execute();
    }

    /** Called externally when a new session is completed. */
    public void refresh() {
        // Reload the transaction table model — find the table in the component tree
        balanceLabel.setText("Refreshing…");
        SwingWorker<Integer, Void> w = new SwingWorker<>() {
            @Override protected Integer doInBackground() {
                return creditService.getBalance(student.getUserId());
            }
            @Override protected void done() {
                try {
                    int bal = get();
                    balanceLabel.setText(bal + " pts");
                    student.setCreditBalance(bal);
                } catch (Exception ignored) {}
            }
        };
        w.execute();
    }
}
