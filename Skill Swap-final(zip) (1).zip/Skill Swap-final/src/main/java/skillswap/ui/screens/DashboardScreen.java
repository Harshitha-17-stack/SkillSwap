package skillswap.ui.screens;

import skillswap.model.*;
import skillswap.service.*;
import skillswap.ui.components.*;

import javax.swing.*;
import java.awt.*;
import java.util.List;

/**
 * Student Dashboard — summary cards + upcoming sessions list.
 *
 * OOP CONCEPT: displayDashboard() is called on the Student here —
 * polymorphism in action (different behaviour if user were Admin).
 * SwingWorker prevents UI freezing during DB calls.
 */
public class DashboardScreen extends JPanel {

    private final Student        student;
    private final BookingService bookingService = new BookingService();
    private final MatchingService matchingService = new MatchingService();

    private final StatCard creditCard;
    private final StatCard upcomingCard;
    private final StatCard completedCard;
    private final StatCard matchesCard;
    private final JPanel   sessionListPanel;

    // ----------------------------------------------------------------
    public DashboardScreen(Student student) {
        this.student = student;

        // OOP CONCEPT: Polymorphism — calls overridden displayDashboard()
        student.displayDashboard();

        setLayout(new BorderLayout());
        setOpaque(false);
        setBorder(BorderFactory.createEmptyBorder(
            UIConstants.PAD_LG, UIConstants.PAD_LG,
            UIConstants.PAD_LG, UIConstants.PAD_LG));

        // ============================================================
        // Header
        // ============================================================
        JPanel header = new JPanel(new BorderLayout());
        header.setOpaque(false);
        header.setBorder(BorderFactory.createEmptyBorder(0, 0, 20, 0));

        JLabel greeting = new JLabel("Good day, " + student.getName().split(" ")[0] + "! 👋");
        greeting.setFont(UIConstants.FONT_H2);
        header.add(greeting, BorderLayout.WEST);

        JLabel subGreet = new JLabel("Here's what's happening with your skill exchanges.");
        subGreet.setFont(UIConstants.FONT_SMALL);
        subGreet.setForeground(ThemeManager.resolve(
            UIConstants.TEXT_MUTED_LIGHT, UIConstants.TEXT_MUTED_DARK));

        JPanel greetBox = new JPanel();
        greetBox.setOpaque(false);
        greetBox.setLayout(new BoxLayout(greetBox, BoxLayout.Y_AXIS));
        greetBox.add(greeting);
        greetBox.add(subGreet);
        header.add(greetBox, BorderLayout.WEST);
        add(header, BorderLayout.NORTH);

        // ============================================================
        // Summary stat cards (2×2 grid)
        // ============================================================
        JPanel cardsPanel = new JPanel(new GridLayout(1, 4, 16, 0));
        cardsPanel.setOpaque(false);
        cardsPanel.setBorder(BorderFactory.createEmptyBorder(0, 0, 20, 0));

        creditCard    = new StatCard("⭐", "Credit Balance",
                          String.valueOf(student.getCreditBalance()), UIConstants.WARNING);
        upcomingCard  = new StatCard("📅", "Upcoming Sessions", "…", UIConstants.INFO);
        completedCard = new StatCard("✅", "Completed Sessions", "…", UIConstants.SUCCESS);
        matchesCard   = new StatCard("🤝", "Potential Matches",  "…", UIConstants.ACCENT);

        cardsPanel.add(creditCard);
        cardsPanel.add(upcomingCard);
        cardsPanel.add(completedCard);
        cardsPanel.add(matchesCard);
        add(cardsPanel, BorderLayout.NORTH);

        // ============================================================
        // Main content area — upcoming sessions list
        // ============================================================
        JPanel content = new JPanel(new BorderLayout());
        content.setOpaque(false);

        // Section title
        JLabel upcoming = new JLabel("Upcoming Sessions");
        upcoming.setFont(UIConstants.FONT_H3);
        upcoming.setBorder(BorderFactory.createEmptyBorder(0, 0, 12, 0));
        content.add(upcoming, BorderLayout.NORTH);

        // Session list (scrollable)
        sessionListPanel = new JPanel();
        sessionListPanel.setOpaque(false);
        sessionListPanel.setLayout(new BoxLayout(sessionListPanel, BoxLayout.Y_AXIS));

        JScrollPane scroll = new JScrollPane(sessionListPanel);
        scroll.setOpaque(false);
        scroll.getViewport().setOpaque(false);
        scroll.setBorder(BorderFactory.createEmptyBorder());
        content.add(scroll, BorderLayout.CENTER);

        // Wrap cards + content in a vertical layout
        JPanel body = new JPanel(new BorderLayout(0, 0));
        body.setOpaque(false);
        body.add(cardsPanel, BorderLayout.NORTH);
        body.add(content,    BorderLayout.CENTER);
        add(body, BorderLayout.CENTER);

        // Load data in background
        loadData();
    }

    // ----------------------------------------------------------------
    private void loadData() {
        SwingWorker<int[], Void> worker = new SwingWorker<>() {
            private List<SessionBooking> upcoming;
            private int matchCount;

            @Override
            protected int[] doInBackground() {
                upcoming   = bookingService.getBookingsByStatus(
                                 student.getUserId(), BookingStatus.CONFIRMED);
                int comp   = bookingService.countCompletedAsProvider(student.getUserId())
                           + bookingService.countCompletedAsRequester(student.getUserId());
                matchCount = matchingService.findMatches(student.getUserId()).size();
                return new int[]{ upcoming.size(), comp, matchCount };
            }

            @Override
            protected void done() {
                try {
                    int[] counts = get();
                    upcomingCard .setValue(String.valueOf(counts[0]));
                    completedCard.setValue(String.valueOf(counts[1]));
                    matchesCard  .setValue(String.valueOf(counts[2]));
                    renderSessionList(upcoming);
                } catch (Exception ex) {
                    ex.printStackTrace();
                }
            }
        };
        worker.execute();
    }

    private void renderSessionList(List<SessionBooking> sessions) {
        sessionListPanel.removeAll();
        if (sessions.isEmpty()) {
            JLabel empty = new JLabel("No upcoming confirmed sessions. Go find a match!");
            empty.setFont(UIConstants.FONT_BODY);
            empty.setForeground(ThemeManager.resolve(
                UIConstants.TEXT_MUTED_LIGHT, UIConstants.TEXT_MUTED_DARK));
            empty.setBorder(BorderFactory.createEmptyBorder(12, 0, 0, 0));
            sessionListPanel.add(empty);
        } else {
            for (SessionBooking b : sessions) {
                sessionListPanel.add(buildSessionRow(b));
                sessionListPanel.add(Box.createVerticalStrut(8));
            }
        }
        sessionListPanel.revalidate();
        sessionListPanel.repaint();
    }

    private JPanel buildSessionRow(SessionBooking b) {
        RoundedPanel row = new RoundedPanel(12, null, false);
        row.setLayout(new BorderLayout(12, 0));
        row.setBorder(BorderFactory.createEmptyBorder(12, 16, 12, 16));
        row.setMaximumSize(new Dimension(Integer.MAX_VALUE, 64));

        // Left: skill + partner
        boolean isTeacher = b.getProviderId() == student.getUserId();
        String partner    = isTeacher ? b.getRequesterName() : b.getProviderName();
        String role       = isTeacher ? "Teaching" : "Learning";
        JLabel main       = new JLabel(role + " " + b.getSkill().getName()
                                     + " with " + partner);
        main.setFont(UIConstants.FONT_BOLD);
        row.add(main, BorderLayout.WEST);

        // Right: date + status pill
        JPanel rightSide = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 0));
        rightSide.setOpaque(false);
        rightSide.add(new JLabel(b.getSessionDate() + " " + b.getSessionTime()));
        rightSide.add(StatusPill.forStatus(b.getStatus()));
        row.add(rightSide, BorderLayout.EAST);

        return row;
    }

    /** Called by MainFrame when credits change so the card stays accurate. */
    public void refreshCredits() {
        creditCard.setValue(String.valueOf(student.getCreditBalance()));
    }
}
