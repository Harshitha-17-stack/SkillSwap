package skillswap.ui.screens;

import skillswap.model.*;
import skillswap.service.BookingService;
import skillswap.service.MatchingService;
import skillswap.service.SkillService;
import skillswap.ui.components.*;

import javax.swing.*;
import java.awt.*;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;
import java.util.function.Consumer;

/**
 * Find Matches screen — searchable/filterable match cards.
 * Each card shows avatar, skills, match badge, compatibility bar,
 * explanation, and "Request Session" button.
 *
 * OOP CONCEPT: uses MatchingService.findMatches() overloads (method overloading demo).
 */
public class FindMatchesScreen extends JPanel {

    private final Student          student;
    private final MatchingService  matchingService  = new MatchingService();
    private final BookingService   bookingService   = new BookingService();
    private final SkillService     skillService     = new SkillService();
    private final JFrame           parentFrame;
    private final Consumer<String> navigate;   // navigate to another screen by id

    private final JTextField searchField;
    private final JComboBox<String> levelFilter;
    private final JPanel     resultsPanel;
    private final JLabel     countLabel;

    // ----------------------------------------------------------------
    public FindMatchesScreen(Student student, JFrame parentFrame, Consumer<String> navigate) {
        this.student     = student;
        this.parentFrame = parentFrame;
        this.navigate    = navigate;

        setLayout(new BorderLayout());
        setOpaque(false);
        setBorder(BorderFactory.createEmptyBorder(
            UIConstants.PAD_LG, UIConstants.PAD_LG,
            UIConstants.PAD_LG, UIConstants.PAD_LG));

        // ============================================================
        // Header + search bar
        // ============================================================
        JPanel top = new JPanel(new BorderLayout(0, 12));
        top.setOpaque(false);
        top.setBorder(BorderFactory.createEmptyBorder(0, 0, 16, 0));

        JLabel title = new JLabel("Find Matches");
        title.setFont(UIConstants.FONT_H2);
        top.add(title, BorderLayout.NORTH);

        JPanel filterRow = new JPanel(new FlowLayout(FlowLayout.LEFT, 12, 0));
        filterRow.setOpaque(false);

        searchField = new JTextField(20);
        searchField.putClientProperty("JTextField.placeholderText", "Search by skill name…");
        searchField.setFont(UIConstants.FONT_BODY);
        filterRow.add(searchField);

        levelFilter = new JComboBox<>(new String[]{"All Levels", "BEGINNER", "INTERMEDIATE", "ADVANCED"});
        filterRow.add(levelFilter);

        StyledButton searchBtn = new StyledButton("🔍 Search", StyledButton.Variant.PRIMARY);
        searchBtn.addActionListener(e -> runSearch());
        filterRow.add(searchBtn);

        StyledButton clearBtn = new StyledButton("Clear", StyledButton.Variant.GHOST);
        clearBtn.addActionListener(e -> {
            searchField.setText("");
            levelFilter.setSelectedIndex(0);
            runSearch();
        });
        filterRow.add(clearBtn);

        countLabel = new JLabel("…");
        countLabel.setFont(UIConstants.FONT_SMALL);
        countLabel.setForeground(ThemeManager.resolve(
            UIConstants.TEXT_MUTED_LIGHT, UIConstants.TEXT_MUTED_DARK));
        filterRow.add(countLabel);

        top.add(filterRow, BorderLayout.CENTER);
        add(top, BorderLayout.NORTH);

        // Allow Enter in search field
        searchField.addActionListener(e -> runSearch());

        // ============================================================
        // Results panel (scrollable)
        // ============================================================
        resultsPanel = new JPanel();
        resultsPanel.setOpaque(false);
        resultsPanel.setLayout(new BoxLayout(resultsPanel, BoxLayout.Y_AXIS));

        JScrollPane scroll = new JScrollPane(resultsPanel);
        scroll.setOpaque(false);
        scroll.getViewport().setOpaque(false);
        scroll.setBorder(BorderFactory.createEmptyBorder());
        add(scroll, BorderLayout.CENTER);

        // Initial load
        runSearch();
    }

    // ----------------------------------------------------------------
    private void runSearch() {
        String query = searchField.getText().trim();
        String level = (String) levelFilter.getSelectedItem();
        if ("All Levels".equals(level)) level = null;
        final String lvl = level;

        countLabel.setText("Searching…");
        resultsPanel.removeAll();
        resultsPanel.revalidate();
        resultsPanel.repaint();

        SwingWorker<List<MatchResult>, Void> worker = new SwingWorker<>() {
            @Override
            protected List<MatchResult> doInBackground() {
                // OOP CONCEPT: Method Overloading — three overloads used here
                if (!query.isEmpty() && lvl != null) {
                    return matchingService.findMatches(student.getUserId(), query, lvl);
                } else if (!query.isEmpty()) {
                    return matchingService.findMatches(student.getUserId(), query);
                } else {
                    return matchingService.findMatches(student.getUserId());
                }
            }
            @Override
            protected void done() {
                try {
                    List<MatchResult> results = get();
                    countLabel.setText(results.size() + " match(es) found");
                    renderResults(results);
                } catch (Exception ex) {
                    countLabel.setText("Search failed.");
                    ex.printStackTrace();
                }
            }
        };
        worker.execute();
    }

    private void renderResults(List<MatchResult> results) {
        resultsPanel.removeAll();
        if (results.isEmpty()) {
            JLabel empty = new JLabel("No matches found. Try adding more skills first!");
            empty.setFont(UIConstants.FONT_BODY);
            empty.setForeground(ThemeManager.resolve(
                UIConstants.TEXT_MUTED_LIGHT, UIConstants.TEXT_MUTED_DARK));
            empty.setBorder(BorderFactory.createEmptyBorder(20, 0, 0, 0));
            resultsPanel.add(empty);
        } else {
            for (MatchResult r : results) {
                resultsPanel.add(buildMatchCard(r));
                resultsPanel.add(Box.createVerticalStrut(12));
            }
        }
        resultsPanel.revalidate();
        resultsPanel.repaint();
    }

    private JPanel buildMatchCard(MatchResult match) {
        RoundedPanel card = new RoundedPanel(UIConstants.ARC_CARD, null, true);
        card.setLayout(new BorderLayout(16, 0));
        card.setBorder(BorderFactory.createEmptyBorder(16, 20, 16, 20));
        card.setMaximumSize(new Dimension(Integer.MAX_VALUE, 140));

        // Left: avatar + name + dept
        JPanel left = new JPanel();
        left.setOpaque(false);
        left.setLayout(new BoxLayout(left, BoxLayout.Y_AXIS));
        left.setPreferredSize(new Dimension(160, 0));

        AvatarCircle av = new AvatarCircle(match.getMatchedStudent().getName(),
                                            UIConstants.AVATAR_SIZE_LG);
        av.setAlignmentX(CENTER_ALIGNMENT);
        left.add(av);
        left.add(Box.createVerticalStrut(6));

        JLabel nameL = new JLabel(match.getMatchedStudent().getName());
        nameL.setFont(UIConstants.FONT_BOLD);
        nameL.setAlignmentX(CENTER_ALIGNMENT);
        left.add(nameL);

        JLabel deptL = new JLabel(match.getMatchedStudent().getDepartment() != null
            ? match.getMatchedStudent().getDepartment() : "");
        deptL.setFont(UIConstants.FONT_SMALL);
        deptL.setForeground(ThemeManager.resolve(
            UIConstants.TEXT_MUTED_LIGHT, UIConstants.TEXT_MUTED_DARK));
        deptL.setAlignmentX(CENTER_ALIGNMENT);
        left.add(deptL);

        card.add(left, BorderLayout.WEST);

        // Centre: explanation + compatibility bar
        JPanel centre = new JPanel();
        centre.setOpaque(false);
        centre.setLayout(new BoxLayout(centre, BoxLayout.Y_AXIS));

        // Match badge
        StatusPill badge = match.getMatchType() == MatchResult.MatchType.STRONG
            ? StatusPill.strongMatch() : StatusPill.partialMatch();
        badge.setAlignmentX(LEFT_ALIGNMENT);
        centre.add(badge);
        centre.add(Box.createVerticalStrut(6));

        JLabel expl = new JLabel("<html><body style='width:320px'>"
            + match.getExplanation() + "</body></html>");
        expl.setFont(UIConstants.FONT_SMALL);
        expl.setAlignmentX(LEFT_ALIGNMENT);
        centre.add(expl);
        centre.add(Box.createVerticalStrut(8));

        // Compatibility score bar + label
        JPanel scoreRow = new JPanel(new FlowLayout(FlowLayout.LEFT, 6, 0));
        scoreRow.setOpaque(false);
        CompatibilityBar bar = new CompatibilityBar(match.getCompatibilityScore());
        bar.setPreferredSize(new Dimension(160, 10));
        scoreRow.add(bar);
        scoreRow.add(new JLabel(match.getCompatibilityScore() + "%"));
        centre.add(scoreRow);

        card.add(centre, BorderLayout.CENTER);

        // Right: action buttons
        JPanel right = new JPanel();
        right.setOpaque(false);
        right.setLayout(new BoxLayout(right, BoxLayout.Y_AXIS));
        right.setPreferredSize(new Dimension(140, 0));

        StyledButton requestBtn = new StyledButton("Request Session");
        requestBtn.setMaximumSize(new Dimension(140, 36));
        requestBtn.setAlignmentX(CENTER_ALIGNMENT);
        requestBtn.addActionListener(e ->
            showBookingDialog(match.getMatchedStudent(), match.getTheyOffer()));
        right.add(Box.createVerticalGlue());
        right.add(requestBtn);
        right.add(Box.createVerticalStrut(8));

        StyledButton profileBtn = new StyledButton("View Profile", StyledButton.Variant.OUTLINE);
        profileBtn.setMaximumSize(new Dimension(140, 36));
        profileBtn.setAlignmentX(CENTER_ALIGNMENT);
        // Navigate to profile — pass user id via a naming convention
        profileBtn.addActionListener(e ->
            showProfileDialog(match.getMatchedStudent()));
        right.add(profileBtn);
        right.add(Box.createVerticalGlue());

        card.add(right, BorderLayout.EAST);
        return card;
    }

    // ----------------------------------------------------------------
    private void showBookingDialog(Student provider, String skillName) {
        JDialog dlg = new JDialog(parentFrame,
            "Request Session with " + provider.getName(), true);
        dlg.setSize(420, 340);
        dlg.setLocationRelativeTo(parentFrame);

        JPanel content = new JPanel();
        content.setLayout(new BoxLayout(content, BoxLayout.Y_AXIS));
        content.setBorder(BorderFactory.createEmptyBorder(24, 28, 24, 28));

        JLabel heading = new JLabel("Book a session with " + provider.getName());
        heading.setFont(UIConstants.FONT_H3);
        heading.setAlignmentX(LEFT_ALIGNMENT);
        content.add(heading);
        content.add(Box.createVerticalStrut(16));

        // Skill (pre-filled)
        FormField skillField = new FormField("Skill", skillName);
        skillField.getField().setEditable(false);
        skillField.setMaximumSize(new Dimension(Integer.MAX_VALUE, 60));
        skillField.setAlignmentX(LEFT_ALIGNMENT);
        content.add(skillField);
        content.add(Box.createVerticalStrut(10));

        // Date (default = tomorrow)
        JLabel dateLbl = new JLabel("Date (YYYY-MM-DD)");
        dateLbl.setFont(UIConstants.FONT_SMALL);
        dateLbl.setForeground(UIConstants.TEXT_MUTED_LIGHT);
        dateLbl.setAlignmentX(LEFT_ALIGNMENT);
        content.add(dateLbl);
        content.add(Box.createVerticalStrut(4));

        JTextField dateField = new JTextField(LocalDate.now().plusDays(1).toString());
        dateField.setFont(UIConstants.FONT_BODY);
        dateField.setMaximumSize(new Dimension(Integer.MAX_VALUE, 36));
        dateField.setAlignmentX(LEFT_ALIGNMENT);
        content.add(dateField);
        content.add(Box.createVerticalStrut(10));

        // Time + Duration row
        JPanel timeRow = new JPanel(new GridLayout(1, 2, 12, 0));
        timeRow.setOpaque(false);
        timeRow.setMaximumSize(new Dimension(Integer.MAX_VALUE, 70));
        timeRow.setAlignmentX(LEFT_ALIGNMENT);

        FormField timeField = new FormField("Time (HH:MM)", "e.g. 14:00");
        timeRow.add(timeField);

        JPanel durWrap = new JPanel();
        durWrap.setOpaque(false);
        durWrap.setLayout(new BoxLayout(durWrap, BoxLayout.Y_AXIS));
        JLabel durLbl = new JLabel("Duration (minutes)");
        durLbl.setFont(UIConstants.FONT_SMALL);
        durLbl.setForeground(UIConstants.TEXT_MUTED_LIGHT);
        durLbl.setAlignmentX(LEFT_ALIGNMENT);
        durWrap.add(durLbl);
        durWrap.add(Box.createVerticalStrut(4));
        JSpinner durSpinner = new JSpinner(new SpinnerNumberModel(60, 15, 240, 15));
        durSpinner.setMaximumSize(new Dimension(Integer.MAX_VALUE, 36));
        durWrap.add(durSpinner);
        timeRow.add(durWrap);
        content.add(timeRow);
        content.add(Box.createVerticalStrut(12));

        JLabel errLbl = new JLabel(" ");
        errLbl.setFont(UIConstants.FONT_SMALL);
        errLbl.setForeground(UIConstants.DANGER);
        errLbl.setAlignmentX(LEFT_ALIGNMENT);
        content.add(errLbl);

        StyledButton confirmBtn = new StyledButton("Send Request");
        confirmBtn.setMaximumSize(new Dimension(Integer.MAX_VALUE, 38));
        confirmBtn.setAlignmentX(LEFT_ALIGNMENT);
        confirmBtn.addActionListener(e -> {
            try {
                LocalDate date = LocalDate.parse(dateField.getText().trim());
                LocalTime time = LocalTime.parse(timeField.getText().trim());
                int dur        = (Integer) durSpinner.getValue();

                // Find skill object
                var skillOpt = skillService.getAllSkills().stream()
                    .filter(s -> s.getName().equalsIgnoreCase(skillName))
                    .findFirst();
                if (skillOpt.isEmpty()) {
                    errLbl.setText("Skill not found in catalogue."); return;
                }

                bookingService.createBooking(
                    student.getUserId(), provider.getUserId(),
                    skillOpt.get(), date, time, dur);

                dlg.dispose();
                Toast.success(parentFrame, "Session request sent to " + provider.getName() + "!");
            } catch (Exception ex) {
                errLbl.setText(ex.getMessage() != null ? ex.getMessage() : "Invalid input.");
            }
        });
        content.add(confirmBtn);
        dlg.add(content);
        dlg.setVisible(true);
    }

    private void showProfileDialog(Student other) {
        JDialog dlg = new JDialog(parentFrame, other.getName() + "'s Profile", false);
        dlg.setSize(400, 300);
        dlg.setLocationRelativeTo(parentFrame);
        dlg.add(new ProfileScreen(other.getUserId(), parentFrame, false));
        dlg.setVisible(true);
    }
}
