package skillswap.ui.screens;

import skillswap.model.*;
import skillswap.service.FeedbackService;
import skillswap.ui.components.*;

import javax.swing.*;
import java.awt.*;
import java.time.format.DateTimeFormatter;
import java.util.List;

/**
 * Ratings & Feedback screen — shows received reviews with star ratings
 * and an average rating summary at the top.
 */
public class FeedbackScreen extends JPanel {

    private final Student         student;
    private final FeedbackService feedbackService = new FeedbackService();

    private static final DateTimeFormatter FMT =
        DateTimeFormatter.ofPattern("dd MMM yyyy");

    // ----------------------------------------------------------------
    public FeedbackScreen(Student student) {
        this.student = student;

        setLayout(new BorderLayout());
        setOpaque(false);
        setBorder(BorderFactory.createEmptyBorder(
            UIConstants.PAD_LG, UIConstants.PAD_LG,
            UIConstants.PAD_LG, UIConstants.PAD_LG));

        JLabel title = new JLabel("Ratings & Feedback");
        title.setFont(UIConstants.FONT_H2);
        title.setBorder(BorderFactory.createEmptyBorder(0, 0, 16, 0));
        add(title, BorderLayout.NORTH);

        JPanel content = new JPanel();
        content.setOpaque(false);
        content.setLayout(new BoxLayout(content, BoxLayout.Y_AXIS));

        // Average rating summary card
        JLabel loadingLbl = new JLabel("Loading…");
        loadingLbl.setFont(UIConstants.FONT_BODY);
        loadingLbl.setAlignmentX(LEFT_ALIGNMENT);
        content.add(loadingLbl);

        JScrollPane scroll = new JScrollPane(content);
        scroll.setOpaque(false);
        scroll.getViewport().setOpaque(false);
        scroll.setBorder(BorderFactory.createEmptyBorder());
        add(scroll, BorderLayout.CENTER);

        loadData(content, loadingLbl);
    }

    private void loadData(JPanel content, JLabel placeholder) {
        SwingWorker<Object[], Void> worker = new SwingWorker<>() {
            @Override
            protected Object[] doInBackground() {
                double avg = feedbackService.getAverageRating(student.getUserId());
                List<Feedback> received = feedbackService.getReceivedFeedback(student.getUserId());
                List<Feedback> given    = feedbackService.getGivenFeedback(student.getUserId());
                return new Object[]{ avg, received, given };
            }
            @Override
            protected void done() {
                try {
                    Object[] data = get();
                    double avg = (double) data[0];
                    @SuppressWarnings("unchecked")
                    List<Feedback> received = (List<Feedback>) data[1];
                    @SuppressWarnings("unchecked")
                    List<Feedback> given    = (List<Feedback>) data[2];
                    content.remove(placeholder);
                    buildUI(content, avg, received, given);
                } catch (Exception ex) { ex.printStackTrace(); }
            }
        };
        worker.execute();
    }

    private void buildUI(JPanel content, double avg,
                          List<Feedback> received, List<Feedback> given) {
        // ---- Summary card ----
        RoundedPanel summaryCard = new RoundedPanel(UIConstants.ARC_CARD, null, true);
        summaryCard.setLayout(new FlowLayout(FlowLayout.LEFT, 24, 16));
        summaryCard.setMaximumSize(new Dimension(Integer.MAX_VALUE, 90));
        summaryCard.setAlignmentX(LEFT_ALIGNMENT);

        JLabel avgLabel = new JLabel(String.format("%.1f", avg));
        avgLabel.setFont(new Font("Segoe UI", Font.BOLD, 42));
        avgLabel.setForeground(UIConstants.WARNING);
        summaryCard.add(avgLabel);

        JPanel starInfo = new JPanel();
        starInfo.setOpaque(false);
        starInfo.setLayout(new BoxLayout(starInfo, BoxLayout.Y_AXIS));
        starInfo.add(new StarRatingPanel(avg, false, null));
        JLabel cnt = new JLabel("based on " + received.size() + " review(s)");
        cnt.setFont(UIConstants.FONT_SMALL);
        cnt.setForeground(ThemeManager.resolve(
            UIConstants.TEXT_MUTED_LIGHT, UIConstants.TEXT_MUTED_DARK));
        starInfo.add(cnt);
        summaryCard.add(starInfo);
        content.add(summaryCard);
        content.add(Box.createVerticalStrut(20));

        // ---- Received reviews ----
        JLabel recTitle = new JLabel("Reviews I Received");
        recTitle.setFont(UIConstants.FONT_H3);
        recTitle.setAlignmentX(LEFT_ALIGNMENT);
        content.add(recTitle);
        content.add(Box.createVerticalStrut(10));

        if (received.isEmpty()) {
            JLabel none = new JLabel("No reviews yet. Complete sessions to start receiving feedback.");
            none.setFont(UIConstants.FONT_SMALL);
            none.setForeground(ThemeManager.resolve(
                UIConstants.TEXT_MUTED_LIGHT, UIConstants.TEXT_MUTED_DARK));
            none.setAlignmentX(LEFT_ALIGNMENT);
            content.add(none);
        } else {
            for (Feedback fb : received) {
                content.add(buildFeedbackCard(fb, true));
                content.add(Box.createVerticalStrut(8));
            }
        }

        content.add(Box.createVerticalStrut(20));

        // ---- Given reviews ----
        JLabel givenTitle = new JLabel("Reviews I Gave");
        givenTitle.setFont(UIConstants.FONT_H3);
        givenTitle.setAlignmentX(LEFT_ALIGNMENT);
        content.add(givenTitle);
        content.add(Box.createVerticalStrut(10));

        if (given.isEmpty()) {
            JLabel none = new JLabel("You haven't given any reviews yet.");
            none.setFont(UIConstants.FONT_SMALL);
            none.setForeground(ThemeManager.resolve(
                UIConstants.TEXT_MUTED_LIGHT, UIConstants.TEXT_MUTED_DARK));
            none.setAlignmentX(LEFT_ALIGNMENT);
            content.add(none);
        } else {
            for (Feedback fb : given) {
                content.add(buildFeedbackCard(fb, false));
                content.add(Box.createVerticalStrut(8));
            }
        }

        content.revalidate();
        content.repaint();
    }

    private JPanel buildFeedbackCard(Feedback fb, boolean received) {
        RoundedPanel card = new RoundedPanel(12, null, false);
        card.setLayout(new BorderLayout(12, 0));
        card.setBorder(BorderFactory.createEmptyBorder(14, 18, 14, 18));
        card.setMaximumSize(new Dimension(Integer.MAX_VALUE, 110));
        card.setAlignmentX(LEFT_ALIGNMENT);

        // Left: person name + avatar
        JPanel left = new JPanel();
        left.setOpaque(false);
        left.setLayout(new BoxLayout(left, BoxLayout.Y_AXIS));
        left.setPreferredSize(new Dimension(140, 0));

        String person = received ? fb.getReviewerName() : fb.getRevieweeName();
        String label  = received ? "From" : "To";
        AvatarCircle av = new AvatarCircle(person != null ? person : "?",
                                            UIConstants.AVATAR_SIZE_SM);
        av.setAlignmentX(LEFT_ALIGNMENT);
        left.add(av);
        left.add(Box.createVerticalStrut(4));
        JLabel personLbl = new JLabel(label + ": " + (person != null ? person : "Unknown"));
        personLbl.setFont(UIConstants.FONT_SMALL);
        left.add(personLbl);
        card.add(left, BorderLayout.WEST);

        // Centre: stars + comment
        JPanel centre = new JPanel();
        centre.setOpaque(false);
        centre.setLayout(new BoxLayout(centre, BoxLayout.Y_AXIS));

        centre.add(new StarRatingPanel(fb.getRating(), false, null));
        if (fb.getComment() != null && !fb.getComment().isBlank()) {
            JLabel comment = new JLabel(
                "<html><body style='width:320px'><i>\"" + fb.getComment() + "\"</i></body></html>");
            comment.setFont(UIConstants.FONT_BODY);
            centre.add(comment);
        }
        card.add(centre, BorderLayout.CENTER);

        // Right: date
        if (fb.getCreatedAt() != null) {
            JLabel date = new JLabel(fb.getCreatedAt().format(FMT));
            date.setFont(UIConstants.FONT_CAPTION);
            date.setForeground(ThemeManager.resolve(
                UIConstants.TEXT_MUTED_LIGHT, UIConstants.TEXT_MUTED_DARK));
            card.add(date, BorderLayout.EAST);
        }
        return card;
    }
}
