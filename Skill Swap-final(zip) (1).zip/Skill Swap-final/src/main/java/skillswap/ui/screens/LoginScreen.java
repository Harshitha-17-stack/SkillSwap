package skillswap.ui.screens;

import skillswap.model.User;
import skillswap.service.AuthService;
import skillswap.ui.components.*;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

/**
 * Welcome / Login screen — split layout:
 *   LEFT:  gradient brand panel with app name + tagline
 *   RIGHT: login form
 *
 * OOP CONCEPT: Encapsulation — AuthService interaction hidden behind onLogin callback.
 */
public class LoginScreen extends JPanel {

    private final AuthService   authService = new AuthService();
    private final Runnable      onLoginSuccess;
    private final Runnable      onRegister;

    private final FormField     emailField;
    private final PasswordField passwordField;
    private final JLabel        errorLabel;

    // ----------------------------------------------------------------
    public LoginScreen(Runnable onLoginSuccess, Runnable onRegister) {
        this.onLoginSuccess = onLoginSuccess;
        this.onRegister     = onRegister;

        setLayout(new GridLayout(1, 2));

        // ============================================================
        // LEFT PANEL — gradient brand panel
        // ============================================================
        JPanel brandPanel = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING,
                                    RenderingHints.VALUE_ANTIALIAS_ON);
                // Gradient: deep indigo → violet
                GradientPaint gp = new GradientPaint(
                    0, 0, new Color(0x4834C2),
                    getWidth(), getHeight(), new Color(0x9B59B6));
                g2.setPaint(gp);
                g2.fillRect(0, 0, getWidth(), getHeight());
                g2.dispose();
            }
        };
        brandPanel.setLayout(new GridBagLayout());

        JPanel brandContent = new JPanel();
        brandContent.setOpaque(false);
        brandContent.setLayout(new BoxLayout(brandContent, BoxLayout.Y_AXIS));

        // App icon / logo
        JLabel logo = new JLabel("🔄");
        logo.setFont(new Font("Segoe UI Emoji", Font.PLAIN, 64));
        logo.setAlignmentX(CENTER_ALIGNMENT);
        brandContent.add(logo);
        brandContent.add(Box.createVerticalStrut(16));

        JLabel appName = new JLabel("SkillSwap");
        appName.setFont(new Font("Segoe UI", Font.BOLD, 40));
        appName.setForeground(Color.WHITE);
        appName.setAlignmentX(CENTER_ALIGNMENT);
        brandContent.add(appName);
        brandContent.add(Box.createVerticalStrut(12));

        JLabel tagline = new JLabel("<html><center>Exchange skills, not money.<br>"
                                  + "Learn what you love, teach what you know.</center></html>");
        tagline.setFont(new Font("Segoe UI", Font.PLAIN, 16));
        tagline.setForeground(new Color(255, 255, 255, 200));
        tagline.setAlignmentX(CENTER_ALIGNMENT);
        brandContent.add(tagline);
        brandContent.add(Box.createVerticalStrut(40));

        // Feature bullets
        for (String feature : new String[]{
            "🎓  Teach what you know",
            "💡  Learn what you love",
            "⭐  Earn credits for teaching",
            "🤝  Mutual skill matching"}) {
            JLabel f = new JLabel(feature);
            f.setFont(new Font("Segoe UI", Font.PLAIN, 14));
            f.setForeground(new Color(255, 255, 255, 180));
            f.setAlignmentX(CENTER_ALIGNMENT);
            brandContent.add(f);
            brandContent.add(Box.createVerticalStrut(8));
        }

        brandPanel.add(brandContent);

        // ============================================================
        // RIGHT PANEL — login form
        // ============================================================
        JPanel formWrapper = new JPanel(new GridBagLayout());
        formWrapper.setBackground(UIConstants.SURFACE_LIGHT);

        JPanel form = new JPanel();
        form.setOpaque(false);
        form.setLayout(new BoxLayout(form, BoxLayout.Y_AXIS));
        form.setPreferredSize(new Dimension(360, 480));

        JLabel heading = new JLabel("Welcome back 👋");
        heading.setFont(UIConstants.FONT_H2);
        heading.setAlignmentX(LEFT_ALIGNMENT);
        form.add(heading);
        form.add(Box.createVerticalStrut(4));

        JLabel sub = new JLabel("Sign in to continue your skill exchange journey.");
        sub.setFont(UIConstants.FONT_SMALL);
        sub.setForeground(UIConstants.TEXT_MUTED_LIGHT);
        sub.setAlignmentX(LEFT_ALIGNMENT);
        form.add(sub);
        form.add(Box.createVerticalStrut(28));

        // Email
        emailField = new FormField("Email address", "you@university.edu");
        emailField.withValidator(
            t -> t.matches("^[\\w._%+\\-]+@[\\w.\\-]+\\.[a-zA-Z]{2,}$"),
            "Please enter a valid email address");
        emailField.setAlignmentX(LEFT_ALIGNMENT);
        emailField.setMaximumSize(new Dimension(Integer.MAX_VALUE, 80));
        form.add(emailField);
        form.add(Box.createVerticalStrut(12));

        // Password
        JLabel pwdLbl = new JLabel("Password");
        pwdLbl.setFont(UIConstants.FONT_SMALL);
        pwdLbl.setForeground(UIConstants.TEXT_MUTED_LIGHT);
        pwdLbl.setAlignmentX(LEFT_ALIGNMENT);
        form.add(pwdLbl);
        form.add(Box.createVerticalStrut(4));

        passwordField = new PasswordField("Enter your password", false);
        passwordField.setAlignmentX(LEFT_ALIGNMENT);
        passwordField.setMaximumSize(new Dimension(Integer.MAX_VALUE, 40));
        form.add(passwordField);
        form.add(Box.createVerticalStrut(12));

        // Error label
        errorLabel = new JLabel(" ");
        errorLabel.setFont(UIConstants.FONT_SMALL);
        errorLabel.setForeground(UIConstants.DANGER);
        errorLabel.setAlignmentX(LEFT_ALIGNMENT);
        form.add(errorLabel);
        form.add(Box.createVerticalStrut(16));

        // Login button
        StyledButton loginBtn = new StyledButton("Sign In");
        loginBtn.setMaximumSize(new Dimension(Integer.MAX_VALUE, 42));
        loginBtn.setAlignmentX(LEFT_ALIGNMENT);
        loginBtn.addActionListener(e -> attemptLogin());
        form.add(loginBtn);
        form.add(Box.createVerticalStrut(16));



        // Register link
        JPanel regRow = new JPanel(new FlowLayout(FlowLayout.LEFT, 0, 0));
        regRow.setOpaque(false);
        regRow.setAlignmentX(LEFT_ALIGNMENT);
        JLabel noAcc = new JLabel("Don't have an account? ");
        noAcc.setFont(UIConstants.FONT_SMALL);
        JLabel regLink = new JLabel("<html><u>Register here</u></html>");
        regLink.setFont(UIConstants.FONT_SMALL);
        regLink.setForeground(UIConstants.ACCENT);
        regLink.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        regLink.addMouseListener(new MouseAdapter() {
            @Override public void mouseClicked(MouseEvent e) {
                if (onRegister != null) onRegister.run();
            }
        });
        regRow.add(noAcc);
        regRow.add(regLink);
        form.add(regRow);

        // Allow Enter key to submit
        Action loginAction = new AbstractAction() {
            @Override public void actionPerformed(ActionEvent e) { attemptLogin(); }
        };
        emailField.getField().addActionListener(loginAction);

        formWrapper.add(form);
        add(brandPanel);
        add(formWrapper);
    }

    // ----------------------------------------------------------------
    private void attemptLogin() {
        String email = emailField.getText().trim();
        String password = passwordField.getPassword();

        if (email.isEmpty() || password.isEmpty()) {
            errorLabel.setText("Email and password are required.");
            return;
        }

        errorLabel.setText("Signing in…");

        SwingWorker<User, Void> worker = new SwingWorker<>() {
            @Override
            protected User doInBackground() throws Exception {
                return authService.login(email, password);
            }
            @Override
            protected void done() {
                try {
                    get(); // throws if doInBackground threw
                    errorLabel.setText(" ");
                    if (onLoginSuccess != null) onLoginSuccess.run();
                } catch (Exception ex) {
                    String msg = ex.getCause() != null
                        ? ex.getCause().getMessage() : ex.getMessage();
                    errorLabel.setText(msg != null ? msg : "Login failed.");
                }
            }
        };
        worker.execute();
    }

    /** Pre-fills the email field (used when redirecting from registration). */
    public void setEmail(String email) {
        emailField.setText(email);
    }
}
