package skillswap.ui.screens;

import skillswap.model.*;
import skillswap.service.*;
import skillswap.ui.components.*;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.List;

/**
 * Admin screen — manage users, view all feedback, moderate listings.
 *
 * OOP CONCEPT: displayDashboard() called on Administrator object (polymorphism).
 * Only shown when logged-in user is an Administrator.
 */
public class AdminScreen extends JPanel {

    private final Administrator admin;
    private final UserService    userService     = new UserService();
    private final FeedbackService feedbackService = new FeedbackService();
    private final JFrame         parentFrame;

    // ----------------------------------------------------------------
    public AdminScreen(Administrator admin, JFrame parentFrame) {
        this.admin       = admin;
        this.parentFrame = parentFrame;

        // OOP CONCEPT: Polymorphism — calls Administrator.displayDashboard()
        admin.displayDashboard();

        setLayout(new BorderLayout());
        setOpaque(false);
        setBorder(BorderFactory.createEmptyBorder(
            UIConstants.PAD_LG, UIConstants.PAD_LG,
            UIConstants.PAD_LG, UIConstants.PAD_LG));

        JLabel title = new JLabel("Admin Panel");
        title.setFont(UIConstants.FONT_H2);
        title.setBorder(BorderFactory.createEmptyBorder(0, 0, 16, 0));
        add(title, BorderLayout.NORTH);

        JTabbedPane tabs = new JTabbedPane();
        tabs.setFont(UIConstants.FONT_BODY);
        tabs.addTab("👥 Users",       buildUsersTab());
        tabs.addTab("⭐ Feedback",     buildFeedbackTab());
        add(tabs, BorderLayout.CENTER);
    }

    // ----------------------------------------------------------------
    private JPanel buildUsersTab() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setOpaque(false);

        String[] cols = {"ID", "Name", "Email", "Role", "Department", "Year", "Credits", "Actions"};
        DefaultTableModel model = new DefaultTableModel(cols, 0) {
            @Override public boolean isCellEditable(int r, int c) { return false; }
        };

        JTable table = new JTable(model);
        table.setFont(UIConstants.FONT_SMALL);
        table.setRowHeight(36);
        table.getTableHeader().setFont(UIConstants.FONT_BOLD);
        table.setShowGrid(false);
        table.setIntercellSpacing(new Dimension(0, 4));
        table.setFillsViewportHeight(true);

        // Custom renderer for Role column
        table.getColumnModel().getColumn(3).setCellRenderer(
            (t, value, sel, foc, row, col) -> {
                JLabel lbl = new JLabel(value != null ? value.toString() : "");
                lbl.setFont(UIConstants.FONT_SMALL);
                lbl.setForeground("ADMIN".equals(value) ? UIConstants.ACCENT : UIConstants.SUCCESS);
                return lbl;
            });

        int[] widths = {40, 130, 160, 70, 120, 50, 70, 120};
        for (int c = 0; c < widths.length; c++) {
            table.getColumnModel().getColumn(c).setPreferredWidth(widths[c]);
        }

        JPanel toolbar = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 8));
        toolbar.setOpaque(false);
        StyledButton refreshBtn = new StyledButton("Refresh", StyledButton.Variant.OUTLINE);
        refreshBtn.addActionListener(e -> loadUsers(model, table));
        toolbar.add(refreshBtn);
        panel.add(toolbar, BorderLayout.NORTH);

        JScrollPane scroll = new JScrollPane(table);
        scroll.setOpaque(false);
        scroll.getViewport().setOpaque(false);
        scroll.setBorder(BorderFactory.createEmptyBorder());
        panel.add(scroll, BorderLayout.CENTER);

        // Delete selected row
        StyledButton deleteBtn = new StyledButton("Delete Selected User", StyledButton.Variant.DANGER);
        deleteBtn.addActionListener(e -> {
            int row = table.getSelectedRow();
            if (row < 0) { Toast.warning(parentFrame, "Select a user first."); return; }
            int userId = (int) model.getValueAt(row, 0);
            String name = (String) model.getValueAt(row, 1);
            if ("ADMIN".equals(model.getValueAt(row, 3))) {
                Toast.error(parentFrame, "Cannot delete an admin account."); return;
            }
            if (ConfirmDialog.show(parentFrame, "Delete User",
                    "Permanently delete user <b>" + name + "</b>? This cannot be undone.")) {
                userService.deleteUser(userId);
                loadUsers(model, table);
                Toast.success(parentFrame, "User deleted.");
            }
        });
        JPanel bottom = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        bottom.setOpaque(false);
        bottom.add(deleteBtn);
        panel.add(bottom, BorderLayout.SOUTH);

        loadUsers(model, table);
        return panel;
    }

    private void loadUsers(DefaultTableModel model, JTable table) {
        SwingWorker<List<User>, Void> w = new SwingWorker<>() {
            @Override protected List<User> doInBackground() {
                return userService.getAllUsers();
            }
            @Override protected void done() {
                try {
                    model.setRowCount(0);
                    for (User u : get()) {
                        int credits = (u instanceof Student s) ? s.getCreditBalance() : 0;
                        model.addRow(new Object[]{
                            u.getUserId(), u.getName(), u.getEmail(),
                            u.getRole(), u.getDepartment(), u.getYearOfStudy(),
                            credits, "Actions"
                        });
                    }
                } catch (Exception ex) { ex.printStackTrace(); }
            }
        };
        w.execute();
    }

    // ----------------------------------------------------------------
    private JPanel buildFeedbackTab() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setOpaque(false);

        JLabel note = new JLabel("All platform feedback — click 'Remove' to moderate.");
        note.setFont(UIConstants.FONT_SMALL);
        note.setForeground(ThemeManager.resolve(
            UIConstants.TEXT_MUTED_LIGHT, UIConstants.TEXT_MUTED_DARK));
        note.setBorder(BorderFactory.createEmptyBorder(8, 0, 8, 0));
        panel.add(note, BorderLayout.NORTH);

        // Simple list of received feedback for the admin account (demo: admin sees all via join)
        JLabel placeholder = new JLabel(
            "Feedback moderation: select a user in the Users tab to view their reviews.",
            SwingConstants.CENTER);
        placeholder.setFont(UIConstants.FONT_BODY);
        panel.add(placeholder, BorderLayout.CENTER);

        return panel;
    }
}
