package skillswap.ui.screens;

import skillswap.model.*;
import skillswap.service.*;
import skillswap.ui.components.*;

import javax.swing.*;
import javax.swing.table.*;
import java.awt.*;
import java.util.List;

/**
 * Booking History screen — tabs: Pending | Upcoming | Completed | Cancelled
 *
 * Each tab contains a JTable with coloured status pills.
 * Confirmed sessions show Confirm / Complete / Cancel action buttons.
 *
 * OOP CONCEPT: SwingWorker keeps UI responsive. Status transitions use
 * BookingStatus.canTransitionTo() (enum encapsulation).
 */
public class BookingHistoryScreen extends JPanel {

    private final Student        student;
    private final BookingService bookingService  = new BookingService();
    private final CreditService  creditService   = new CreditService();
    private final FeedbackService feedbackService = new FeedbackService();
    private final JFrame         parentFrame;
    private final Runnable       onCreditsChanged;

    private final JTabbedPane tabs;

    // ----------------------------------------------------------------
    public BookingHistoryScreen(Student student, JFrame parentFrame,
                                 Runnable onCreditsChanged) {
        this.student          = student;
        this.parentFrame      = parentFrame;
        this.onCreditsChanged = onCreditsChanged;

        setLayout(new BorderLayout());
        setOpaque(false);
        setBorder(BorderFactory.createEmptyBorder(
            UIConstants.PAD_LG, UIConstants.PAD_LG,
            UIConstants.PAD_LG, UIConstants.PAD_LG));

        JLabel title = new JLabel("Booking History");
        title.setFont(UIConstants.FONT_H2);
        title.setBorder(BorderFactory.createEmptyBorder(0, 0, 16, 0));
        add(title, BorderLayout.NORTH);

        tabs = new JTabbedPane(JTabbedPane.TOP);
        tabs.setFont(UIConstants.FONT_BODY);
        add(tabs, BorderLayout.CENTER);

        loadAll();
    }

    // ----------------------------------------------------------------
    public void loadAll() {
        SwingWorker<List<SessionBooking>[], Void> worker = new SwingWorker<>() {
            @Override
            protected List<SessionBooking>[] doInBackground() {
                @SuppressWarnings("unchecked")
                List<SessionBooking>[] result = new List[4];
                result[0] = bookingService.getBookingsByStatus(student.getUserId(), BookingStatus.REQUESTED);
                result[1] = bookingService.getBookingsByStatus(student.getUserId(), BookingStatus.CONFIRMED);
                result[2] = bookingService.getBookingsByStatus(student.getUserId(), BookingStatus.COMPLETED);
                result[3] = bookingService.getBookingsByStatus(student.getUserId(), BookingStatus.CANCELLED);
                return result;
            }
            @Override
            protected void done() {
                try {
                    List<SessionBooking>[] data = get();
                    tabs.removeAll();
                    tabs.addTab("⏳ Pending ("   + data[0].size() + ")", buildTab(data[0]));
                    tabs.addTab("📅 Upcoming ("  + data[1].size() + ")", buildTab(data[1]));
                    tabs.addTab("✅ Completed (" + data[2].size() + ")", buildTab(data[2]));
                    tabs.addTab("❌ Cancelled (" + data[3].size() + ")", buildTab(data[3]));
                    tabs.revalidate();
                } catch (Exception ex) { ex.printStackTrace(); }
            }
        };
        worker.execute();
    }

    // ----------------------------------------------------------------
    private JPanel buildTab(List<SessionBooking> bookings) {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setOpaque(false);

        if (bookings.isEmpty()) {
            JLabel empty = new JLabel("No sessions in this category.", SwingConstants.CENTER);
            empty.setFont(UIConstants.FONT_BODY);
            empty.setForeground(ThemeManager.resolve(
                UIConstants.TEXT_MUTED_LIGHT, UIConstants.TEXT_MUTED_DARK));
            panel.add(empty, BorderLayout.CENTER);
            return panel;
        }

        // Table columns
        String[] cols = {"#", "Partner", "Skill", "Date", "Time", "Duration", "Role", "Status", "Actions"};
        Object[][] rows = new Object[bookings.size()][cols.length];

        for (int i = 0; i < bookings.size(); i++) {
            SessionBooking b = bookings.get(i);
            boolean isTeacher = b.getProviderId() == student.getUserId();
            rows[i][0] = b.getBookingId();
            rows[i][1] = isTeacher ? b.getRequesterName() : b.getProviderName();
            rows[i][2] = b.getSkill().getName();
            rows[i][3] = b.getSessionDate();
            rows[i][4] = b.getSessionTime();
            rows[i][5] = b.getDurationMinutes() + " min";
            rows[i][6] = isTeacher ? "Teaching" : "Learning";
            rows[i][7] = b.getStatus();
            rows[i][8] = b;  // pass full booking for action rendering
        }

        DefaultTableModel model = new DefaultTableModel(rows, cols) {
            @Override public boolean isCellEditable(int r, int c) { return false; }
        };

        JTable table = new JTable(model);
        table.setFont(UIConstants.FONT_SMALL);
        table.setRowHeight(40);
        table.getTableHeader().setFont(UIConstants.FONT_BOLD);
        table.setShowGrid(false);
        table.setIntercellSpacing(new Dimension(0, 4));
        table.setFillsViewportHeight(true);

        // Custom renderer for Status column (pill)
        table.getColumnModel().getColumn(7).setCellRenderer(
            (t, value, sel, foc, row, col) -> {
                if (value instanceof BookingStatus status) {
                    return StatusPill.forStatus(status);
                }
                return new JLabel(value != null ? value.toString() : "");
            });

        // Custom renderer + editor for Actions column
        table.getColumnModel().getColumn(8).setCellRenderer(
            (t, value, sel, foc, row, col) -> buildActionPanel((SessionBooking) value));
        table.getColumnModel().getColumn(8).setCellEditor(
            new BookingActionEditor(parentFrame));

        // Column widths
        int[] widths = {40, 120, 110, 100, 70, 80, 80, 90, 200};
        for (int c = 0; c < widths.length; c++) {
            table.getColumnModel().getColumn(c).setPreferredWidth(widths[c]);
        }

        JScrollPane scroll = new JScrollPane(table);
        scroll.setOpaque(false);
        scroll.getViewport().setOpaque(false);
        scroll.setBorder(BorderFactory.createEmptyBorder());
        panel.add(scroll, BorderLayout.CENTER);
        return panel;
    }

    // ----------------------------------------------------------------
    private JPanel buildActionPanel(SessionBooking b) {
        JPanel panel = new JPanel(new FlowLayout(FlowLayout.LEFT, 4, 4));
        panel.setOpaque(false);

        BookingStatus status = b.getStatus();
        boolean isProvider   = b.getProviderId() == student.getUserId();

        // REQUESTED → Provider can Confirm; either can Cancel
        if (status == BookingStatus.REQUESTED) {
            if (isProvider) {
                StyledButton confirmBtn = new StyledButton("Confirm",
                    StyledButton.Variant.PRIMARY);
                confirmBtn.setFont(UIConstants.FONT_SMALL);
                confirmBtn.addActionListener(e -> {
                    try {
                        bookingService.confirmBooking(b.getBookingId());
                        Toast.success(parentFrame, "Session confirmed!");
                        loadAll();
                    } catch (Exception ex) { Toast.error(parentFrame, ex.getMessage()); }
                });
                panel.add(confirmBtn);
            }
            addCancelBtn(panel, b);
        }

        // CONFIRMED → Provider can Complete; either can Cancel
        if (status == BookingStatus.CONFIRMED) {
            if (isProvider) {
                StyledButton completeBtn = new StyledButton("Complete",
                    StyledButton.Variant.PRIMARY);
                completeBtn.setFont(UIConstants.FONT_SMALL);
                completeBtn.addActionListener(e -> {
                    try {
                        bookingService.completeBooking(b.getBookingId());
                        // Award credits automatically
                        creditService.awardCredits(b.getBookingId());
                        // Refresh student credit balance
                        student.setCreditBalance(
                            creditService.getBalance(student.getUserId()));
                        if (onCreditsChanged != null) onCreditsChanged.run();
                        Toast.success(parentFrame, "Session completed! +10 credits awarded.");
                        loadAll();
                    } catch (Exception ex) { Toast.error(parentFrame, ex.getMessage()); }
                });
                panel.add(completeBtn);
            }
            addCancelBtn(panel, b);
        }

        // COMPLETED → can Leave Feedback (if not already done)
        if (status == BookingStatus.COMPLETED) {
            int revieweeId = isProvider ? b.getRequesterId() : b.getProviderId();
            boolean alreadyReviewed = feedbackService.hasReviewed(
                b.getBookingId(), student.getUserId());
            if (!alreadyReviewed) {
                StyledButton rateBtn = new StyledButton("Leave Review",
                    StyledButton.Variant.OUTLINE);
                rateBtn.setFont(UIConstants.FONT_SMALL);
                rateBtn.addActionListener(e -> showRatingDialog(b, revieweeId));
                panel.add(rateBtn);
            } else {
                JLabel done = new JLabel("✓ Reviewed");
                done.setFont(UIConstants.FONT_SMALL);
                done.setForeground(UIConstants.SUCCESS);
                panel.add(done);
            }
        }

        return panel;
    }

    private void addCancelBtn(JPanel panel, SessionBooking b) {
        StyledButton cancelBtn = new StyledButton("Cancel", StyledButton.Variant.DANGER);
        cancelBtn.setFont(UIConstants.FONT_SMALL);
        cancelBtn.addActionListener(e -> {
            String reason = ConfirmDialog.showWithReason(parentFrame,
                "Cancel Session",
                "Are you sure you want to cancel this session?");
            if (reason != null) {
                try {
                    bookingService.cancelBooking(b.getBookingId(), reason);
                    Toast.info(parentFrame, "Session cancelled.");
                    loadAll();
                } catch (Exception ex) { Toast.error(parentFrame, ex.getMessage()); }
            }
        });
        panel.add(cancelBtn);
    }

    private void showRatingDialog(SessionBooking b, int revieweeId) {
        JDialog dlg = new JDialog(parentFrame, "Leave a Review", true);
        dlg.setSize(400, 300);
        dlg.setLocationRelativeTo(parentFrame);

        JPanel content = new JPanel();
        content.setLayout(new BoxLayout(content, BoxLayout.Y_AXIS));
        content.setBorder(BorderFactory.createEmptyBorder(24, 28, 24, 28));

        JLabel heading = new JLabel("How was your session?");
        heading.setFont(UIConstants.FONT_H3);
        heading.setAlignmentX(LEFT_ALIGNMENT);
        content.add(heading);
        content.add(Box.createVerticalStrut(16));

        JLabel rateLbl = new JLabel("Rating");
        rateLbl.setFont(UIConstants.FONT_SMALL);
        rateLbl.setForeground(UIConstants.TEXT_MUTED_LIGHT);
        rateLbl.setAlignmentX(LEFT_ALIGNMENT);
        content.add(rateLbl);

        final int[] selectedRating = {3};
        StarRatingPanel stars = new StarRatingPanel(3, true,
            r -> selectedRating[0] = r);
        stars.setAlignmentX(LEFT_ALIGNMENT);
        content.add(stars);
        content.add(Box.createVerticalStrut(12));

        JLabel commentLbl = new JLabel("Comment (optional)");
        commentLbl.setFont(UIConstants.FONT_SMALL);
        commentLbl.setForeground(UIConstants.TEXT_MUTED_LIGHT);
        commentLbl.setAlignmentX(LEFT_ALIGNMENT);
        content.add(commentLbl);

        JTextArea commentArea = new JTextArea(3, 30);
        commentArea.setLineWrap(true);
        commentArea.setWrapStyleWord(true);
        JScrollPane commentScroll = new JScrollPane(commentArea);
        commentScroll.setMaximumSize(new Dimension(Integer.MAX_VALUE, 80));
        commentScroll.setAlignmentX(LEFT_ALIGNMENT);
        content.add(commentScroll);
        content.add(Box.createVerticalStrut(12));

        JLabel errLbl = new JLabel(" ");
        errLbl.setFont(UIConstants.FONT_SMALL);
        errLbl.setForeground(UIConstants.DANGER);
        errLbl.setAlignmentX(LEFT_ALIGNMENT);
        content.add(errLbl);

        StyledButton submitBtn = new StyledButton("Submit Review");
        submitBtn.setMaximumSize(new Dimension(Integer.MAX_VALUE, 38));
        submitBtn.setAlignmentX(LEFT_ALIGNMENT);
        submitBtn.addActionListener(e -> {
            try {
                feedbackService.submitFeedback(
                    b.getBookingId(), student.getUserId(), revieweeId,
                    selectedRating[0], commentArea.getText().trim());
                dlg.dispose();
                Toast.success(parentFrame, "Review submitted!");
                loadAll();
            } catch (Exception ex) {
                errLbl.setText(ex.getMessage() != null ? ex.getMessage() : "Submission failed.");
            }
        });
        content.add(submitBtn);
        dlg.add(content);
        dlg.setVisible(true);
    }

    // ----------------------------------------------------------------
    // No-op table cell editor (needed for action buttons to be clickable in table)
    // ----------------------------------------------------------------
    private class BookingActionEditor extends DefaultCellEditor {
        BookingActionEditor(JFrame parent) {
            super(new JCheckBox());
        }
        @Override
        public Component getTableCellEditorComponent(JTable table, Object value,
                boolean sel, int row, int col) {
            return buildActionPanel((SessionBooking) value);
        }
        @Override public Object getCellEditorValue() { return null; }
    }
}
