package skillswap.ui.screens;

import skillswap.service.AuthService;
import skillswap.ui.components.*;

import javax.swing.*;
import java.awt.*;
import java.util.function.Consumer;

/**
 * Registration screen: name, email, password (with strength meter),
 * department, year of study, optional bio. Inline field validation.
 *
 * OOP CONCEPT: Encapsulation — AuthService.register() handles all
 * business-rule validation; this screen handles UX validation.
 */
public class RegisterScreen extends JPanel {

    private final AuthService    authService = new AuthService();
    private final Consumer<String> onSuccess;   // called with the registered email
    private final Runnable         onBack;

    // Form fields
    private final FormField     nameField;
    private final FormField     emailField;
    private final PasswordField passwordField;
    private final FormField     deptField;
    private final JSpinner      yearSpinner;
    private final JTextArea     bioArea;
    private final JLabel        statusLabel;

    private static final String[] DEPARTMENTS = {
        "Computer Science", "Design", "Mathematics", "Music",
        "Photography", "Languages", "Business", "Engineering",
        "Medicine", "Arts", "Other"
    };

    // ----------------------------------------------------------------
    public RegisterScreen(Consumer<String> onSuccess, Runnable onBack) {
        this.onSuccess = onSuccess;
        this.onBack    = onBack;

        setLayout(new GridBagLayout());
        setBackground(UIConstants.BG_LIGHT);

        // Card container
        RoundedPanel card = new RoundedPanel(UIConstants.ARC_CARD, null, true);
        card.setLayout(new BoxLayout(card, BoxLayout.Y_AXIS));
        card.setBorder(BorderFactory.createEmptyBorder(32, 40, 32, 40));
        card.setPreferredSize(new Dimension(500, 640));

        // Title
        JLabel title = new JLabel("Create your account");
        title.setFont(UIConstants.FONT_H2);
        title.setAlignmentX(LEFT_ALIGNMENT);
        card.add(title);

        JLabel sub = new JLabel("Join the SkillSwap community today.");
        sub.setFont(UIConstants.FONT_SMALL);
        sub.setForeground(UIConstants.TEXT_MUTED_LIGHT);
        sub.setAlignmentX(LEFT_ALIGNMENT);
        card.add(sub);
        card.add(Box.createVerticalStrut(20));

        // Name
        nameField = new FormField("Full Name *", "e.g. Aarav Sharma");
        nameField.withValidator(t -> !t.isBlank() && t.length() <= 150, "Name is required (max 150 chars)");
        nameField.setAlignmentX(LEFT_ALIGNMENT);
        nameField.setMaximumSize(new Dimension(Integer.MAX_VALUE, 80));
        card.add(nameField);
        card.add(Box.createVerticalStrut(8));

        // Email
        emailField = new FormField("Email Address *", "you@university.edu");
        emailField.withValidator(
            t -> t.matches("^[\\w._%+\\-]+@[\\w.\\-]+\\.[a-zA-Z]{2,}$"),
            "Enter a valid email address");
        emailField.setAlignmentX(LEFT_ALIGNMENT);
        emailField.setMaximumSize(new Dimension(Integer.MAX_VALUE, 80));
        card.add(emailField);
        card.add(Box.createVerticalStrut(8));

        // Password
        JLabel pwdLbl = new JLabel("Password *  (min 6 characters)");
        pwdLbl.setFont(UIConstants.FONT_SMALL);
        pwdLbl.setForeground(UIConstants.TEXT_MUTED_LIGHT);
        pwdLbl.setAlignmentX(LEFT_ALIGNMENT);
        card.add(pwdLbl);
        card.add(Box.createVerticalStrut(4));
        passwordField = new PasswordField("Choose a strong password", true);
        passwordField.setAlignmentX(LEFT_ALIGNMENT);
        passwordField.setMaximumSize(new Dimension(Integer.MAX_VALUE, 70));
        card.add(passwordField);
        card.add(Box.createVerticalStrut(8));

        // Department (row with Year)
        JPanel deptRow = new JPanel(new GridLayout(1, 2, 12, 0));
        deptRow.setOpaque(false);
        deptRow.setMaximumSize(new Dimension(Integer.MAX_VALUE, 80));
        deptRow.setAlignmentX(LEFT_ALIGNMENT);

        deptField = new FormField("Department *", "e.g. Computer Science");
        deptField.withValidator(t -> !t.isBlank(), "Department is required");
        deptRow.add(deptField);

        JPanel yearWrap = new JPanel();
        yearWrap.setOpaque(false);
        yearWrap.setLayout(new BoxLayout(yearWrap, BoxLayout.Y_AXIS));
        JLabel yearLbl = new JLabel("Year of Study *");
        yearLbl.setFont(UIConstants.FONT_SMALL);
        yearLbl.setForeground(UIConstants.TEXT_MUTED_LIGHT);
        yearLbl.setAlignmentX(LEFT_ALIGNMENT);
        yearWrap.add(yearLbl);
        yearWrap.add(Box.createVerticalStrut(4));
        yearSpinner = new JSpinner(new SpinnerNumberModel(1, 1, 10, 1));
        yearSpinner.setMaximumSize(new Dimension(Integer.MAX_VALUE, 36));
        yearWrap.add(yearSpinner);
        deptRow.add(yearWrap);
        card.add(deptRow);
        card.add(Box.createVerticalStrut(8));

        // Bio
        JLabel bioLbl = new JLabel("Short Bio (optional)");
        bioLbl.setFont(UIConstants.FONT_SMALL);
        bioLbl.setForeground(UIConstants.TEXT_MUTED_LIGHT);
        bioLbl.setAlignmentX(LEFT_ALIGNMENT);
        card.add(bioLbl);
        card.add(Box.createVerticalStrut(4));

        bioArea = new JTextArea(3, 30);
        bioArea.setFont(UIConstants.FONT_BODY);
        bioArea.setLineWrap(true);
        bioArea.setWrapStyleWord(true);
        bioArea.putClientProperty("JTextArea.showClearButton", true);
        JScrollPane bioScroll = new JScrollPane(bioArea);
        bioScroll.setMaximumSize(new Dimension(Integer.MAX_VALUE, 80));
        bioScroll.setAlignmentX(LEFT_ALIGNMENT);
        card.add(bioScroll);
        card.add(Box.createVerticalStrut(12));

        // Status label
        statusLabel = new JLabel(" ");
        statusLabel.setFont(UIConstants.FONT_SMALL);
        statusLabel.setAlignmentX(LEFT_ALIGNMENT);
        card.add(statusLabel);
        card.add(Box.createVerticalStrut(8));

        // Buttons row
        JPanel btnRow = new JPanel(new GridLayout(1, 2, 12, 0));
        btnRow.setOpaque(false);
        btnRow.setMaximumSize(new Dimension(Integer.MAX_VALUE, 42));
        btnRow.setAlignmentX(LEFT_ALIGNMENT);

        StyledButton backBtn = new StyledButton("← Back to Login", StyledButton.Variant.OUTLINE);
        backBtn.addActionListener(e -> { if (onBack != null) onBack.run(); });
        btnRow.add(backBtn);

        StyledButton registerBtn = new StyledButton("Create Account");
        registerBtn.addActionListener(e -> attemptRegister());
        btnRow.add(registerBtn);

        card.add(btnRow);

        add(card);
    }

    // ----------------------------------------------------------------
    private void attemptRegister() {
        // Gather inputs
        String name  = nameField.getText().trim();
        String email = emailField.getText().trim();
        String pwd   = passwordField.getPassword();
        String dept  = deptField.getText().trim();
        int    year  = (Integer) yearSpinner.getValue();
        String bio   = bioArea.getText().trim();

        // Front-end validation
        if (name.isBlank()) {
            showError("Name is required."); return;
        }
        if (!email.matches("^[\\w._%+\\-]+@[\\w.\\-]+\\.[a-zA-Z]{2,}$")) {
            showError("Enter a valid email address."); return;
        }
        if (pwd.length() < 6) {
            showError("Password must be at least 6 characters."); return;
        }
        if (dept.isBlank()) {
            showError("Department is required."); return;
        }

        showInfo("Creating your account…");

        SwingWorker<Void, Void> worker = new SwingWorker<>() {
            @Override
            protected Void doInBackground() throws Exception {
                authService.register(name, email, pwd, dept, year, bio);
                return null;
            }
            @Override
            protected void done() {
                try {
                    get();
                    showSuccess("Account created! You can now sign in.");
                    if (onSuccess != null) onSuccess.accept(email);
                } catch (Exception ex) {
                    String msg = ex.getCause() != null
                        ? ex.getCause().getMessage() : ex.getMessage();
                    showError(msg != null ? msg : "Registration failed.");
                }
            }
        };
        worker.execute();
    }

    private void showError  (String msg) { statusLabel.setText(msg); statusLabel.setForeground(UIConstants.DANGER);  }
    private void showSuccess(String msg) { statusLabel.setText(msg); statusLabel.setForeground(UIConstants.SUCCESS); }
    private void showInfo   (String msg) { statusLabel.setText(msg); statusLabel.setForeground(UIConstants.INFO);    }
}
