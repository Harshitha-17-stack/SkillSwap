package skillswap.ui.components;

import javax.swing.*;
import java.awt.*;

/**
 * Circular avatar showing the user's initials on a coloured background.
 * Used in the TopBar and on match/profile cards.
 *
 * OOP CONCEPT: Inheritance (extends JComponent), Method Overriding (paintComponent).
 */
public class AvatarCircle extends JComponent {

    private static final Color[] PALETTE = {
        new Color(0x6C5CE7), new Color(0x00B894), new Color(0xFDAB32),
        new Color(0xFF7675), new Color(0x74B9FF), new Color(0xA29BFE),
        new Color(0xFD79A8), new Color(0x55EFC4)
    };

    private String  initials;
    private Color   bgColor;
    private int     size;
    private Font    font;

    // ----------------------------------------------------------------
    public AvatarCircle(String fullName, int size) {
        this.initials = extractInitials(fullName);
        this.size     = size;
        this.bgColor  = pickColor(fullName);
        this.font     = new Font("Segoe UI", Font.BOLD, size / 3);
        setPreferredSize(new Dimension(size, size));
        setMinimumSize(new Dimension(size, size));
        setMaximumSize(new Dimension(size, size));
    }

    @Override
    protected void paintComponent(Graphics g) {
        Graphics2D g2 = (Graphics2D) g.create();
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

        // Circle background
        g2.setColor(bgColor);
        g2.fillOval(0, 0, size - 1, size - 1);

        // Initials text, centred
        g2.setFont(font);
        g2.setColor(Color.WHITE);
        FontMetrics fm = g2.getFontMetrics();
        int tx = (size - fm.stringWidth(initials)) / 2;
        int ty = (size - fm.getHeight()) / 2 + fm.getAscent();
        g2.drawString(initials, tx, ty);

        g2.dispose();
    }

    // ----------------------------------------------------------------
    private String extractInitials(String name) {
        if (name == null || name.isBlank()) return "?";
        String[] parts = name.trim().split("\\s+");
        if (parts.length == 1) return parts[0].substring(0, 1).toUpperCase();
        return (parts[0].substring(0, 1)
              + parts[parts.length - 1].substring(0, 1)).toUpperCase();
    }

    /** Deterministic colour pick from the palette based on name hash. */
    private Color pickColor(String name) {
        int idx = Math.abs((name == null ? 0 : name.hashCode())) % PALETTE.length;
        return PALETTE[idx];
    }

    public void setName(String name) {
        this.initials = extractInitials(name);
        this.bgColor  = pickColor(name);
        repaint();
    }
}
