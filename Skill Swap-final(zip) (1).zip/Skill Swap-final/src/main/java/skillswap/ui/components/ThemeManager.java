package skillswap.ui.components;

import com.formdev.flatlaf.FlatDarkLaf;
import com.formdev.flatlaf.FlatLightLaf;
import skillswap.util.AppPreferences;

import javax.swing.*;
import java.awt.*;

/**
 * Manages light/dark theme switching at runtime.
 * Calls SwingUtilities.updateComponentTreeUI() to repaint all open windows.
 *
 * OOP CONCEPT: Encapsulation — theme-swap details hidden behind a static method.
 */
public final class ThemeManager {

    private ThemeManager() {}

    /**
     * Toggles between light and dark FlatLaf themes,
     * saves the preference, and repaints all windows.
     *
     * @return true if the new theme is dark
     */
    public static boolean toggleTheme() {
        boolean nowDark = !AppPreferences.isDarkTheme();
        applyTheme(nowDark);
        AppPreferences.setDarkTheme(nowDark);
        return nowDark;
    }

    /** Applies the specified theme without toggling. */
    public static void applyTheme(boolean dark) {
        try {
            if (dark) {
                FlatDarkLaf.setup();
            } else {
                FlatLightLaf.setup();
            }
            applyGlobalDefaults();
            // Refresh every open Swing window
            for (Window w : Window.getWindows()) {
                SwingUtilities.updateComponentTreeUI(w);
                w.revalidate();
                w.repaint();
            }
        } catch (Exception e) {
            System.err.println("[Theme] Failed to apply theme: " + e.getMessage());
        }
    }

    private static void applyGlobalDefaults() {
        UIManager.put("Button.arc",        UIConstants.ARC_BUTTON);
        UIManager.put("Component.arc",     UIConstants.ARC_CARD);
        UIManager.put("TextComponent.arc", 10);
        UIManager.put("ScrollBar.thumbArc",999);
        UIManager.put("defaultFont", UIConstants.FONT_BODY);
    }

    public static boolean isDark() {
        return AppPreferences.isDarkTheme();
    }

    /**
     * Returns the appropriate colour depending on current theme.
     * Convenience helper used by custom-painted components.
     */
    public static Color resolve(Color light, Color dark) {
        return isDark() ? dark : light;
    }
}
