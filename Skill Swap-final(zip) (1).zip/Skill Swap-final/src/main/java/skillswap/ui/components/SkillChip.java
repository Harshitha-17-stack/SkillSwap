package skillswap.ui.components;

import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

/**
 * A rounded chip/tag showing a skill name with an optional × remove button.
 *
 * Used in "My Skills" panel and match cards.
 * OOP CONCEPT: Inheritance (extends JPanel), Encapsulation, Observer (Runnable callback).
 */
public class SkillChip extends JPanel {

    private final String  label;
    private       Color   chipColor;
    private       boolean removable;
    private       Runnable onRemove;

    // ----------------------------------------------------------------
    /** Display-only chip (no remove button). */
    public SkillChip(String label, Color chipColor) {
        this(label, chipColor, false, null);
    }

    /** Removable chip (shows × button, fires onRemove when clicked). */
    public SkillChip(String label, Color chipColor, boolean removable, Runnable onRemove) {
        this.label     = label;
        this.chipColor = chipColor;
        this.removable = removable;
        this.onRemove  = onRemove;
        build();
    }

    private void build() {
        setOpaque(false);
        setLayout(new FlowLayout(FlowLayout.LEFT, 6, 2));

        // Skill name label — slight transparency on the chip background
        JLabel nameLabel = new JLabel(label);
        nameLabel.setFont(UIConstants.FONT_SMALL);
        nameLabel.setForeground(chipColor.darker().darker());
        add(nameLabel);

        if (removable && onRemove != null) {
            JLabel removeBtn = new JLabel("×");
            removeBtn.setFont(UIConstants.FONT_BOLD);
            removeBtn.setForeground(chipColor.darker());
            removeBtn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
            removeBtn.addMouseListener(new MouseAdapter() {
                @Override public void mouseClicked(MouseEvent e) { onRemove.run(); }
            });
            add(removeBtn);
        }
    }

    @Override
    protected void paintComponent(Graphics g) {
        Graphics2D g2 = (Graphics2D) g.create();
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

        // Light tinted background
        Color bg = new Color(chipColor.getRed(), chipColor.getGreen(),
                             chipColor.getBlue(), 35);
        g2.setColor(bg);
        g2.fillRoundRect(0, 0, getWidth(), getHeight(),
                         UIConstants.ARC_CHIP, UIConstants.ARC_CHIP);

        // Border
        g2.setColor(new Color(chipColor.getRed(), chipColor.getGreen(),
                              chipColor.getBlue(), 120));
        g2.setStroke(new BasicStroke(1.0f));
        g2.drawRoundRect(0, 0, getWidth() - 1, getHeight() - 1,
                         UIConstants.ARC_CHIP, UIConstants.ARC_CHIP);

        g2.dispose();
        super.paintComponent(g);
    }

    @Override
    public Dimension getPreferredSize() {
        Dimension d = super.getPreferredSize();
        return new Dimension(d.width + 8, d.height + 2);
    }
}
