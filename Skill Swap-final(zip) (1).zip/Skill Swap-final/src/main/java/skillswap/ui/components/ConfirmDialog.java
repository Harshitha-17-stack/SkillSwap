package skillswap.ui.components;

import javax.swing.*;
import java.awt.*;

/**
 * Reusable confirmation dialog with a custom message and Confirm/Cancel buttons.
 * Returns true if the user confirmed, false otherwise.
 *
 * OOP CONCEPT: Encapsulation — dialog construction details hidden in static factory.
 */
public final class ConfirmDialog {

    private ConfirmDialog() {}

    /**
     * Shows a modal confirmation dialog centred on the parent frame.
     *
     * @param parent  the owning frame
     * @param title   dialog title
     * @param message question to ask
     * @return true if the user clicked "Confirm"
     */
    public static boolean show(JFrame parent, String title, String message) {
        int result = JOptionPane.showOptionDialog(
            parent,
            buildMessagePanel(message),
            title,
            JOptionPane.YES_NO_OPTION,
            JOptionPane.QUESTION_MESSAGE,
            null,
            new Object[]{"Confirm", "Cancel"},
            "Cancel"
        );
        return result == JOptionPane.YES_OPTION;
    }

    /**
     * Overload: shows the dialog and also collects a reason text field.
     * Used for cancellation dialogs.
     *
     * @return the entered reason, or null if cancelled
     */
    public static String showWithReason(JFrame parent, String title, String message) {
        JTextField reasonField = new JTextField(30);
        reasonField.putClientProperty("JTextField.placeholderText", "Enter reason (required)");

        JPanel panel = new JPanel(new BorderLayout(0, 8));
        panel.add(new JLabel("<html>" + message + "</html>"), BorderLayout.NORTH);
        panel.add(reasonField, BorderLayout.CENTER);

        int result = JOptionPane.showOptionDialog(
            parent, panel, title,
            JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE,
            null, new Object[]{"Confirm", "Cancel"}, "Cancel"
        );

        if (result != JOptionPane.YES_OPTION) return null;
        String reason = reasonField.getText().trim();
        return reason.isBlank() ? null : reason;
    }

    private static JPanel buildMessagePanel(String message) {
        JPanel p = new JPanel(new BorderLayout());
        p.setOpaque(false);
        JLabel lbl = new JLabel("<html><body style='width:280px'>" + message + "</body></html>");
        lbl.setFont(UIConstants.FONT_BODY);
        p.add(lbl);
        return p;
    }
}
