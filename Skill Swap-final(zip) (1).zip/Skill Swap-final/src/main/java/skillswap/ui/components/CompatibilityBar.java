package skillswap.ui.components;

import javax.swing.*;
import java.awt.*;

/**
 * Horizontal progress bar that shows a compatibility % score.
 * Colour shifts from orange (low) → green (high).
 *
 * OOP CONCEPT: Inheritance (extends JPanel), Method Overriding (paintComponent).
 */
public class CompatibilityBar extends JPanel {

    private int score;   // 0–100

    public CompatibilityBar(int score) {
        this.score = Math.max(0, Math.min(100, score));
        setOpaque(false);
        setPreferredSize(new Dimension(200, 10));
    }

    @Override
    protected void paintComponent(Graphics g) {
        Graphics2D g2 = (Graphics2D) g.create();
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

        int w = getWidth();
        int h = getHeight();
        int filled = (int) (w * score / 100.0);

        // Track (background)
        g2.setColor(ThemeManager.resolve(UIConstants.BORDER_LIGHT, UIConstants.BORDER_DARK));
        g2.fillRoundRect(0, 0, w, h, h, h);

        // Fill
        if (filled > 0) {
            Color fill = score >= 85 ? UIConstants.SUCCESS
                       : score >= 50 ? UIConstants.WARNING
                       : UIConstants.DANGER;
            g2.setColor(fill);
            g2.fillRoundRect(0, 0, filled, h, h, h);
        }

        g2.dispose();
    }

    public void setScore(int score) {
        this.score = Math.max(0, Math.min(100, score));
        repaint();
    }

    public int getScore() { return score; }
}
