package skillswap.ui.components;

import javax.swing.*;
import java.awt.*;
import java.awt.geom.RoundRectangle2D;

/**
 * A JPanel with rounded corners, a solid background, and an optional
 * drop-shadow effect — used as the base "card" across all screens.
 *
 * OOP CONCEPT: Inheritance — extends JPanel and overrides paintComponent().
 * Encapsulation — corner radius, bg colour, shadow flag are all configurable
 *                 through the constructor; internals are private.
 */
public class RoundedPanel extends JPanel {

    private int   arc;
    private Color bgColor;
    private boolean shadow;

    // ----------------------------------------------------------------
    // Constructors — method overloading
    // ----------------------------------------------------------------

    /** Default card style — system background colour, 16px arc, with shadow. */
    public RoundedPanel() {
        this(UIConstants.ARC_CARD, null, true);
    }

    public RoundedPanel(int arc) {
        this(arc, null, true);
    }

    public RoundedPanel(int arc, Color bgColor) {
        this(arc, bgColor, true);
    }

    public RoundedPanel(int arc, Color bgColor, boolean shadow) {
        super();
        this.arc     = arc;
        this.bgColor = bgColor;
        this.shadow  = shadow;
        setOpaque(false);        // let our custom painting handle the background
    }

    // ----------------------------------------------------------------
    // OOP CONCEPT: Method Overriding — paintComponent replaces JPanel's default
    // ----------------------------------------------------------------
    @Override
    protected void paintComponent(Graphics g) {
        Graphics2D g2 = (Graphics2D) g.create();

        // Smooth anti-aliasing for rounded corners
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING,
                            RenderingHints.VALUE_ANTIALIAS_ON);
        g2.setRenderingHint(RenderingHints.KEY_RENDERING,
                            RenderingHints.VALUE_RENDER_QUALITY);

        int w = getWidth();
        int h = getHeight();

        // Optional drop shadow (4px down, 40% opacity black)
        if (shadow) {
            g2.setColor(new Color(0, 0, 0, 25));
            g2.fillRoundRect(3, 5, w - 6, h - 4, arc, arc);
        }

        // Card background
        Color bg = bgColor != null ? bgColor
                 : ThemeManager.resolve(UIConstants.SURFACE_LIGHT, UIConstants.SURFACE_DARK);
        g2.setColor(bg);
        g2.fillRoundRect(0, 0, w - 4, h - 4, arc, arc);

        g2.dispose();
        super.paintComponent(g);
    }

    // ----------------------------------------------------------------
    // Setters for dynamic theming
    // ----------------------------------------------------------------
    public void setArc(int arc)           { this.arc = arc;       repaint(); }
    public void setBgColor(Color color)   { this.bgColor = color; repaint(); }
    public void setShadow(boolean shadow) { this.shadow = shadow; repaint(); }
    public Color getBgColor()             { return bgColor; }
}
