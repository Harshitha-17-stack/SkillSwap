package skillswap.ui.components;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;

/**
 * Non-blocking toast / snackbar notification that appears at the bottom-centre
 * of the parent frame for 2.5 seconds then fades out.
 *
 * Usage:
 *   Toast.show(parentFrame, "Session booked!", Toast.Type.SUCCESS);
 *   Toast.show(parentFrame, "Invalid email.", Toast.Type.ERROR);
 *
 * OOP CONCEPT: Encapsulation — timing and animation logic private.
 *              Static factory method hides construction details.
 */
public class Toast extends JWindow {

    public enum Type { SUCCESS, ERROR, INFO, WARNING }

    private static final int DURATION_MS = 2500;
    private static final int FADE_STEPS  = 20;
    private static final int FADE_DELAY  = 15;   // ms per step

    private float opacity = 1.0f;

    // ----------------------------------------------------------------
    private Toast(JFrame parent, String message, Type type) {
        super(parent);

        // Background colour per type
        Color bg = switch (type) {
            case SUCCESS -> UIConstants.SUCCESS;
            case ERROR   -> UIConstants.DANGER;
            case WARNING -> UIConstants.WARNING;
            case INFO    -> UIConstants.ACCENT;
        };

        // Build the toast panel
        JPanel panel = new JPanel(new FlowLayout(FlowLayout.LEFT, 16, 10));
        panel.setBackground(bg);
        panel.setBorder(BorderFactory.createEmptyBorder(4, 8, 4, 8));

        // Icon prefix
        String icon = switch (type) {
            case SUCCESS -> "✓";
            case ERROR   -> "✕";
            case WARNING -> "⚠";
            case INFO    -> "ℹ";
        };

        JLabel iconLabel = new JLabel(icon);
        iconLabel.setFont(new Font("Segoe UI", Font.BOLD, 16));
        iconLabel.setForeground(Color.WHITE);
        panel.add(iconLabel);

        JLabel textLabel = new JLabel(message);
        textLabel.setFont(UIConstants.FONT_BODY);
        textLabel.setForeground(Color.WHITE);
        panel.add(textLabel);

        add(panel);
        pack();

        // Position at bottom-centre of parent
        if (parent != null) {
            int px = parent.getX() + (parent.getWidth()  - getWidth())  / 2;
            int py = parent.getY() +  parent.getHeight() - getHeight() - 60;
            setLocation(px, py);
        }

        setOpacity(1.0f);
    }

    // ----------------------------------------------------------------
    // Static factory — the only public entry point
    // ----------------------------------------------------------------

    /**
     * Shows a toast message and schedules its dismissal.
     * Safe to call from the EDT.
     */
    public static void show(JFrame parent, String message, Type type) {
        SwingUtilities.invokeLater(() -> {
            Toast toast = new Toast(parent, message, type);
            toast.setVisible(true);

            // Auto-dismiss after DURATION_MS
            Timer dismissTimer = new Timer(DURATION_MS, null);
            dismissTimer.addActionListener((ActionEvent e) -> {
                dismissTimer.stop();
                toast.fadeOut();
            });
            dismissTimer.setRepeats(false);
            dismissTimer.start();
        });
    }

    /** Convenience overloads */
    public static void success(JFrame p, String msg) { show(p, msg, Type.SUCCESS); }
    public static void error  (JFrame p, String msg) { show(p, msg, Type.ERROR);   }
    public static void info   (JFrame p, String msg) { show(p, msg, Type.INFO);    }
    public static void warning(JFrame p, String msg) { show(p, msg, Type.WARNING); }

    // ----------------------------------------------------------------
    private void fadeOut() {
        Timer fadeTimer = new Timer(FADE_DELAY, null);
        fadeTimer.addActionListener(e -> {
            opacity -= 1.0f / FADE_STEPS;
            if (opacity <= 0) {
                ((Timer) e.getSource()).stop();
                dispose();
            } else {
                try { setOpacity(Math.max(0.0f, opacity)); }
                catch (Exception ignored) {}
            }
        });
        fadeTimer.start();
    }
}
