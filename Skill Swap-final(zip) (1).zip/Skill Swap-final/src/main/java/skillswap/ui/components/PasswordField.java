package skillswap.ui.components;

import skillswap.util.ValidationUtils;

import javax.swing.*;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import java.awt.*;

/**
 * Password input with:
 *   - Show/hide toggle (👁 button)
 *   - Optional password strength meter
 *
 * OOP CONCEPT: Encapsulation — strength logic is private, callers just call getPassword().
 *              Composition — PasswordField HAS-A JPasswordField + toggle button + strength bar.
 */
public class PasswordField extends JPanel {

    private final JPasswordField pwdField;
    private final JLabel         strengthLabel;
    private final JPanel         strengthBar;
    private       boolean        showStrength;

    // ----------------------------------------------------------------
    public PasswordField(String placeholder, boolean showStrength) {
        this.showStrength = showStrength;
        setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));
        setOpaque(false);

        // -- Row: password field + eye toggle --
        JPanel row = new JPanel(new BorderLayout(4, 0));
        row.setOpaque(false);
        row.setMaximumSize(new Dimension(Integer.MAX_VALUE, 36));
        row.setAlignmentX(LEFT_ALIGNMENT);

        pwdField = new JPasswordField();
        pwdField.setFont(UIConstants.FONT_BODY);
        pwdField.putClientProperty("JTextField.placeholderText", placeholder);
        row.add(pwdField, BorderLayout.CENTER);

        JButton toggleBtn = new JButton("👁");
        toggleBtn.setFont(new Font("Segoe UI Emoji", Font.PLAIN, 14));
        toggleBtn.setOpaque(false);
        toggleBtn.setContentAreaFilled(false);
        toggleBtn.setBorderPainted(false);
        toggleBtn.setFocusPainted(false);
        toggleBtn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        toggleBtn.setPreferredSize(new Dimension(38, 36));
        toggleBtn.addActionListener(e -> {
            char echo = pwdField.getEchoChar();
            pwdField.setEchoChar(echo == 0 ? '•' : (char) 0);
        });
        row.add(toggleBtn, BorderLayout.EAST);
        add(row);

        // -- Strength meter (optional) --
        strengthLabel = new JLabel(" ");
        strengthLabel.setFont(UIConstants.FONT_CAPTION);
        strengthLabel.setAlignmentX(LEFT_ALIGNMENT);

        strengthBar = new JPanel() {
            @Override protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2 = (Graphics2D) g;
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING,
                                    RenderingHints.VALUE_ANTIALIAS_ON);
                String strength = (String) getClientProperty("strength");
                if (strength == null) return;
                int w = getWidth();
                int filled = switch (strength) {
                    case "Weak"   -> w / 4;
                    case "Fair"   -> w / 2;
                    case "Good"   -> 3 * w / 4;
                    case "Strong" -> w;
                    default -> 0;
                };
                Color c = switch (strength) {
                    case "Strong" -> UIConstants.SUCCESS;
                    case "Good"   -> UIConstants.INFO;
                    case "Fair"   -> UIConstants.WARNING;
                    default       -> UIConstants.DANGER;
                };
                g2.setColor(ThemeManager.resolve(UIConstants.BORDER_LIGHT, UIConstants.BORDER_DARK));
                g2.fillRoundRect(0, 0, w, 6, 6, 6);
                if (filled > 0) { g2.setColor(c); g2.fillRoundRect(0, 0, filled, 6, 6, 6); }
            }
        };
        strengthBar.setOpaque(false);
        strengthBar.setMaximumSize(new Dimension(Integer.MAX_VALUE, 10));
        strengthBar.setPreferredSize(new Dimension(300, 10));
        strengthBar.setAlignmentX(LEFT_ALIGNMENT);

        if (showStrength) {
            add(Box.createVerticalStrut(4));
            add(strengthBar);
            add(strengthLabel);

            pwdField.getDocument().addDocumentListener(new DocumentListener() {
                @Override public void insertUpdate (DocumentEvent e) { updateStrength(); }
                @Override public void removeUpdate (DocumentEvent e) { updateStrength(); }
                @Override public void changedUpdate(DocumentEvent e) { updateStrength(); }
            });
        }
    }

    private void updateStrength() {
        String pwd      = new String(pwdField.getPassword());
        String strength = ValidationUtils.passwordStrength(pwd);
        strengthBar.putClientProperty("strength", strength);
        strengthBar.repaint();
        strengthLabel.setText("Strength: " + strength);
        Color c = switch (strength) {
            case "Strong" -> UIConstants.SUCCESS;
            case "Good"   -> UIConstants.INFO;
            case "Fair"   -> UIConstants.WARNING;
            default       -> UIConstants.DANGER;
        };
        strengthLabel.setForeground(c);
    }

    // ----------------------------------------------------------------
    public String getPassword() { return new String(pwdField.getPassword()); }
    public void clear()         { pwdField.setText(""); }
}
