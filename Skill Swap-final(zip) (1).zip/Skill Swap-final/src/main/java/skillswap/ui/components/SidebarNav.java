package skillswap.ui.components;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;

/**
 * Left navigation sidebar — simple, reliable, no emoji dependencies.
 * Each item is a clickable panel with label text and active highlight.
 *
 * OOP CONCEPT: Composition — SidebarNav HAS-A list of NavItemPanels.
 *              Observer — Consumer<String> callback fires on click.
 *              Inner class — NavItemPanel encapsulates one nav row.
 */
public class SidebarNav extends JPanel {

    /** Data class for one nav entry. */
    public static class NavItem {
        public final String id;
        public final String label;
        public final String icon; // unused but kept for API compatibility

        public NavItem(String id, String label, String icon) {
            this.id    = id;
            this.label = label;
            this.icon  = icon;
        }
    }

    private final List<NavItemPanel>  panels   = new ArrayList<>();
    private       String              activeId = "";
    private final Consumer<String>    onSelect;

    public SidebarNav(Consumer<String> onSelect) {
        this.onSelect = onSelect;
        setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));
        setOpaque(false);
        setBorder(BorderFactory.createEmptyBorder(12, 0, 12, 0));
    }

    public void addItem(NavItem item) {
        NavItemPanel p = new NavItemPanel(item);
        panels.add(p);
        add(p);
    }

    public void addSeparator() {
        add(Box.createVerticalStrut(4));
    }

    public void setActive(String id) {
        this.activeId = id;
        panels.forEach(p -> p.repaint());
    }

    public String getActiveId() { return activeId; }

    // ----------------------------------------------------------------
    // Inner class — one clickable nav row
    // ----------------------------------------------------------------
    private class NavItemPanel extends JPanel {
        private final NavItem item;
        private boolean hovered = false;

        NavItemPanel(NavItem item) {
            this.item = item;
            setOpaque(false);
            setPreferredSize(new Dimension(200, 42));
            setMaximumSize(new Dimension(200, 42));
            setMinimumSize(new Dimension(200, 42));
            setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
            setLayout(new BorderLayout());

            JLabel lbl = new JLabel("  " + item.label);
            lbl.setFont(UIConstants.FONT_BODY);
            lbl.setForeground(UIConstants.TEXT_PRIMARY_LIGHT);
            add(lbl, BorderLayout.CENTER);

            addMouseListener(new MouseAdapter() {
                @Override public void mouseEntered(MouseEvent e) { hovered = true;  repaint(); }
                @Override public void mouseExited (MouseEvent e) { hovered = false; repaint(); }
                @Override public void mouseClicked(MouseEvent e) {
                    setActive(item.id);
                    if (onSelect != null) onSelect.accept(item.id);
                }
            });
        }

        @Override
        protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

            boolean active = item.id.equals(activeId);

            if (active) {
                // Tinted accent background
                g2.setColor(new Color(108, 92, 231, 30));
                g2.fillRect(0, 0, getWidth(), getHeight());
                // Left accent bar
                g2.setColor(UIConstants.ACCENT);
                g2.fillRect(0, 4, 4, getHeight() - 8);
            } else if (hovered) {
                g2.setColor(new Color(0, 0, 0, 12));
                g2.fillRect(0, 0, getWidth(), getHeight());
            }

            g2.dispose();
            super.paintComponent(g);

            // Update label colour & font
            for (Component c : getComponents()) {
                if (c instanceof JLabel lbl) {
                    lbl.setForeground(active ? UIConstants.ACCENT : UIConstants.TEXT_PRIMARY_LIGHT);
                    lbl.setFont(active
                        ? UIConstants.FONT_BODY.deriveFont(Font.BOLD)
                        : UIConstants.FONT_BODY);
                }
            }
        }
    }
}
