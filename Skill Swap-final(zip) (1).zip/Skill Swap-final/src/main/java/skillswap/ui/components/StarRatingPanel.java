package skillswap.ui.components;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.function.Consumer;

/**
 * Clickable 5-star rating widget.
 *
 * Modes:
 *   - interactive = true  →  user can click to select a rating (feedback form)
 *   - interactive = false →  display-only (profile/history cards)
 *
 * OOP CONCEPT: Inheritance (extends JPanel), Encapsulation (rating state private),
 *              Observer pattern via Consumer<Integer> callback.
 */
public class StarRatingPanel extends JPanel {

    private static final int STAR_SIZE = 24;
    private static final int STAR_GAP  = 4;
    private static final int MAX_STARS = 5;

    private int     rating    = 0;    // currently selected rating (1–5), 0 = none
    private int     hoverStar = 0;    // star index under mouse cursor
    private boolean interactive;
    private Consumer<Integer> onRatingChanged;  // callback when user clicks

    // ----------------------------------------------------------------
    public StarRatingPanel(boolean interactive) {
        this(0, interactive, null);
    }

    public StarRatingPanel(double displayRating, boolean interactive,
                           Consumer<Integer> onRatingChanged) {
        this.rating          = (int) Math.round(displayRating);
        this.interactive     = interactive;
        this.onRatingChanged = onRatingChanged;

        setOpaque(false);
        int width = MAX_STARS * (STAR_SIZE + STAR_GAP);
        setPreferredSize(new Dimension(width, STAR_SIZE + 4));

        if (interactive) {
            setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
            addMouseListener(new MouseAdapter() {
                @Override
                public void mouseClicked(MouseEvent e) {
                    int star = starAt(e.getX());
                    if (star > 0) {
                        rating = star;
                        repaint();
                        if (onRatingChanged != null) onRatingChanged.accept(rating);
                    }
                }
                @Override public void mouseExited(MouseEvent e) { hoverStar = 0; repaint(); }
            });
            addMouseMotionListener(new MouseMotionAdapter() {
                @Override
                public void mouseMoved(MouseEvent e) {
                    hoverStar = starAt(e.getX());
                    repaint();
                }
            });
        }
    }

    // OOP CONCEPT: Method Overriding
    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2 = (Graphics2D) g.create();
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

        int displayUpTo = interactive && hoverStar > 0 ? hoverStar : rating;

        for (int i = 1; i <= MAX_STARS; i++) {
            int x = (i - 1) * (STAR_SIZE + STAR_GAP);
            boolean filled = i <= displayUpTo;
            drawStar(g2, x, 2, STAR_SIZE,
                     filled ? UIConstants.STAR_FILLED : UIConstants.STAR_EMPTY);
        }
        g2.dispose();
    }

    /** Draws a single filled star polygon centred at (x, y). */
    private void drawStar(Graphics2D g2, int x, int y, int size, Color color) {
        g2.setColor(color);
        int   cx = x + size / 2;
        int   cy = y + size / 2;
        float r1 = size / 2.0f;        // outer radius
        float r2 = size / 4.5f;        // inner radius
        int   np = 5;                   // 5 points

        int[] px = new int[np * 2];
        int[] py = new int[np * 2];

        for (int i = 0; i < np * 2; i++) {
            float angle = (float) (Math.PI / np * i - Math.PI / 2);
            float r     = (i % 2 == 0) ? r1 : r2;
            px[i] = (int) (cx + r * Math.cos(angle));
            py[i] = (int) (cy + r * Math.sin(angle));
        }
        g2.fillPolygon(px, py, np * 2);
    }

    /** Returns which star (1–5) is at pixel x, or 0 if none. */
    private int starAt(int x) {
        int star = x / (STAR_SIZE + STAR_GAP) + 1;
        return (star >= 1 && star <= MAX_STARS) ? star : 0;
    }

    // ----------------------------------------------------------------
    public int  getRating()      { return rating; }
    public void setRating(int r) { this.rating = Math.max(0, Math.min(5, r)); repaint(); }
    public void setRating(double avg) { setRating((int) Math.round(avg)); }
}
