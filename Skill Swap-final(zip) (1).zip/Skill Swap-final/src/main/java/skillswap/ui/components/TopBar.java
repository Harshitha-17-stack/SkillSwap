package skillswap.ui.components;

import skillswap.model.Student;
import skillswap.model.User;

import javax.swing.*;
import java.awt.*;

/**
 * Top application bar: app title | spacer | credit badge | avatar | name | theme toggle | logout.
 *
 * OOP CONCEPT: Composition — TopBar HAS-A AvatarCircle, StyledButton.
 *              Encapsulation — callback Runnables injected via constructor.
 */
public class TopBar extends JPanel {

    private final JLabel  creditLabel;
    private final JLabel  nameLabel;
    private final AvatarCircle avatar;

    // ----------------------------------------------------------------
    /**
     * @param user          the logged-in user
     * @param onThemeToggle called when the theme toggle is clicked
     * @param onLogout      called when Logout is clicked
     */
    public TopBar(User user, Runnable onThemeToggle, Runnable onLogout) {
        setPreferredSize(new Dimension(0, UIConstants.TOPBAR_HEIGHT));
        setLayout(new BorderLayout());
        setOpaque(false);

        // --- Left: App name ---
        JLabel appName = new JLabel("  SkillSwap");
        appName.setFont(UIConstants.FONT_H3);
        appName.setForeground(UIConstants.ACCENT);
        add(appName, BorderLayout.WEST);

        // --- Right: controls ---
        JPanel right = new JPanel(new FlowLayout(FlowLayout.RIGHT, 12, 10));
        right.setOpaque(false);

        // Credit balance badge
        int credits = (user instanceof Student s) ? s.getCreditBalance() : 0;
        creditLabel = new JLabel("⭐ " + credits + " pts");
        creditLabel.setFont(UIConstants.FONT_SMALL);
        creditLabel.setForeground(UIConstants.CREDIT_BADGE_FG);
        creditLabel.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(UIConstants.CREDIT_BADGE_FG, 1, true),
            BorderFactory.createEmptyBorder(3, 8, 3, 8)
        ));
        right.add(creditLabel);

        // Avatar circle
        avatar = new AvatarCircle(user.getName(), UIConstants.AVATAR_SIZE_SM);
        right.add(avatar);

        // User name
        nameLabel = new JLabel(user.getName());
        nameLabel.setFont(UIConstants.FONT_BOLD);
        right.add(nameLabel);

        // Theme toggle button
        boolean dark = ThemeManager.isDark();
        StyledButton themeBtn = new StyledButton(dark ? "☀ Light" : "☾ Dark",
                                                  StyledButton.Variant.GHOST);
        themeBtn.setFont(UIConstants.FONT_SMALL);
        themeBtn.addActionListener(e -> {
            boolean nowDark = ThemeManager.toggleTheme();
            themeBtn.setText(nowDark ? "☀ Light" : "☾ Dark");
            if (onThemeToggle != null) onThemeToggle.run();
        });
        right.add(themeBtn);

        // Logout button
        StyledButton logoutBtn = new StyledButton("Logout", StyledButton.Variant.OUTLINE);
        logoutBtn.setFont(UIConstants.FONT_SMALL);
        logoutBtn.addActionListener(e -> { if (onLogout != null) onLogout.run(); });
        right.add(logoutBtn);

        add(right, BorderLayout.EAST);

        // Bottom border line
        setBorder(BorderFactory.createMatteBorder(0, 0, 1, 0,
            ThemeManager.resolve(UIConstants.BORDER_LIGHT, UIConstants.BORDER_DARK)));
    }

    /** Call after a session completes to refresh the credit count. */
    public void updateCredits(int credits) {
        creditLabel.setText("⭐ " + credits + " pts");
    }

    public void updateUser(User user) {
        nameLabel.setText(user.getName());
        avatar.setName(user.getName());
        if (user instanceof Student s) updateCredits(s.getCreditBalance());
    }
}
