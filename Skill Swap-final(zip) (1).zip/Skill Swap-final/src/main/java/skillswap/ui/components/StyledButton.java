package skillswap.ui.components;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.geom.RoundRectangle2D;

/**
 * Custom rounded button with hover/press effects and variant styles.
 *
 * Variants:
 *   PRIMARY  — filled accent colour (default)
 *   OUTLINE  — transparent with accent border
 *   DANGER   — filled red (for cancel/delete actions)
 *   GHOST    — no background, plain text
 *
 * OOP CONCEPT: Inheritance (extends JButton), Encapsulation (private fields),
 *              Method Overriding (paintComponent, contains).
 */
public class StyledButton extends JButton {

    public enum Variant { PRIMARY, OUTLINE, DANGER, GHOST }

    private Variant variant;
    private boolean hovered  = false;
    private boolean pressed  = false;

    // ----------------------------------------------------------------
    public StyledButton(String text) {
        this(text, Variant.PRIMARY);
    }

    public StyledButton(String text, Variant variant) {
        super(text);
        this.variant = variant;
        init();
    }

    private void init() {
        setOpaque(false);
        setContentAreaFilled(false);
        setBorderPainted(false);
        setFocusPainted(false);
        setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        setFont(UIConstants.FONT_BOLD);
        setPreferredSize(new Dimension(getPreferredSize().width + 24, 38));

        addMouseListener(new MouseAdapter() {
            @Override public void mouseEntered(MouseEvent e) { hovered = true;  repaint(); }
            @Override public void mouseExited (MouseEvent e) { hovered = false; repaint(); }
            @Override public void mousePressed(MouseEvent e) { pressed = true;  repaint(); }
            @Override public void mouseReleased(MouseEvent e){ pressed = false; repaint(); }
        });
    }

    // OOP CONCEPT: Method Overriding
    @Override
    protected void paintComponent(Graphics g) {
        Graphics2D g2 = (Graphics2D) g.create();
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

        int w = getWidth(), h = getHeight();
        int arc = UIConstants.ARC_BUTTON;

        switch (variant) {
            case PRIMARY -> {
                Color bg = pressed ? UIConstants.ACCENT_DARK
                         : hovered ? UIConstants.ACCENT_HOVER
                         : UIConstants.ACCENT;
                g2.setColor(bg);
                g2.fillRoundRect(0, 0, w, h, arc, arc);
                setForeground(Color.WHITE);
            }
            case OUTLINE -> {
                if (hovered) {
                    g2.setColor(UIConstants.ACCENT_LIGHT);
                    g2.fillRoundRect(0, 0, w, h, arc, arc);
                }
                g2.setColor(UIConstants.ACCENT);
                g2.setStroke(new BasicStroke(1.8f));
                g2.drawRoundRect(1, 1, w - 2, h - 2, arc, arc);
                setForeground(UIConstants.ACCENT);
            }
            case DANGER -> {
                Color bg = pressed ? new Color(0xC0392B)
                         : hovered ? new Color(0xE74C3C)
                         : UIConstants.DANGER;
                g2.setColor(bg);
                g2.fillRoundRect(0, 0, w, h, arc, arc);
                setForeground(Color.WHITE);
            }
            case GHOST -> {
                if (hovered) {
                    g2.setColor(ThemeManager.resolve(
                        new Color(0, 0, 0, 15), new Color(255, 255, 255, 20)));
                    g2.fillRoundRect(0, 0, w, h, arc, arc);
                }
                setForeground(ThemeManager.resolve(
                    UIConstants.TEXT_PRIMARY_LIGHT, UIConstants.TEXT_PRIMARY_DARK));
            }
        }
        g2.dispose();
        super.paintComponent(g);
    }

    // Make hover detection pixel-perfect with the rounded shape
    @Override
    public boolean contains(int x, int y) {
        Shape shape = new RoundRectangle2D.Float(0, 0, getWidth(), getHeight(),
                          UIConstants.ARC_BUTTON, UIConstants.ARC_BUTTON);
        return shape.contains(x, y);
    }

    public void setVariant(Variant v) { this.variant = v; repaint(); }
}
