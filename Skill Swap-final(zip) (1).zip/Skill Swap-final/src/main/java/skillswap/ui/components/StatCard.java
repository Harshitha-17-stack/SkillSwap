package skillswap.ui.components;

import javax.swing.*;
import java.awt.*;

/**
 * A summary card showing an icon, a large number, and a description label.
 * Used on the Student Dashboard for credit balance, sessions, matches, etc.
 *
 * OOP CONCEPT: Inheritance (extends RoundedPanel).
 *              Composition — StatCard HAS-A RoundedPanel base with Swing children.
 */
public class StatCard extends RoundedPanel {

    private final JLabel valueLabel;
    private final JLabel titleLabel;

    // ----------------------------------------------------------------
    public StatCard(String icon, String title, String value, Color accentColor) {
        super(UIConstants.ARC_CARD, null, true);
        setLayout(new BorderLayout());
        setBorder(BorderFactory.createEmptyBorder(
            UIConstants.PAD_LG, UIConstants.PAD_LG,
            UIConstants.PAD_LG, UIConstants.PAD_LG));

        // Top: icon + coloured strip
        JPanel topRow = new JPanel(new FlowLayout(FlowLayout.LEFT, 0, 0));
        topRow.setOpaque(false);

        JLabel iconLabel = new JLabel(icon);
        iconLabel.setFont(new Font("Segoe UI Emoji", Font.PLAIN, 28));
        topRow.add(iconLabel);
        add(topRow, BorderLayout.NORTH);

        // Centre: large value
        valueLabel = new JLabel(value);
        valueLabel.setFont(new Font("Segoe UI", Font.BOLD, 32));
        valueLabel.setForeground(accentColor);
        add(valueLabel, BorderLayout.CENTER);

        // Bottom: title
        titleLabel = new JLabel(title);
        titleLabel.setFont(UIConstants.FONT_SMALL);
        titleLabel.setForeground(ThemeManager.resolve(
            UIConstants.TEXT_MUTED_LIGHT, UIConstants.TEXT_MUTED_DARK));
        add(titleLabel, BorderLayout.SOUTH);
    }

    /** Updates the large number displayed. */
    public void setValue(String value) {
        valueLabel.setText(value);
    }

    public void setTitle(String title) {
        titleLabel.setText(title);
    }
}
