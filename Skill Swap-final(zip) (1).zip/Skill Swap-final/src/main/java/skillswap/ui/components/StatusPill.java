package skillswap.ui.components;

import skillswap.model.BookingStatus;

import javax.swing.*;
import java.awt.*;

/**
 * Coloured rounded pill label for BookingStatus and match type.
 * e.g.  ● Confirmed   ● Strong Match   ● Partial Match
 *
 * OOP CONCEPT: Inheritance (extends JLabel), Encapsulation (colour mapping).
 */
public class StatusPill extends JLabel {

    public StatusPill(BookingStatus status) {
        this(status.getLabel(), colorFor(status));
    }

    public StatusPill(String text, Color color) {
        super(" " + text + " ");
        setFont(UIConstants.FONT_SMALL);
        setForeground(Color.WHITE);
        setOpaque(false);
        // Store colour for paintComponent
        putClientProperty("pillColor", color);
    }

    // OOP CONCEPT: Method Overriding
    @Override
    protected void paintComponent(Graphics g) {
        Graphics2D g2 = (Graphics2D) g.create();
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

        Color c = (Color) getClientProperty("pillColor");
        if (c == null) c = UIConstants.ACCENT;

        // Draw a softened tinted background instead of solid to look more refined
        g2.setColor(new Color(c.getRed(), c.getGreen(), c.getBlue(), 220));
        g2.fillRoundRect(0, 0, getWidth(), getHeight(),
                         UIConstants.ARC_PILL, UIConstants.ARC_PILL);

        g2.dispose();
        super.paintComponent(g);
    }

    @Override
    public Dimension getPreferredSize() {
        Dimension d = super.getPreferredSize();
        return new Dimension(d.width + 12, d.height + 4);
    }

    // ----------------------------------------------------------------
    // Factory helpers
    // ----------------------------------------------------------------

    public static StatusPill forStatus(BookingStatus status) {
        return new StatusPill(status);
    }

    public static StatusPill strongMatch() {
        return new StatusPill("Strong Match", UIConstants.MATCH_STRONG);
    }

    public static StatusPill partialMatch() {
        return new StatusPill("Partial Match", UIConstants.MATCH_PARTIAL);
    }

    private static Color colorFor(BookingStatus s) {
        return switch (s) {
            case REQUESTED -> UIConstants.STATUS_REQUESTED;
            case CONFIRMED -> UIConstants.STATUS_CONFIRMED;
            case COMPLETED -> UIConstants.STATUS_COMPLETED;
            case CANCELLED -> UIConstants.STATUS_CANCELLED;
        };
    }
}
