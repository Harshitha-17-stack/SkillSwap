package skillswap.ui.components;

import javax.swing.*;
import java.awt.*;

/**
 * Semi-transparent overlay with a spinning "Loading…" indicator.
 * Layered over the content panel during SwingWorker background tasks
 * so the UI never freezes and provides user feedback.
 *
 * Usage:
 *   LoadingOverlay overlay = new LoadingOverlay(parentPanel);
 *   overlay.show();
 *   // ... SwingWorker done callback:
 *   overlay.hide();
 *
 * OOP CONCEPT: Encapsulation — spinning animation timer is private.
 */
public class LoadingOverlay extends JPanel {

    private int   angle = 0;
    private Timer spinTimer;

    // ----------------------------------------------------------------
    public LoadingOverlay() {
        setOpaque(false);
        setLayout(new GridBagLayout());  // centres content

        spinTimer = new Timer(30, e -> { angle = (angle + 10) % 360; repaint(); });
    }

    public void show(JLayeredPane layered) {
        setBounds(0, 0, layered.getWidth(), layered.getHeight());
        layered.add(this, JLayeredPane.MODAL_LAYER);
        layered.revalidate();
        spinTimer.start();
        setVisible(true);
    }

    public void hide(JLayeredPane layered) {
        spinTimer.stop();
        layered.remove(this);
        layered.revalidate();
        layered.repaint();
    }

    // OOP CONCEPT: Method Overriding
    @Override
    protected void paintComponent(Graphics g) {
        Graphics2D g2 = (Graphics2D) g.create();
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

        // Dim the background
        g2.setColor(new Color(0, 0, 0, 90));
        g2.fillRect(0, 0, getWidth(), getHeight());

        // Draw spinning arc at centre
        int cx = getWidth()  / 2;
        int cy = getHeight() / 2;
        int r  = 24;

        g2.setStroke(new BasicStroke(4, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
        g2.setColor(new Color(255, 255, 255, 60));
        g2.drawOval(cx - r, cy - r, r * 2, r * 2);

        g2.setColor(UIConstants.ACCENT);
        g2.drawArc(cx - r, cy - r, r * 2, r * 2, angle, 90);

        // Label
        g2.setFont(UIConstants.FONT_SMALL);
        g2.setColor(Color.WHITE);
        String text = "Loading…";
        FontMetrics fm = g2.getFontMetrics();
        g2.drawString(text, cx - fm.stringWidth(text) / 2, cy + r + 20);

        g2.dispose();
    }
}
