package skillswap.ui.components;

import javax.swing.*;
import javax.swing.border.Border;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import java.awt.*;
import java.util.function.Predicate;

/**
 * A labelled form field (JLabel + JTextField) with built-in inline validation.
 * Turns red/green border on invalid/valid input.
 *
 * OOP CONCEPT: Encapsulation — label, field, error label, and validator
 *              all managed internally. Callers only use getText() / isValid().
 */
public class FormField extends JPanel {

    private final JLabel     label;
    private final JTextField field;
    private final JLabel     errorLabel;
    private       Predicate<String> validator;
    private       String           errorMessage = "Invalid input";

    // ----------------------------------------------------------------
    public FormField(String labelText, String placeholder) {
        setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));
        setOpaque(false);

        // Label
        label = new JLabel(labelText);
        label.setFont(UIConstants.FONT_SMALL);
        label.setForeground(ThemeManager.resolve(
            UIConstants.TEXT_MUTED_LIGHT, UIConstants.TEXT_MUTED_DARK));
        label.setAlignmentX(LEFT_ALIGNMENT);
        add(label);
        add(Box.createVerticalStrut(4));

        // Text field
        field = new JTextField();
        field.setFont(UIConstants.FONT_BODY);
        field.setMaximumSize(new Dimension(Integer.MAX_VALUE, 36));
        field.setPreferredSize(new Dimension(300, 36));
        field.putClientProperty("JTextField.placeholderText", placeholder);
        field.setAlignmentX(LEFT_ALIGNMENT);
        add(field);

        // Error label (hidden until validation fails)
        errorLabel = new JLabel(" ");
        errorLabel.setFont(UIConstants.FONT_CAPTION);
        errorLabel.setForeground(UIConstants.DANGER);
        errorLabel.setAlignmentX(LEFT_ALIGNMENT);
        add(errorLabel);

        // Live validation on keystroke
        field.getDocument().addDocumentListener(new DocumentListener() {
            @Override public void insertUpdate (DocumentEvent e) { runValidation(); }
            @Override public void removeUpdate (DocumentEvent e) { runValidation(); }
            @Override public void changedUpdate(DocumentEvent e) { runValidation(); }
        });
    }

    // ----------------------------------------------------------------
    private void runValidation() {
        if (validator == null) return;
        boolean valid = validator.test(field.getText());
        errorLabel.setText(valid ? " " : errorMessage);
        field.putClientProperty("JComponent.outline", valid ? null : "error");
        field.repaint();
    }

    // ----------------------------------------------------------------
    public FormField withValidator(Predicate<String> v, String errMsg) {
        this.validator    = v;
        this.errorMessage = errMsg;
        return this;
    }

    public String  getText()       { return field.getText();           }
    public void    setText(String t){ field.setText(t);                 }
    public boolean isValid()       {
        return validator == null || validator.test(field.getText());
    }
    public JTextField getField()   { return field;                     }
    public void setEditable(boolean b) { field.setEditable(b);         }
    public void showError(String msg) { errorLabel.setText(msg);        }
    public void clearError()          { errorLabel.setText(" ");        }
}
