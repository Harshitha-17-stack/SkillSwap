package skillswap.ui.components;

import java.awt.*;

/**
 * Central design-token file — all colours, fonts, sizes, and spacing
 * live here so every component stays visually consistent.
 *
 * OOP CONCEPT: Encapsulation — UI constants in one place,
 * never scattered as magic numbers across the codebase.
 */
public final class UIConstants {

    private UIConstants() {} // utility class — no instances

    // ----------------------------------------------------------------
    // COLOUR PALETTE  (indigo/violet accent, soft neutrals)
    // ----------------------------------------------------------------
    public static final Color ACCENT        = new Color(0x6C5CE7);   // primary indigo
    public static final Color ACCENT_HOVER  = new Color(0x5849C4);   // darker on hover
    public static final Color ACCENT_LIGHT  = new Color(0xEDE9FF);   // tinted bg
    public static final Color ACCENT_DARK   = new Color(0x4834C2);   // pressed

    // Semantic colours
    public static final Color SUCCESS       = new Color(0x00B894);
    public static final Color WARNING       = new Color(0xFDAB32);
    public static final Color DANGER        = new Color(0xFF6B6B);
    public static final Color INFO          = new Color(0x74B9FF);

    // Status pill colours (for BookingStatus)
    public static final Color STATUS_REQUESTED  = new Color(0xFDAB32);
    public static final Color STATUS_CONFIRMED  = new Color(0x74B9FF);
    public static final Color STATUS_COMPLETED  = new Color(0x00B894);
    public static final Color STATUS_CANCELLED  = new Color(0xFF6B6B);

    // Match badge colours
    public static final Color MATCH_STRONG  = new Color(0x00B894);
    public static final Color MATCH_PARTIAL = new Color(0xFDAB32);

    // Star rating
    public static final Color STAR_FILLED  = new Color(0xFDAB32);
    public static final Color STAR_EMPTY   = new Color(0xDFE6E9);

    // Light theme surfaces
    public static final Color BG_LIGHT          = new Color(0xF8F7FF);
    public static final Color SURFACE_LIGHT     = Color.WHITE;
    public static final Color SIDEBAR_LIGHT     = new Color(0xFFFFFF);
    public static final Color TEXT_PRIMARY_LIGHT = new Color(0x2D3436);
    public static final Color TEXT_MUTED_LIGHT   = new Color(0x636E72);
    public static final Color BORDER_LIGHT       = new Color(0xECECF0);

    // Dark theme surfaces
    public static final Color BG_DARK           = new Color(0x1A1A2E);
    public static final Color SURFACE_DARK      = new Color(0x16213E);
    public static final Color SIDEBAR_DARK      = new Color(0x0F3460);
    public static final Color TEXT_PRIMARY_DARK  = new Color(0xECF0F1);
    public static final Color TEXT_MUTED_DARK    = new Color(0x95A5A6);
    public static final Color BORDER_DARK        = new Color(0x2C3A5A);

    // ----------------------------------------------------------------
    // TYPOGRAPHY
    // ----------------------------------------------------------------
    public static final Font FONT_H1      = new Font("Segoe UI", Font.BOLD,  28);
    public static final Font FONT_H2      = new Font("Segoe UI", Font.BOLD,  22);
    public static final Font FONT_H3      = new Font("Segoe UI", Font.BOLD,  16);
    public static final Font FONT_BODY    = new Font("Segoe UI", Font.PLAIN, 14);
    public static final Font FONT_SMALL   = new Font("Segoe UI", Font.PLAIN, 12);
    public static final Font FONT_CAPTION = new Font("Segoe UI", Font.ITALIC,11);
    public static final Font FONT_MONO    = new Font("Consolas",  Font.PLAIN, 13);
    public static final Font FONT_BOLD    = new Font("Segoe UI", Font.BOLD,  14);

    // ----------------------------------------------------------------
    // SHAPE / SPACING
    // ----------------------------------------------------------------
    public static final int ARC_CARD     = 16;   // card corner radius
    public static final int ARC_BUTTON   = 20;   // button corner radius
    public static final int ARC_CHIP     = 20;   // skill chip radius
    public static final int ARC_PILL     = 30;   // status pill radius

    public static final int PAD_SM  =  8;
    public static final int PAD_MD  = 16;
    public static final int PAD_LG  = 24;
    public static final int PAD_XL  = 32;

    public static final int SIDEBAR_WIDTH = 240;
    public static final int TOPBAR_HEIGHT =  60;

    // ----------------------------------------------------------------
    // AVATAR
    // ----------------------------------------------------------------
    public static final int AVATAR_SIZE_LG = 48;
    public static final int AVATAR_SIZE_SM = 32;

    // Credit badge colour
    public static final Color CREDIT_BADGE_BG = new Color(0xFEF9E7);
    public static final Color CREDIT_BADGE_FG = new Color(0xF39C12);
}
