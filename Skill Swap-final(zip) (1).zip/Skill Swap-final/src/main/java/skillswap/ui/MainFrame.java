package skillswap.ui;

import skillswap.model.*;
import skillswap.service.AuthService;
import skillswap.ui.components.*;
import skillswap.ui.screens.*;

import javax.swing.*;
import java.awt.*;

/**
 * Main application window — Student-only platform.
 *
 * Layout:
 *   ┌─────────────────────────────────────────┐
 *   │  TopBar (name, credits, theme, logout)  │
 *   ├──────────┬──────────────────────────────┤
 *   │ Sidebar  │  CardLayout content area     │
 *   │ Nav      │  (screen panels swap here)   │
 *   └──────────┴──────────────────────────────┘
 */
public class MainFrame extends JFrame {

    // Screen IDs
    private static final String SCREEN_LOGIN     = "login";
    private static final String SCREEN_REGISTER  = "register";
    private static final String SCREEN_DASHBOARD = "dashboard";
    private static final String SCREEN_SKILLS    = "skills";
    private static final String SCREEN_MATCHES   = "matches";
    private static final String SCREEN_BOOKINGS  = "bookings";
    private static final String SCREEN_CREDITS   = "credits";
    private static final String SCREEN_FEEDBACK  = "feedback";
    private static final String SCREEN_PROFILE   = "profile";

    // Root card layout (login vs app shell)
    private final CardLayout cardLayout = new CardLayout();
    private final JPanel     cards      = new JPanel(cardLayout);

    // Pre-login
    private LoginScreen    loginScreen;
    private RegisterScreen registerScreen;

    // Post-login shell
    private JPanel     mainShell;
    private JPanel     sidebarWrapper;
    private SidebarNav sidebar;
    private TopBar     topBar;
    private JPanel     contentArea;
    private CardLayout contentLayout;

    // Screens
    private DashboardScreen      dashboardScreen;
    private MySkillsScreen       mySkillsScreen;
    private FindMatchesScreen    matchesScreen;
    private BookingHistoryScreen bookingHistoryScreen;
    private CreditsScreen        creditsScreen;
    private FeedbackScreen       feedbackScreen;
    private ProfileScreen        profileScreen;

    public MainFrame() {
        setTitle("SkillSwap — Peer-to-Peer Skill Exchange");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(1280, 800);
        setMinimumSize(new Dimension(1100, 680));
        setLocationRelativeTo(null);
        setContentPane(cards);
        buildPreLoginScreens();
        cardLayout.show(cards, SCREEN_LOGIN);
    }

    // ================================================================
    // PRE-LOGIN
    // ================================================================
    private void buildPreLoginScreens() {
        loginScreen = new LoginScreen(
            this::onLoginSuccess,
            () -> cardLayout.show(cards, SCREEN_REGISTER));
        cards.add(loginScreen, SCREEN_LOGIN);

        registerScreen = new RegisterScreen(
            email -> { loginScreen.setEmail(email); cardLayout.show(cards, SCREEN_LOGIN); },
            () -> cardLayout.show(cards, SCREEN_LOGIN));
        cards.add(registerScreen, SCREEN_REGISTER);
    }

    // ================================================================
    // POST-LOGIN
    // ================================================================
    private void onLoginSuccess() {
        User user = AuthService.getCurrentUser();
        if (user == null) return;
        buildMainShell(user);
        cardLayout.show(cards, "shell");
        navigateTo(SCREEN_DASHBOARD);
    }

    private void buildMainShell(User user) {
        mainShell = new JPanel(new BorderLayout());
        mainShell.setBackground(UIConstants.BG_LIGHT);

        // TopBar
        topBar = new TopBar(user, () -> {}, this::onLogout);
        mainShell.add(topBar, BorderLayout.NORTH);

        // Body = sidebar + content
        JPanel body = new JPanel(new BorderLayout());
        body.setOpaque(false);

        // Sidebar wrapper
        sidebarWrapper = new JPanel(new BorderLayout());
        sidebarWrapper.setOpaque(true);
        sidebarWrapper.setBackground(new Color(0xF0EFFE));
        sidebarWrapper.setPreferredSize(new Dimension(200, 0));

        sidebar = new SidebarNav(this::navigateTo);
        sidebar.addItem(new SidebarNav.NavItem(SCREEN_DASHBOARD, "Dashboard",    ""));
        sidebar.addItem(new SidebarNav.NavItem(SCREEN_SKILLS,    "My Skills",    ""));
        sidebar.addItem(new SidebarNav.NavItem(SCREEN_MATCHES,   "Find Matches", ""));
        sidebar.addItem(new SidebarNav.NavItem(SCREEN_BOOKINGS,  "Bookings",     ""));
        sidebar.addItem(new SidebarNav.NavItem(SCREEN_CREDITS,   "Credits",      ""));
        sidebar.addItem(new SidebarNav.NavItem(SCREEN_FEEDBACK,  "Feedback",     ""));
        sidebar.addItem(new SidebarNav.NavItem(SCREEN_PROFILE,   "My Profile",   ""));

        sidebarWrapper.add(sidebar, BorderLayout.NORTH);

        JLabel ver = new JLabel("  SkillSwap v1.0");
        ver.setFont(UIConstants.FONT_CAPTION);
        ver.setForeground(UIConstants.TEXT_MUTED_LIGHT);
        sidebarWrapper.add(ver, BorderLayout.SOUTH);
        body.add(sidebarWrapper, BorderLayout.WEST);

        // Content area
        contentLayout = new CardLayout();
        contentArea   = new JPanel(contentLayout);
        contentArea.setBackground(UIConstants.BG_LIGHT);
        body.add(contentArea, BorderLayout.CENTER);

        mainShell.add(body, BorderLayout.CENTER);

        // Build screens
        if (user instanceof Student student) {
            buildStudentScreens(student);
        }

        cards.add(mainShell, "shell");
        cards.revalidate();
        cards.repaint();
    }

    private void buildStudentScreens(Student student) {
        dashboardScreen = new DashboardScreen(student);
        contentArea.add(dashboardScreen, SCREEN_DASHBOARD);

        mySkillsScreen = new MySkillsScreen(student, this);
        contentArea.add(mySkillsScreen, SCREEN_SKILLS);

        matchesScreen = new FindMatchesScreen(student, this, this::navigateTo);
        contentArea.add(matchesScreen, SCREEN_MATCHES);

        bookingHistoryScreen = new BookingHistoryScreen(student, this, this::onCreditsChanged);
        contentArea.add(bookingHistoryScreen, SCREEN_BOOKINGS);

        creditsScreen = new CreditsScreen(student);
        contentArea.add(creditsScreen, SCREEN_CREDITS);

        feedbackScreen = new FeedbackScreen(student);
        contentArea.add(feedbackScreen, SCREEN_FEEDBACK);

        profileScreen = new ProfileScreen(student.getUserId(), this, true);
        contentArea.add(profileScreen, SCREEN_PROFILE);
    }

    // ================================================================
    // NAVIGATION
    // ================================================================
    public void navigateTo(String screenId) {
        sidebar.setActive(screenId);
        contentLayout.show(contentArea, screenId);

        if (SCREEN_SKILLS.equals(screenId)   && mySkillsScreen       != null) mySkillsScreen.refresh();
        if (SCREEN_BOOKINGS.equals(screenId) && bookingHistoryScreen  != null) bookingHistoryScreen.loadAll();
        if (SCREEN_PROFILE.equals(screenId)  && profileScreen        != null) {
            // reload profile
        }
    }

    // ================================================================
    // CALLBACKS
    // ================================================================
    private void onCreditsChanged() {
        User user = AuthService.getCurrentUser();
        if (user instanceof Student s) {
            topBar.updateCredits(s.getCreditBalance());
            if (dashboardScreen != null) dashboardScreen.refreshCredits();
            if (creditsScreen   != null) creditsScreen.refresh();
        }
    }

    private void onLogout() {
        if (ConfirmDialog.show(this, "Logout", "Are you sure you want to logout?")) {
            new AuthService().logout();
            cards.removeAll();
            mainShell   = null;
            contentArea = null;
            buildPreLoginScreens();
            cardLayout.show(cards, SCREEN_LOGIN);
            cards.revalidate();
            cards.repaint();
        }
    }
}
