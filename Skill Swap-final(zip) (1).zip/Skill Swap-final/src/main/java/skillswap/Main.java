package skillswap;

import com.formdev.flatlaf.FlatLightLaf;
import com.formdev.flatlaf.FlatDarkLaf;
import skillswap.ui.MainFrame;
import skillswap.util.AppPreferences;
import skillswap.util.DatabaseManager;

import javax.swing.*;

/**
 * Application entry point.
 *
 * Startup sequence:
 *   1. Apply saved theme (FlatLaf light or dark)
 *   2. Connect to SQLite and initialise schema
 *   3. Optionally seed demo data (first run)
 *   4. Launch the Swing UI on the Event Dispatch Thread
 *
 * OOP CONCEPT: Demonstrates separation of concerns — Main only wires
 * together the layers; it contains no business or UI logic itself.
 */
public class Main {

    public static void main(String[] args) {

        // ---- 1. Apply theme BEFORE any Swing components are created ----
        applyTheme();

        // ---- 2. Set global Swing rendering hints ----
        System.setProperty("awt.useSystemAAFontSettings", "on");
        System.setProperty("swing.aatext", "true");

        // ---- 3. Database bootstrap (happens on background thread to avoid
        //         freezing the splash / login screen) ----
        SwingWorker<Void, Void> dbInit = new SwingWorker<>() {
            @Override
            protected Void doInBackground() {
                DatabaseManager db = DatabaseManager.getInstance();
                db.initializeSchema();

                // Seed only if the users table is empty (first run)
                if (isDatabaseEmpty(db)) {
                    db.seedDatabase();
                    System.out.println("[Main] First run — demo data loaded.");
                }
                return null;
            }
        };
        dbInit.execute();

        // ---- 4. Launch UI on the Event Dispatch Thread ----
        SwingUtilities.invokeLater(() -> {
            MainFrame frame = new MainFrame();
            frame.setVisible(true);
        });

        // ---- 5. Shutdown hook — close DB connection cleanly ----
        Runtime.getRuntime().addShutdownHook(new Thread(() -> {
            DatabaseManager.getInstance().close();
            System.out.println("[Main] Application shut down.");
        }));
    }

    // ----------------------------------------------------------------

    /** Applies the FlatLaf theme from saved preferences. */
    private static void applyTheme() {
        try {
            if (AppPreferences.isDarkTheme()) {
                FlatDarkLaf.setup();
            } else {
                FlatLightLaf.setup();
            }
            // Tune global FlatLaf UI defaults
            UIManager.put("Button.arc",            20);
            UIManager.put("Component.arc",         12);
            UIManager.put("TextComponent.arc",     10);
            UIManager.put("ScrollBar.thumbArc",    999);
            UIManager.put("ScrollBar.trackArc",    999);
            UIManager.put("TabbedPane.tabArc",     10);
            UIManager.put("defaultFont",           new java.awt.Font("Segoe UI", java.awt.Font.PLAIN, 14));
        } catch (Exception e) {
            System.err.println("[Main] Failed to apply theme, using system default: " + e.getMessage());
        }
    }

    /** Returns true if no users exist yet (fresh database). */
    private static boolean isDatabaseEmpty(DatabaseManager db) {
        try (var stmt = db.getConnection().prepareStatement("SELECT COUNT(*) FROM users");
             var rs   = stmt.executeQuery()) {
            return rs.next() && rs.getInt(1) == 0;
        } catch (Exception e) {
            return true;  // Treat errors as empty — seed will create tables
        }
    }
}
