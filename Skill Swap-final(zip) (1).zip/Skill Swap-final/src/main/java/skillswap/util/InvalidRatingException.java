package skillswap.util;

/**
 * OOP CONCEPT: Custom checked Exception.
 * Thrown when a feedback rating is outside the valid 1–5 range,
 * or when feedback is attempted on a non-completed / cancelled session.
 */
public class InvalidRatingException extends Exception {

    public InvalidRatingException(String message) {
        super(message);
    }
}
