package skillswap.util;

/**
 * OOP CONCEPT: Custom Exception (extends RuntimeException).
 * Wraps low-level SQLExceptions into domain-meaningful errors,
 * keeping DAO layer details out of the service/UI layers.
 */
public class DatabaseException extends RuntimeException {

    public DatabaseException(String message) {
        super(message);
    }

    public DatabaseException(String message, Throwable cause) {
        super(message, cause);
    }
}
