package skillswap.util;

/**
 * OOP CONCEPT: Custom checked Exception.
 * Thrown when a user tries to submit a second review
 * for the same booking (enforces the UNIQUE DB constraint in code too).
 */
public class DuplicateFeedbackException extends Exception {

    public DuplicateFeedbackException(String message) {
        super(message);
    }
}
