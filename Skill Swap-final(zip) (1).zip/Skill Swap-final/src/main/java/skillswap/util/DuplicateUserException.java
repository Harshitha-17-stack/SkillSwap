package skillswap.util;

/**
 * OOP CONCEPT: Custom checked Exception.
 * Thrown when a registration attempt uses an email that already exists.
 */
public class DuplicateUserException extends Exception {

    public DuplicateUserException(String message) {
        super(message);
    }
}
