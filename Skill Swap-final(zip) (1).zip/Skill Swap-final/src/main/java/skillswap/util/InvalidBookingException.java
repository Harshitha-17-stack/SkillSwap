package skillswap.util;

/**
 * OOP CONCEPT: Custom checked Exception.
 * Thrown when a booking violates business rules:
 * - past date, self-booking, conflicting session, invalid status transition.
 */
public class InvalidBookingException extends Exception {

    public InvalidBookingException(String message) {
        super(message);
    }

    public InvalidBookingException(String message, Throwable cause) {
        super(message, cause);
    }
}
