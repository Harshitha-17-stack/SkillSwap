package skillswap.util;

import java.time.LocalDate;
import java.util.regex.Pattern;

/**
 * Stateless utility class for input validation used by both
 * the service layer and the UI layer (inline feedback).
 *
 * OOP CONCEPT: Encapsulation — validation rules in one place,
 * not scattered across the codebase.
 */
public final class ValidationUtils {

    // RFC-5322-inspired email regex (practical subset)
    private static final Pattern EMAIL_PATTERN =
        Pattern.compile("^[\\w._%+\\-]+@[\\w.\\-]+\\.[a-zA-Z]{2,}$");

    private ValidationUtils() {}  // Prevent instantiation

    /** Returns true if the email looks syntactically valid. */
    public static boolean isValidEmail(String email) {
        return email != null && EMAIL_PATTERN.matcher(email.trim()).matches();
    }

    /**
     * Returns a password strength label.
     * Used to drive the strength meter on the Registration screen.
     */
    public static String passwordStrength(String password) {
        if (password == null || password.length() < 6) return "Weak";
        boolean hasUpper = password.chars().anyMatch(Character::isUpperCase);
        boolean hasDigit = password.chars().anyMatch(Character::isDigit);
        boolean hasSpec  = password.chars().anyMatch(c -> !Character.isLetterOrDigit(c));
        int score = (hasUpper ? 1 : 0) + (hasDigit ? 1 : 0) + (hasSpec ? 1 : 0);
        return switch (score) {
            case 3    -> "Strong";
            case 2    -> "Good";
            case 1    -> "Fair";
            default   -> "Weak";
        };
    }

    /** Returns true if the date is today or in the future. */
    public static boolean isFutureOrToday(LocalDate date) {
        return date != null && !date.isBefore(LocalDate.now());
    }

    /** Returns true if the string is non-null and non-blank. */
    public static boolean notBlank(String s) {
        return s != null && !s.isBlank();
    }

    /** Clamps a string to maxLength characters. */
    public static String clamp(String s, int maxLength) {
        if (s == null) return "";
        return s.length() > maxLength ? s.substring(0, maxLength) : s;
    }
}
