package skillswap.util;

import java.util.prefs.Preferences;

/**
 * Utility class that wraps Java's Preferences API to persist
 * user settings (e.g., dark/light theme) across sessions.
 *
 * OOP CONCEPT: Encapsulation — all preference keys are private constants;
 * callers use typed getter/setter methods.
 */
public final class AppPreferences {

    private static final Preferences PREFS =
        Preferences.userNodeForPackage(AppPreferences.class);

    // Preference keys
    private static final String KEY_DARK_THEME = "darkTheme";

    // Private constructor — utility class, no instances needed
    private AppPreferences() {}

    public static boolean isDarkTheme() {
        return PREFS.getBoolean(KEY_DARK_THEME, false);
    }

    public static void setDarkTheme(boolean dark) {
        PREFS.putBoolean(KEY_DARK_THEME, dark);
    }
}
