package skillswap.util;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.sql.*;
import java.util.stream.Collectors;

/**
 * OOP CONCEPT: Singleton pattern — only one database connection in the JVM.
 *
 * Responsibilities:
 *   1. Open and hold the single SQLite connection.
 *   2. Run schema.sql on first startup to create tables.
 *   3. Optionally run seed.sql to populate demo data.
 *   4. Provide a factory for PreparedStatements.
 *
 * All DAOs obtain their Connection from this class.
 * Uses try-with-resources throughout to prevent resource leaks.
 */
public final class DatabaseManager {

    // SQLite file stored next to the JAR (or in the project root during dev).
    // Tests override this with -Dskillswap.db.url=jdbc:sqlite::memory:
    private static final String DB_URL = System.getProperty(
        "skillswap.db.url", "jdbc:sqlite:skillswap.db");

    // Volatile ensures the singleton is safely published across threads
    private static volatile DatabaseManager instance;

    private Connection connection;

    // ----------------------------------------------------------------
    // Private constructor — prevents direct instantiation (Singleton)
    // ----------------------------------------------------------------
    private DatabaseManager() {
        try {
            // Load the SQLite JDBC driver
            Class.forName("org.sqlite.JDBC");
            connection = DriverManager.getConnection(DB_URL);

            // Enable foreign-key enforcement (SQLite disables it by default)
            try (Statement stmt = connection.createStatement()) {
                stmt.execute("PRAGMA foreign_keys = ON");
                // WAL mode is incompatible with in-memory DBs (used by tests)
                if (!DB_URL.contains(":memory:")) {
                    stmt.execute("PRAGMA journal_mode = WAL");
                }
            }

            System.out.println("[DB] Connected to SQLite: " + DB_URL);
        } catch (ClassNotFoundException e) {
            throw new DatabaseException("SQLite JDBC driver not found.", e);
        } catch (SQLException e) {
            throw new DatabaseException("Failed to connect to database.", e);
        }
    }

    // ----------------------------------------------------------------
    // Double-checked locking Singleton
    // ----------------------------------------------------------------
    public static DatabaseManager getInstance() {
        if (instance == null) {
            synchronized (DatabaseManager.class) {
                if (instance == null) {
                    instance = new DatabaseManager();
                }
            }
        }
        return instance;
    }

    /** Returns the active connection (reconnects if closed). */
    public Connection getConnection() {
        try {
            if (connection == null || connection.isClosed()) {
                connection = DriverManager.getConnection(DB_URL);
                try (Statement stmt = connection.createStatement()) {
                    stmt.execute("PRAGMA foreign_keys = ON");
                    if (!DB_URL.contains(":memory:")) {
                        stmt.execute("PRAGMA journal_mode = WAL");
                    }
                }
            }
        } catch (SQLException e) {
            throw new DatabaseException("Failed to obtain database connection.", e);
        }
        return connection;
    }

    // ----------------------------------------------------------------
    // Schema bootstrap — called once at application startup
    // ----------------------------------------------------------------

    /**
     * Creates all tables if they don't already exist.
     * Runs the DDL directly — does NOT depend on file parsing.
     */
    public void initializeSchema() {
        String[] ddl = {
            "PRAGMA foreign_keys = ON",
            "CREATE TABLE IF NOT EXISTS users (" +
                "user_id INTEGER PRIMARY KEY AUTOINCREMENT," +
                "name TEXT NOT NULL," +
                "email TEXT NOT NULL UNIQUE," +
                "password_hash TEXT NOT NULL," +
                "role TEXT NOT NULL CHECK(role IN ('STUDENT','ADMIN'))," +
                "department TEXT," +
                "year_of_study INTEGER," +
                "bio TEXT," +
                "credit_balance INTEGER NOT NULL DEFAULT 0," +
                "access_level INTEGER DEFAULT 1," +
                "created_at DATETIME DEFAULT CURRENT_TIMESTAMP)",
            "CREATE TABLE IF NOT EXISTS skills (" +
                "skill_id INTEGER PRIMARY KEY AUTOINCREMENT," +
                "name TEXT NOT NULL UNIQUE," +
                "category TEXT NOT NULL," +
                "created_at DATETIME DEFAULT CURRENT_TIMESTAMP)",
            "CREATE TABLE IF NOT EXISTS skill_listings (" +
                "listing_id INTEGER PRIMARY KEY AUTOINCREMENT," +
                "user_id INTEGER NOT NULL REFERENCES users(user_id) ON DELETE CASCADE," +
                "skill_id INTEGER NOT NULL REFERENCES skills(skill_id) ON DELETE CASCADE," +
                "listing_type TEXT NOT NULL CHECK(listing_type IN ('OFFER','WANT'))," +
                "proficiency TEXT NOT NULL CHECK(proficiency IN ('BEGINNER','INTERMEDIATE','ADVANCED'))," +
                "description TEXT," +
                "created_at DATETIME DEFAULT CURRENT_TIMESTAMP," +
                "UNIQUE(user_id, skill_id, listing_type))",
            "CREATE TABLE IF NOT EXISTS bookings (" +
                "booking_id INTEGER PRIMARY KEY AUTOINCREMENT," +
                "requester_id INTEGER NOT NULL REFERENCES users(user_id)," +
                "provider_id INTEGER NOT NULL REFERENCES users(user_id)," +
                "skill_id INTEGER NOT NULL REFERENCES skills(skill_id)," +
                "session_date TEXT NOT NULL," +
                "session_time TEXT NOT NULL," +
                "duration_minutes INTEGER NOT NULL CHECK(duration_minutes > 0)," +
                "status TEXT NOT NULL DEFAULT 'REQUESTED' CHECK(status IN ('REQUESTED','CONFIRMED','COMPLETED','CANCELLED'))," +
                "cancel_reason TEXT," +
                "created_at DATETIME DEFAULT CURRENT_TIMESTAMP," +
                "CHECK(requester_id != provider_id))",
            "CREATE TABLE IF NOT EXISTS credit_transactions (" +
                "tx_id INTEGER PRIMARY KEY AUTOINCREMENT," +
                "user_id INTEGER NOT NULL REFERENCES users(user_id)," +
                "booking_id INTEGER UNIQUE REFERENCES bookings(booking_id)," +
                "amount INTEGER NOT NULL," +
                "reason TEXT NOT NULL," +
                "created_at DATETIME DEFAULT CURRENT_TIMESTAMP)",
            "CREATE TABLE IF NOT EXISTS feedback (" +
                "feedback_id INTEGER PRIMARY KEY AUTOINCREMENT," +
                "booking_id INTEGER NOT NULL REFERENCES bookings(booking_id)," +
                "reviewer_id INTEGER NOT NULL REFERENCES users(user_id)," +
                "reviewee_id INTEGER NOT NULL REFERENCES users(user_id)," +
                "rating INTEGER NOT NULL CHECK(rating BETWEEN 1 AND 5)," +
                "comment TEXT," +
                "created_at DATETIME DEFAULT CURRENT_TIMESTAMP," +
                "UNIQUE(booking_id, reviewer_id))"
        };
        try (Statement stmt = getConnection().createStatement()) {
            for (String sql : ddl) {
                stmt.execute(sql);
            }
        } catch (SQLException e) {
            throw new DatabaseException("Failed to initialise schema.", e);
        }
        System.out.println("[DB] Schema initialised.");
    }

    /**
     * Runs seed.sql to load demo data.
     * Clears existing data first (safe for presentations / resets).
     */
    public void seedDatabase() {
        executeSqlFile("/seed.sql");
        System.out.println("[DB] Demo data seeded.");
    }

    // ----------------------------------------------------------------
    // Helpers
    // ----------------------------------------------------------------

    /**
     * Reads a SQL file from the classpath and executes each statement.
     * Statements are split on semicolons (handles multi-line statements).
     *
     * OOP CONCEPT: try-with-resources — automatically closes streams and statements.
     */
    private void executeSqlFile(String resourcePath) {
        String sql = readResource(resourcePath);
        // Split on ";" followed by optional whitespace / newline
        String[] statements = sql.split(";\\s*");
        for (String s : statements) {
            String trimmed = s.trim();
            // Skip blank lines and SQL comments
            if (trimmed.isEmpty()) continue;
            if (trimmed.startsWith("--")) continue;
            // Skip PRAGMA journal_mode on in-memory DBs
            if (trimmed.toLowerCase().contains("journal_mode")
                    && DB_URL.contains(":memory:")) continue;
            try (Statement stmt = getConnection().createStatement()) {
                stmt.execute(trimmed);
            } catch (SQLException e) {
                // Only re-throw non-ignorable errors
                String msg = e.getMessage();
                if (msg != null && (msg.contains("already exists")
                        || msg.contains("no such table: sqlite_sequence"))) {
                    continue; // harmless — table already created or sequence not needed
                }
                throw new DatabaseException("Error in SQL file " + resourcePath
                    + ": " + trimmed.substring(0, Math.min(80, trimmed.length())), e);
            }
        }
    }

    /** Reads a classpath resource file into a String. */
    private String readResource(String path) {
        try (InputStream is = getClass().getResourceAsStream(path)) {
            if (is == null) {
                throw new DatabaseException("SQL resource not found on classpath: " + path);
            }
            try (BufferedReader reader = new BufferedReader(
                    new InputStreamReader(is, StandardCharsets.UTF_8))) {
                return reader.lines().collect(Collectors.joining("\n"));
            }
        } catch (IOException e) {
            throw new DatabaseException("Failed to read SQL resource: " + path, e);
        }
    }

    /** Closes the connection — called on application shutdown. */
    public void close() {
        if (connection != null) {
            try {
                connection.close();
                System.out.println("[DB] Connection closed.");
            } catch (SQLException e) {
                System.err.println("[DB] Error closing connection: " + e.getMessage());
            }
        }
    }

    /**
     * Resets the singleton — FOR TESTING ONLY.
     * Closes the current connection and forces re-creation on next getInstance() call.
     * Call before setting the skillswap.db.url system property in test setUp().
     */
    public static synchronized void resetForTesting() {
        if (instance != null) {
            instance.close();
            instance = null;
        }
    }
}
