package skillswap.service;

import skillswap.dao.SkillDAO;
import skillswap.model.Skill;
import skillswap.model.SkillListing;
import skillswap.model.SkillListing.ListingType;
import skillswap.model.SkillListing.Proficiency;
import skillswap.util.ValidationUtils;

import java.util.List;
import java.util.Optional;

/**
 * Service: Skill catalogue and student skill-listing management.
 *
 * OOP CONCEPTS:
 * - Composition: SkillService HAS-A SkillDAO
 * - Encapsulation: all validation in one place, DAOs hidden from the UI
 */
public class SkillService {

    private final SkillDAO skillDAO = new SkillDAO();

    // ----------------------------------------------------------------
    // Skill Catalogue
    // ----------------------------------------------------------------

    /** Returns the full skills catalogue for populating combo-boxes. */
    public List<Skill> getAllSkills() {
        return skillDAO.findAllSkills();
    }

    /**
     * Finds or creates a skill by name.
     * If the skill name already exists (case-insensitive), returns it.
     * Otherwise inserts it as a new skill.
     */
    public Skill findOrCreateSkill(String name, String category) {
        if (!ValidationUtils.notBlank(name)) {
            throw new IllegalArgumentException("Skill name cannot be empty.");
        }
        Optional<Skill> existing = skillDAO.findSkillByName(name);
        if (existing.isPresent()) return existing.get();

        Skill newSkill = new Skill(name, category);
        int id = skillDAO.insertSkill(newSkill);
        newSkill.setSkillId(id);
        return newSkill;
    }

    // ----------------------------------------------------------------
    // Skill Listings
    // ----------------------------------------------------------------

    /** Returns all listings (OFFER + WANT) for a student. */
    public List<SkillListing> getListingsForUser(int userId) {
        return skillDAO.findListingsByUser(userId);
    }

    /** Returns only OFFER listings for a user. */
    public List<SkillListing> getOfferedSkills(int userId) {
        return skillDAO.findOfferedByUser(userId);
    }

    /** Returns only WANT listings for a user. */
    public List<SkillListing> getWantedSkills(int userId) {
        return skillDAO.findWantedByUser(userId);
    }

    /**
     * Adds a skill listing for a student.
     *
     * Validates:
     *   - Skill name not blank
     *   - Description max 500 chars
     *
     * @return the new SkillListing with its DB-assigned ID
     */
    public SkillListing addListing(int userId, Skill skill, ListingType type,
                                   Proficiency proficiency, String description) {
        if (!ValidationUtils.notBlank(skill.getName())) {
            throw new IllegalArgumentException("Skill name is required.");
        }
        String desc = ValidationUtils.clamp(description, 500);
        SkillListing listing = new SkillListing(userId, skill, type, proficiency, desc);
        int id = skillDAO.insertListing(listing);
        listing.setListingId(id);
        return listing;
    }

    /** Updates an existing listing's proficiency and description. */
    public void updateListing(int listingId, Proficiency proficiency, String description) {
        String desc = ValidationUtils.clamp(description, 500);
        skillDAO.updateListing(listingId, proficiency, desc);
    }

    /** Removes a skill listing. */
    public void removeListing(int listingId) {
        skillDAO.deleteListing(listingId);
    }
}
