package skillswap.service;

import skillswap.dao.BookingDAO;
import skillswap.model.BookingStatus;
import skillswap.model.SessionBooking;
import skillswap.model.Skill;
import skillswap.util.InvalidBookingException;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;

/**
 * Service: Session booking lifecycle management.
 *
 * OOP CONCEPTS:
 * - Composition: BookingService HAS-A BookingDAO
 * - Custom exception: InvalidBookingException thrown for rule violations
 * - try-catch-finally: used in confirmBooking() and cancelBooking()
 * - Enum: BookingStatus.canTransitionTo() drives all state changes
 *
 * BUSINESS RULES enforced here:
 *   - Booking date must be today or future
 *   - Duration must be > 0
 *   - Cannot book yourself (requester != provider)
 *   - No scheduling conflicts (overlapping confirmed sessions)
 *   - Status transitions must be valid (REQUESTED→CONFIRMED→COMPLETED, etc.)
 *   - Cancellation requires a reason
 */
public class BookingService {

    private final BookingDAO bookingDAO = new BookingDAO();

    // ----------------------------------------------------------------
    // CREATE
    // ----------------------------------------------------------------

    /**
     * Creates and persists a new booking in REQUESTED status.
     *
     * @throws InvalidBookingException on any rule violation
     */
    public SessionBooking createBooking(int requesterId, int providerId,
                                        Skill skill, LocalDate date, LocalTime time,
                                        int durationMinutes)
            throws InvalidBookingException {

        // Rule 1: Cannot book yourself
        if (requesterId == providerId) {
            throw new InvalidBookingException("You cannot book a session with yourself.");
        }

        // Rule 2: Date must be today or in the future
        if (date.isBefore(LocalDate.now())) {
            throw new InvalidBookingException(
                "Session date must be today or in the future. Got: " + date);
        }

        // Rule 3: Duration must be positive
        if (durationMinutes <= 0) {
            throw new InvalidBookingException("Duration must be greater than 0 minutes.");
        }

        // Rule 4: Check for scheduling conflicts
        checkConflicts(requesterId, providerId, date, time, durationMinutes, -1);

        // All validations passed — create and persist the booking
        SessionBooking booking = new SessionBooking(
            0, requesterId, providerId, skill, date, time,
            durationMinutes, BookingStatus.REQUESTED, null
        );

        int id = bookingDAO.insertBooking(booking);
        booking.setBookingId(id);
        return booking;
    }

    // ----------------------------------------------------------------
    // STATUS TRANSITIONS
    // ----------------------------------------------------------------

    /**
     * Confirms a REQUESTED booking.
     * OOP: try-catch-finally — cleanup logged in finally block.
     *
     * @throws InvalidBookingException if transition is invalid
     */
    public void confirmBooking(int bookingId) throws InvalidBookingException {
        // try-catch-finally — OOP CONCEPT
        SessionBooking booking = null;
        try {
            booking = loadOrThrow(bookingId);
            booking.transitionTo(BookingStatus.CONFIRMED);       // validates transition
            bookingDAO.updateStatus(bookingId, BookingStatus.CONFIRMED, null);

        } catch (InvalidBookingException e) {
            throw e;  // re-throw as-is
        } finally {
            // finally block: could be used for audit logging in production
            if (booking != null) {
                System.out.println("[Booking] Confirm attempted for booking #" + bookingId
                    + " — status now: " + (booking.getStatus()));
            }
        }
    }

    /**
     * Marks a CONFIRMED booking as COMPLETED.
     *
     * @throws InvalidBookingException if not in CONFIRMED state
     */
    public void completeBooking(int bookingId) throws InvalidBookingException {
        SessionBooking booking = loadOrThrow(bookingId);
        booking.transitionTo(BookingStatus.COMPLETED);
        bookingDAO.updateStatus(bookingId, BookingStatus.COMPLETED, null);
    }

    /**
     * Cancels a REQUESTED or CONFIRMED booking with a reason.
     * OOP: Calls the Cancellable interface method on the model object.
     *
     * @throws InvalidBookingException if already COMPLETED or CANCELLED,
     *                                  or if reason is blank
     */
    public void cancelBooking(int bookingId, String reason) throws InvalidBookingException {
        if (reason == null || reason.isBlank()) {
            throw new InvalidBookingException("A cancellation reason is required.");
        }
        SessionBooking booking = loadOrThrow(bookingId);

        // Calls the Cancellable.cancel() interface method — OOP CONCEPT
        booking.cancel(reason);
        bookingDAO.updateStatus(bookingId, BookingStatus.CANCELLED, reason);
    }

    // ----------------------------------------------------------------
    // QUERIES
    // ----------------------------------------------------------------

    /** Returns all bookings (any status) involving the given user. */
    public List<SessionBooking> getBookingsForUser(int userId) {
        return bookingDAO.findByUser(userId);
    }

    /** Returns bookings filtered by status. */
    public List<SessionBooking> getBookingsByStatus(int userId, BookingStatus status) {
        return bookingDAO.findByUserAndStatus(userId, status);
    }

    /** Loads a single booking by ID. */
    public SessionBooking getBookingById(int bookingId) throws InvalidBookingException {
        return loadOrThrow(bookingId);
    }

    /** Count completed sessions as teacher. */
    public int countCompletedAsProvider(int userId) {
        return bookingDAO.countCompletedAsProvider(userId);
    }

    /** Count completed sessions as learner. */
    public int countCompletedAsRequester(int userId) {
        return bookingDAO.countCompletedAsRequester(userId);
    }

    // ----------------------------------------------------------------
    // Helpers
    // ----------------------------------------------------------------

    /**
     * Loads a booking or throws if not found.
     */
    private SessionBooking loadOrThrow(int bookingId) throws InvalidBookingException {
        return bookingDAO.findById(bookingId)
            .orElseThrow(() -> new InvalidBookingException(
                "Booking #" + bookingId + " not found."));
    }

    /**
     * Checks whether the proposed session would conflict with any existing
     * CONFIRMED sessions for either the requester or provider on the same date.
     *
     * Conflict = same date, and the new session's time window overlaps
     * with any existing confirmed session's window.
     *
     * @param excludeBookingId pass -1 when creating; pass the booking's own ID when editing
     */
    private void checkConflicts(int requesterId, int providerId,
                                 LocalDate date, LocalTime time,
                                 int durationMinutes, int excludeBookingId)
            throws InvalidBookingException {

        // Check requester's schedule
        checkUserConflict(requesterId, date, time, durationMinutes, excludeBookingId);
        // Check provider's schedule
        checkUserConflict(providerId, date, time, durationMinutes, excludeBookingId);
    }

    private void checkUserConflict(int userId, LocalDate date, LocalTime startTime,
                                    int durationMinutes, int excludeId)
            throws InvalidBookingException {

        List<SessionBooking> existing = bookingDAO.findConfirmedOnDate(userId, date);
        LocalTime endTime = startTime.plusMinutes(durationMinutes);

        for (SessionBooking b : existing) {
            if (b.getBookingId() == excludeId) continue;

            LocalTime existStart = b.getSessionTime();
            LocalTime existEnd   = existStart.plusMinutes(b.getDurationMinutes());

            // Overlap: new starts before existing ends AND new ends after existing starts
            boolean overlaps = startTime.isBefore(existEnd) && endTime.isAfter(existStart);
            if (overlaps) {
                throw new InvalidBookingException(
                    "Scheduling conflict: a confirmed session already exists on "
                    + date + " from " + existStart + " to " + existEnd + ".");
            }
        }
    }
}
