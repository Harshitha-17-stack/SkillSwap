package skillswap.service;

import org.mindrot.jbcrypt.BCrypt;
import skillswap.dao.UserDAO;
import skillswap.model.Student;
import skillswap.model.User;
import skillswap.util.DatabaseException;
import skillswap.util.DuplicateUserException;
import skillswap.util.ValidationUtils;

import java.util.Optional;

/**
 * Service: Authentication and registration.
 *
 * OOP CONCEPTS:
 * - Composition: AuthService HAS-A UserDAO (not extends)
 * - Encapsulation: BCrypt hashing hidden inside this class
 * - Custom exceptions: DuplicateUserException thrown on duplicate email
 * - try-catch-finally: used in login() for comprehensive error handling
 */
public class AuthService {

    // OOP CONCEPT: Composition — the service owns its DAO
    private final UserDAO userDAO = new UserDAO();

    // Singleton: currently logged-in user (null = nobody logged in)
    private static User currentUser = null;

    // ----------------------------------------------------------------
    // REGISTRATION
    // ----------------------------------------------------------------

    /**
     * Registers a new student account.
     *
     * Business rules enforced:
     *   - Valid email format
     *   - Email not already taken
     *   - Password at least 6 characters
     *   - Name not blank
     *
     * OOP: throws DuplicateUserException (custom checked exception)
     *
     * @return the newly created Student with their DB-assigned userId
     */
    public Student register(String name, String email, String password,
                            String department, int yearOfStudy, String bio)
            throws DuplicateUserException {

        // --- Validate inputs ---
        if (!ValidationUtils.notBlank(name)) {
            throw new IllegalArgumentException("Name is required.");
        }
        if (!ValidationUtils.isValidEmail(email)) {
            throw new IllegalArgumentException("Invalid email address.");
        }
        if (password == null || password.length() < 6) {
            throw new IllegalArgumentException("Password must be at least 6 characters.");
        }

        // --- Check for duplicate email ---
        if (userDAO.emailExists(email)) {
            // OOP CONCEPT: Custom exception thrown with meaningful message
            throw new DuplicateUserException(
                "An account with email '" + email + "' already exists.");
        }

        // --- Hash the password (never store plain text) ---
        String hash = BCrypt.hashpw(password, BCrypt.gensalt(12));

        // --- Create Student object and persist ---
        Student student = new Student(0, name, email, hash, department, yearOfStudy, bio, 0);
        int newId = userDAO.insertUser(student, bio, 0);
        // Return a fresh Student with the real DB-assigned ID
        return new Student(newId, name, email, hash, department, yearOfStudy, bio, 0);
    }

    // ----------------------------------------------------------------
    // LOGIN
    // ----------------------------------------------------------------

    /**
     * Authenticates a user by email + password.
     * OOP CONCEPT: try-catch-finally — ensures cleanup even on error.
     *
     * @return the authenticated User (Student or Administrator)
     * @throws IllegalArgumentException if credentials are invalid
     */
    public User login(String email, String password) {
        // try-catch-finally demonstrates OOP custom exception handling
        try {
            Optional<User> found = userDAO.findByEmail(email);
            if (found.isEmpty()) {
                throw new IllegalArgumentException("No account found for: " + email);
            }
            User user = found.get();

            // BCrypt.checkpw does the timing-safe comparison
            if (!BCrypt.checkpw(password, user.getPasswordHash())) {
                throw new IllegalArgumentException("Incorrect password.");
            }

            user.login();          // marks loggedIn = true on the model object
            currentUser = user;    // store in session
            return user;

        } catch (DatabaseException e) {
            // Wrap DB errors into a user-friendly message
            throw new IllegalArgumentException("Login failed due to a system error.", e);
        } finally {
            // finally block always runs — good place for audit logs in production
            System.out.println("[Auth] Login attempt for: " + email);
        }
    }

    // ----------------------------------------------------------------
    // LOGOUT
    // ----------------------------------------------------------------

    /** Logs out the current user and clears the session. */
    public void logout() {
        if (currentUser != null) {
            currentUser.logout();
            currentUser = null;
        }
    }

    // ----------------------------------------------------------------
    // SESSION ACCESS
    // ----------------------------------------------------------------

    /** Returns the currently logged-in user, or null. */
    public static User getCurrentUser() {
        return currentUser;
    }

    /** Convenience: returns true if someone is logged in. */
    public static boolean isLoggedIn() {
        return currentUser != null;
    }
}
