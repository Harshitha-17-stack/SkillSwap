package skillswap.service;

import skillswap.dao.BookingDAO;
import skillswap.dao.FeedbackDAO;
import skillswap.model.BookingStatus;
import skillswap.model.Feedback;
import skillswap.model.SessionBooking;
import skillswap.util.DuplicateFeedbackException;
import skillswap.util.InvalidBookingException;
import skillswap.util.InvalidRatingException;

import java.time.LocalDateTime;
import java.util.List;

/**
 * Service: Feedback submission and retrieval.
 *
 * BUSINESS RULES:
 *   - Only COMPLETED sessions can be rated
 *   - Rating must be 1–5
 *   - One review per reviewer per booking (duplicate check + DB UNIQUE)
 *   - Cannot review a CANCELLED session
 *
 * OOP CONCEPTS:
 * - Composition: FeedbackService HAS-A FeedbackDAO, BookingDAO
 * - Custom exceptions: InvalidRatingException, DuplicateFeedbackException
 * - Calls SessionBooking.submitRating() — Rateable interface method
 */
public class FeedbackService {

    private final FeedbackDAO feedbackDAO = new FeedbackDAO();
    private final BookingDAO  bookingDAO  = new BookingDAO();

    // ----------------------------------------------------------------
    // SUBMIT
    // ----------------------------------------------------------------

    /**
     * Submits a rating and optional comment for a completed session.
     *
     * @param bookingId  the booking being rated
     * @param reviewerId the user submitting the review
     * @param revieweeId the user being reviewed
     * @param rating     integer 1–5
     * @param comment    optional written feedback
     *
     * @throws InvalidBookingException     if session is not COMPLETED
     * @throws InvalidRatingException      if rating is out of range
     * @throws DuplicateFeedbackException  if reviewer already reviewed this booking
     */
    public Feedback submitFeedback(int bookingId, int reviewerId, int revieweeId,
                                    int rating, String comment)
            throws InvalidBookingException, InvalidRatingException, DuplicateFeedbackException {

        // --- Load and validate the booking ---
        SessionBooking booking = bookingDAO.findById(bookingId)
            .orElseThrow(() -> new InvalidBookingException(
                "Booking #" + bookingId + " not found."));

        // Delegate rating validation to the model's Rateable method
        // OOP CONCEPT: Calling interface method (Rateable) on the model object
        booking.submitRating(rating, comment);   // throws InvalidRatingException

        // --- Duplicate review check ---
        if (feedbackDAO.hasReviewed(bookingId, reviewerId)) {
            throw new DuplicateFeedbackException(
                "You have already submitted a review for this session.");
        }

        // --- Persist ---
        Feedback fb = new Feedback(
            0, bookingId, reviewerId, revieweeId,
            rating, comment, LocalDateTime.now()
        );
        int id = feedbackDAO.insertFeedback(fb);

        return new Feedback(id, bookingId, reviewerId, revieweeId,
                            rating, comment, fb.getCreatedAt());
    }

    // ----------------------------------------------------------------
    // QUERIES
    // ----------------------------------------------------------------

    /** Returns all feedback received by a user (for their public profile). */
    public List<Feedback> getReceivedFeedback(int userId) {
        return feedbackDAO.findReceivedByUser(userId);
    }

    /** Returns all feedback given by a user. */
    public List<Feedback> getGivenFeedback(int userId) {
        return feedbackDAO.findGivenByUser(userId);
    }

    /** Returns the average rating (0.0 if none). */
    public double getAverageRating(int userId) {
        return feedbackDAO.getAverageRating(userId);
    }

    /** Returns true if the reviewer has already reviewed this booking. */
    public boolean hasReviewed(int bookingId, int reviewerId) {
        return feedbackDAO.hasReviewed(bookingId, reviewerId);
    }

    /** Admin: removes feedback that violates platform rules. */
    public void moderateFeedback(int feedbackId) {
        feedbackDAO.deleteFeedback(feedbackId);
    }
}
