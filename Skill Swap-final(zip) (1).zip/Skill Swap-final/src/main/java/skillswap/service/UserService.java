package skillswap.service;

import skillswap.dao.FeedbackDAO;
import skillswap.dao.SkillDAO;
import skillswap.dao.UserDAO;
import skillswap.model.SkillListing;
import skillswap.model.Student;
import skillswap.model.User;
import skillswap.util.ValidationUtils;

import java.util.List;
import java.util.Optional;

/**
 * Service: User profile retrieval and management.
 * Assembles rich Student objects with skill listings and ratings
 * for display in the profile and admin screens.
 *
 * OOP CONCEPT: Composition — UserService HAS-A UserDAO, SkillDAO, FeedbackDAO.
 */
public class UserService {

    private final UserDAO     userDAO     = new UserDAO();
    private final SkillDAO    skillDAO    = new SkillDAO();
    private final FeedbackDAO feedbackDAO = new FeedbackDAO();

    // ----------------------------------------------------------------
    // PROFILE
    // ----------------------------------------------------------------

    /**
     * Returns the full user by ID, or empty if not found.
     */
    public Optional<User> getUserById(int userId) {
        return userDAO.findById(userId);
    }

    /**
     * Returns a Student with their skill listings loaded into
     * the in-memory lists (offeredSkills / wantedSkills).
     * Used to populate the My Skills and Profile screens.
     */
    public Optional<Student> getStudentWithSkills(int userId) {
        Optional<User> user = userDAO.findById(userId);
        if (user.isEmpty() || !(user.get() instanceof Student student)) {
            return Optional.empty();
        }

        // Load listings from DB and populate the Student's in-memory collections
        List<SkillListing> listings = skillDAO.findListingsByUser(userId);
        for (SkillListing l : listings) {
            student.addSkill(l);
        }
        return Optional.of(student);
    }

    /**
     * Returns the average rating for a user.
     */
    public double getAverageRating(int userId) {
        return feedbackDAO.getAverageRating(userId);
    }

    // ----------------------------------------------------------------
    // UPDATE
    // ----------------------------------------------------------------

    /**
     * Updates a student's profile fields.
     *
     * Validates:
     *   - name not blank
     *   - yearOfStudy in range 1–10
     */
    public void updateProfile(int userId, String name, String department,
                               int yearOfStudy, String bio) {
        if (!ValidationUtils.notBlank(name)) {
            throw new IllegalArgumentException("Name is required.");
        }
        if (yearOfStudy < 1 || yearOfStudy > 10) {
            throw new IllegalArgumentException("Year of study must be between 1 and 10.");
        }
        String clampedBio = ValidationUtils.clamp(bio, 500);
        userDAO.updateProfile(userId, name, department, yearOfStudy, clampedBio);
    }

    // ----------------------------------------------------------------
    // ADMIN
    // ----------------------------------------------------------------

    /** Returns all users for the Admin screen. */
    public List<User> getAllUsers() {
        return userDAO.findAll();
    }

    /** Deletes a user account (admin only). */
    public void deleteUser(int userId) {
        userDAO.deleteUser(userId);
    }
}
