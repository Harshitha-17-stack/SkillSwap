package skillswap.service;

import skillswap.dao.SkillDAO;
import skillswap.dao.UserDAO;
import skillswap.model.MatchResult;
import skillswap.model.MatchResult.MatchType;
import skillswap.model.Skill;
import skillswap.model.SkillListing;
import skillswap.model.SkillListing.ListingType;
import skillswap.model.Student;

import java.util.*;
import java.util.stream.Collectors;

/**
 * Service: Peer-to-peer skill matching algorithm.
 *
 * OOP CONCEPTS DEMONSTRATED HERE:
 *
 * 1. METHOD OVERLOADING — findMatches() has two signatures:
 *      findMatches(int currentUserId)                   — find all matches
 *      findMatches(int currentUserId, String skillName) — filter by skill name
 *      findMatches(int currentUserId, String skillName, String level) — filter by skill + level
 *
 * 2. Composition — MatchingService HAS-A SkillDAO and UserDAO
 *
 * 3. Collections — HashMap for O(1) lookup of skills by name
 *
 * MATCHING RULES:
 *   STRONG  (100% base score) — A offers what B wants AND B offers what A wants
 *   PARTIAL (50% base score)  — only one direction matches
 */
public class MatchingService {

    private final SkillDAO skillDAO = new SkillDAO();
    private final UserDAO  userDAO  = new UserDAO();

    // ================================================================
    // METHOD OVERLOADING — three versions of findMatches()
    // ================================================================

    /**
     * Overload 1: Find ALL possible matches for the current user.
     * OOP CONCEPT: Method Overloading — same name, different parameters.
     */
    public List<MatchResult> findMatches(int currentUserId) {
        return findMatches(currentUserId, null, null);
    }

    /**
     * Overload 2: Find matches filtered by skill name.
     * OOP CONCEPT: Method Overloading — narrows the result set.
     */
    public List<MatchResult> findMatches(int currentUserId, String skillName) {
        return findMatches(currentUserId, skillName, null);
    }

    /**
     * Overload 3: Find matches filtered by skill name AND proficiency level.
     * OOP CONCEPT: Method Overloading — most specific overload; contains core logic.
     *
     * Algorithm:
     *   1. Load the current user's OFFER and WANT listings.
     *   2. For every other student, check if they offer what the current user wants.
     *   3. If mutual (they also want what the current user offers) → STRONG match.
     *   4. Otherwise → PARTIAL match.
     *   5. Sort by score descending.
     */
    public List<MatchResult> findMatches(int currentUserId, String skillName, String level) {

        // --- Step 1: Load current user's listings ---
        List<SkillListing> myOffers = skillDAO.findOfferedByUser(currentUserId);
        List<SkillListing> myWants  = skillDAO.findWantedByUser(currentUserId);

        // Build a Set of skill names I offer and skill names I want (lower-case for comparison)
        // OOP CONCEPT: Collections — Set for O(1) lookup
        Set<String> myOfferNames = myOffers.stream()
            .map(l -> l.getSkill().getName().toLowerCase())
            .collect(Collectors.toSet());

        Set<String> myWantNames = myWants.stream()
            .map(l -> l.getSkill().getName().toLowerCase())
            .collect(Collectors.toSet());

        // --- Step 2: Iterate over all other students ---
        List<Student> allStudents = userDAO.findAllStudents();
        List<MatchResult> results = new ArrayList<>();

        for (Student other : allStudents) {
            if (other.getUserId() == currentUserId) continue; // skip self

            List<SkillListing> theirOffers = skillDAO.findOfferedByUser(other.getUserId());
            List<SkillListing> theirWants  = skillDAO.findWantedByUser(other.getUserId());

            // What they offer that I want
            List<SkillListing> relevantOffers = theirOffers.stream()
                .filter(l -> myWantNames.contains(l.getSkill().getName().toLowerCase()))
                .collect(Collectors.toList());

            if (relevantOffers.isEmpty()) continue; // no basis for a match

            // Apply skill-name filter (Overload 2 & 3)
            if (skillName != null && !skillName.isBlank()) {
                relevantOffers = relevantOffers.stream()
                    .filter(l -> l.getSkill().getName()
                                  .toLowerCase()
                                  .contains(skillName.toLowerCase()))
                    .collect(Collectors.toList());
                if (relevantOffers.isEmpty()) continue;
            }

            // Apply level filter (Overload 3 only)
            if (level != null && !level.isBlank()) {
                relevantOffers = relevantOffers.stream()
                    .filter(l -> l.getProficiency().name().equalsIgnoreCase(level))
                    .collect(Collectors.toList());
                if (relevantOffers.isEmpty()) continue;
            }

            // --- Step 3 & 4: Determine match type ---
            // What they want that I offer
            boolean isMutual = theirWants.stream()
                .anyMatch(l -> myOfferNames.contains(l.getSkill().getName().toLowerCase()));

            for (SkillListing theirOffer : relevantOffers) {
                // The reciprocal skill (what I offer that they want) for explanation
                String youOffer = null;
                if (isMutual) {
                    youOffer = theirWants.stream()
                        .filter(l -> myOfferNames.contains(l.getSkill().getName().toLowerCase()))
                        .findFirst()
                        .map(l -> l.getSkill().getName())
                        .orElse(null);
                }

                MatchType type  = isMutual ? MatchType.STRONG : MatchType.PARTIAL;
                int       score = computeScore(type, theirOffer);
                String    explanation = buildExplanation(
                    other.getName(), theirOffer.getSkill().getName(), youOffer);

                results.add(new MatchResult(other, type, score, explanation,
                                            theirOffer.getSkill().getName(), youOffer));
            }
        }

        // --- Step 5: Sort — STRONG first, then by score desc ---
        results.sort(Comparator
            .comparing((MatchResult r) -> r.getMatchType() == MatchType.STRONG ? 0 : 1)
            .thenComparingInt(r -> -r.getCompatibilityScore()));

        return results;
    }

    // ----------------------------------------------------------------
    // Helpers
    // ----------------------------------------------------------------

    /**
     * Computes a compatibility score (0–100).
     * STRONG mutual match starts at 90; PARTIAL at 50.
     * Proficiency level adds up to 10 bonus points.
     */
    private int computeScore(MatchType type, SkillListing theirOffer) {
        int base = type == MatchType.STRONG ? 90 : 50;
        int profBonus = switch (theirOffer.getProficiency()) {
            case ADVANCED     -> 10;
            case INTERMEDIATE -> 5;
            case BEGINNER     -> 0;
        };
        return Math.min(100, base + profBonus);
    }

    /**
     * Builds a human-readable match explanation.
     * Examples:
     *   "Priya teaches Graphic Design; Priya wants Python and you offer Python"
     *   "Priya teaches Graphic Design (partial match)"
     */
    private String buildExplanation(String theirName, String theyOffer, String youOffer) {
        if (youOffer != null) {
            return theirName + " teaches " + theyOffer
                 + "; " + theirName + " wants " + youOffer
                 + " and you can teach it — perfect exchange!";
        }
        return theirName + " teaches " + theyOffer
             + " which you want to learn (partial match).";
    }
}
