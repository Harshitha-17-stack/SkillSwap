package skillswap.service;

import skillswap.dao.BookingDAO;
import skillswap.dao.CreditDAO;
import skillswap.dao.UserDAO;
import skillswap.model.BookingStatus;
import skillswap.model.CreditTransaction;
import skillswap.model.SessionBooking;
import skillswap.util.DatabaseException;
import skillswap.util.InvalidBookingException;

import java.time.LocalDateTime;
import java.util.List;

/**
 * Service: Credit award and transaction history.
 *
 * BUSINESS RULES:
 *   - 10 credits awarded to the PROVIDER (teacher) per completed session
 *   - Credits awarded exactly ONCE per booking (enforced by DB UNIQUE + code check)
 *   - Cancelled sessions earn zero credits
 *   - awardCredits() is idempotent — safe to call multiple times
 *
 * OOP CONCEPTS:
 * - Composition: CreditService HAS-A CreditDAO, BookingDAO, UserDAO
 * - Custom exception + DatabaseException used for error flow
 */
public class CreditService {

    private static final int CREDITS_PER_SESSION = 10;

    private final CreditDAO  creditDAO  = new CreditDAO();
    private final BookingDAO bookingDAO = new BookingDAO();
    private final UserDAO    userDAO    = new UserDAO();

    // ----------------------------------------------------------------
    // AWARD CREDITS
    // ----------------------------------------------------------------

    /**
     * Awards credits to the provider of a completed session.
     *
     * Idempotent: calling this twice for the same booking is safe —
     * the second call is a no-op (returns without error).
     *
     * @throws InvalidBookingException if the booking is not COMPLETED
     * @throws DatabaseException       if a DB error occurs (other than duplicate)
     */
    public void awardCredits(int bookingId) throws InvalidBookingException {
        // Load the booking
        SessionBooking booking = bookingDAO.findById(bookingId)
            .orElseThrow(() -> new InvalidBookingException(
                "Booking #" + bookingId + " not found."));

        // Rule: only completed sessions earn credits
        if (booking.getStatus() != BookingStatus.COMPLETED) {
            throw new InvalidBookingException(
                "Credits can only be awarded for COMPLETED sessions. "
                + "Current status: " + booking.getStatus().getLabel());
        }

        // Rule: award only once — check in code BEFORE hitting the DB UNIQUE constraint
        if (creditDAO.existsForBooking(bookingId)) {
            System.out.println("[Credits] Credits already awarded for booking #" + bookingId
                + " — skipping.");
            return;   // idempotent no-op
        }

        int providerId = booking.getProviderId();
        String reason  = "Taught " + booking.getSkill().getName()
                       + " to " + booking.getRequesterName();

        // Record the transaction
        CreditTransaction tx = new CreditTransaction(
            0, providerId, bookingId,
            CREDITS_PER_SESSION, reason, LocalDateTime.now()
        );
        creditDAO.insertTransaction(tx);

        // Update the provider's cached balance in the users table
        List<CreditTransaction> allTx = creditDAO.findByUser(providerId);
        int newBalance = allTx.stream().mapToInt(CreditTransaction::getAmount).sum();
        userDAO.updateCreditBalance(providerId, newBalance);

        System.out.println("[Credits] +" + CREDITS_PER_SESSION
            + " credited to userId=" + providerId + " for booking #" + bookingId);
    }

    // ----------------------------------------------------------------
    // QUERIES
    // ----------------------------------------------------------------

    /**
     * Returns all credit transactions for a user, newest first.
     */
    public List<CreditTransaction> getTransactionHistory(int userId) {
        return creditDAO.findByUser(userId);
    }

    /**
     * Returns the current credit balance as the sum of all transactions.
     * Cross-checks against the cached users.credit_balance field.
     */
    public int getBalance(int userId) {
        return creditDAO.findByUser(userId)
            .stream()
            .mapToInt(CreditTransaction::getAmount)
            .sum();
    }
}
