package skillswap.dao;

import skillswap.model.CreditTransaction;
import skillswap.util.DatabaseException;
import skillswap.util.DatabaseManager;

import java.sql.*;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

/**
 * DAO for the 'credit_transactions' table.
 * The UNIQUE constraint on booking_id prevents double-awarding at the DB level;
 * CreditService checks it in code first for a user-friendly error message.
 */
public class CreditDAO {

    private final DatabaseManager db = DatabaseManager.getInstance();

    // ----------------------------------------------------------------
    // CREATE
    // ----------------------------------------------------------------

    /**
     * Records a credit award and returns the new transaction ID.
     * @throws DatabaseException if a transaction already exists for this booking_id
     */
    public int insertTransaction(CreditTransaction tx) {
        String sql = """
            INSERT INTO credit_transactions (user_id, booking_id, amount, reason)
            VALUES (?, ?, ?, ?)
            """;
        try (PreparedStatement ps = db.getConnection().prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {

            ps.setInt   (1, tx.getUserId());
            if (tx.getBookingId() > 0) ps.setInt(2, tx.getBookingId());
            else                        ps.setNull(2, Types.INTEGER);
            ps.setInt   (3, tx.getAmount());
            ps.setString(4, tx.getReason());
            ps.executeUpdate();

            try (ResultSet keys = ps.getGeneratedKeys()) {
                if (keys.next()) return keys.getInt(1);
            }
        } catch (SQLException e) {
            if (e.getMessage() != null && e.getMessage().contains("UNIQUE")) {
                throw new DatabaseException(
                    "Credits already awarded for booking #" + tx.getBookingId());
            }
            throw new DatabaseException("Failed to record credit transaction.", e);
        }
        throw new DatabaseException("Credit insert returned no generated key.");
    }

    // ----------------------------------------------------------------
    // READ
    // ----------------------------------------------------------------

    /** Returns all transactions for a user, newest first. */
    public List<CreditTransaction> findByUser(int userId) {
        List<CreditTransaction> list = new ArrayList<>();
        String sql = """
            SELECT * FROM credit_transactions
            WHERE user_id = ?
            ORDER BY created_at DESC
            """;
        try (PreparedStatement ps = db.getConnection().prepareStatement(sql)) {

            ps.setInt(1, userId);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) list.add(mapRow(rs));
            }
        } catch (SQLException e) {
            throw new DatabaseException("Failed to load credit transactions.", e);
        }
        return list;
    }

    /** Returns true if a transaction already exists for the given booking_id. */
    public boolean existsForBooking(int bookingId) {
        String sql = "SELECT COUNT(*) FROM credit_transactions WHERE booking_id = ?";
        try (PreparedStatement ps = db.getConnection().prepareStatement(sql)) {

            ps.setInt(1, bookingId);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next() && rs.getInt(1) > 0;
            }
        } catch (SQLException e) {
            throw new DatabaseException("Failed to check credit transaction existence.", e);
        }
    }

    // ----------------------------------------------------------------
    // Row mapper
    // ----------------------------------------------------------------

    private CreditTransaction mapRow(ResultSet rs) throws SQLException {
        String tsStr = rs.getString("created_at");
        LocalDateTime createdAt = tsStr != null
            ? LocalDateTime.parse(tsStr.replace(" ", "T"))
            : LocalDateTime.now();

        return new CreditTransaction(
            rs.getInt   ("tx_id"),
            rs.getInt   ("user_id"),
            rs.getInt   ("booking_id"),   // 0 if NULL
            rs.getInt   ("amount"),
            rs.getString("reason"),
            createdAt
        );
    }
}
