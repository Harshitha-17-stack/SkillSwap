package skillswap.dao;

import skillswap.model.BookingStatus;
import skillswap.model.SessionBooking;
import skillswap.model.Skill;
import skillswap.util.DatabaseException;
import skillswap.util.DatabaseManager;

import java.sql.*;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

/**
 * DAO for the 'bookings' table.
 * All SQL uses PreparedStatements. try-with-resources on every connection.
 */
public class BookingDAO {

    private final DatabaseManager db = DatabaseManager.getInstance();

    // ----------------------------------------------------------------
    // CREATE
    // ----------------------------------------------------------------

    /**
     * Inserts a new booking and returns its generated ID.
     */
    public int insertBooking(SessionBooking booking) {
        String sql = """
            INSERT INTO bookings
              (requester_id, provider_id, skill_id,
               session_date, session_time, duration_minutes, status)
            VALUES (?, ?, ?, ?, ?, ?, ?)
            """;
        try (PreparedStatement ps = db.getConnection().prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {

            ps.setInt   (1, booking.getRequesterId());
            ps.setInt   (2, booking.getProviderId());
            ps.setInt   (3, booking.getSkill().getSkillId());
            ps.setString(4, booking.getSessionDate().toString());
            ps.setString(5, booking.getSessionTime().toString());
            ps.setInt   (6, booking.getDurationMinutes());
            ps.setString(7, booking.getStatus().name());
            ps.executeUpdate();

            try (ResultSet keys = ps.getGeneratedKeys()) {
                if (keys.next()) return keys.getInt(1);
            }
        } catch (SQLException e) {
            throw new DatabaseException("Failed to insert booking.", e);
        }
        throw new DatabaseException("Booking insert returned no generated key.");
    }

    // ----------------------------------------------------------------
    // READ
    // ----------------------------------------------------------------

    /** Finds a booking by primary key, with joined skill and user names. */
    public Optional<SessionBooking> findById(int bookingId) {
        String sql = buildJoinedSql("b.booking_id = ?");
        try (PreparedStatement ps = db.getConnection().prepareStatement(sql)) {

            ps.setInt(1, bookingId);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) return Optional.of(mapRow(rs));
            }
        } catch (SQLException e) {
            throw new DatabaseException("Failed to find booking by id.", e);
        }
        return Optional.empty();
    }

    /**
     * Returns all bookings where the user is either the requester or provider,
     * ordered by date desc (most recent first).
     */
    public List<SessionBooking> findByUser(int userId) {
        String sql = buildJoinedSql("b.requester_id = ? OR b.provider_id = ?")
                   + " ORDER BY b.session_date DESC, b.session_time DESC";
        try (PreparedStatement ps = db.getConnection().prepareStatement(sql)) {

            ps.setInt(1, userId);
            ps.setInt(2, userId);
            return executeAndMap(ps);

        } catch (SQLException e) {
            throw new DatabaseException("Failed to load user bookings.", e);
        }
    }

    /** Returns bookings for a user filtered by status. */
    public List<SessionBooking> findByUserAndStatus(int userId, BookingStatus status) {
        String sql = buildJoinedSql(
                "(b.requester_id = ? OR b.provider_id = ?) AND b.status = ?")
                + " ORDER BY b.session_date ASC";
        try (PreparedStatement ps = db.getConnection().prepareStatement(sql)) {

            ps.setInt   (1, userId);
            ps.setInt   (2, userId);
            ps.setString(3, status.name());
            return executeAndMap(ps);

        } catch (SQLException e) {
            throw new DatabaseException("Failed to load bookings by status.", e);
        }
    }

    /**
     * Returns all CONFIRMED bookings for a user on a given date.
     * Used to detect scheduling conflicts.
     */
    public List<SessionBooking> findConfirmedOnDate(int userId, LocalDate date) {
        String sql = buildJoinedSql(
                "(b.requester_id = ? OR b.provider_id = ?) "
              + "AND b.session_date = ? AND b.status = 'CONFIRMED'");
        try (PreparedStatement ps = db.getConnection().prepareStatement(sql)) {

            ps.setInt   (1, userId);
            ps.setInt   (2, userId);
            ps.setString(3, date.toString());
            return executeAndMap(ps);

        } catch (SQLException e) {
            throw new DatabaseException("Failed to check schedule conflicts.", e);
        }
    }

    /** Returns the count of completed sessions where the user was the provider (teacher). */
    public int countCompletedAsProvider(int userId) {
        String sql = "SELECT COUNT(*) FROM bookings WHERE provider_id = ? AND status = 'COMPLETED'";
        try (PreparedStatement ps = db.getConnection().prepareStatement(sql)) {

            ps.setInt(1, userId);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next() ? rs.getInt(1) : 0;
            }
        } catch (SQLException e) {
            throw new DatabaseException("Failed to count completed sessions.", e);
        }
    }

    /** Returns the count of completed sessions where the user was the requester (learner). */
    public int countCompletedAsRequester(int userId) {
        String sql = "SELECT COUNT(*) FROM bookings WHERE requester_id = ? AND status = 'COMPLETED'";
        try (PreparedStatement ps = db.getConnection().prepareStatement(sql)) {

            ps.setInt(1, userId);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next() ? rs.getInt(1) : 0;
            }
        } catch (SQLException e) {
            throw new DatabaseException("Failed to count completed sessions.", e);
        }
    }

    // ----------------------------------------------------------------
    // UPDATE
    // ----------------------------------------------------------------

    /** Updates the status (and optional cancel reason) of a booking. */
    public void updateStatus(int bookingId, BookingStatus newStatus, String cancelReason) {
        String sql = "UPDATE bookings SET status = ?, cancel_reason = ? WHERE booking_id = ?";
        try (PreparedStatement ps = db.getConnection().prepareStatement(sql)) {

            ps.setString(1, newStatus.name());
            ps.setString(2, cancelReason);   // null if not cancelling
            ps.setInt   (3, bookingId);
            ps.executeUpdate();

        } catch (SQLException e) {
            throw new DatabaseException("Failed to update booking status.", e);
        }
    }

    // ----------------------------------------------------------------
    // Helpers
    // ----------------------------------------------------------------

    /**
     * Builds the standard SELECT with JOINs, filtering with the given WHERE clause.
     * Joins: requester name, provider name, skill name/category.
     */
    private String buildJoinedSql(String whereClause) {
        return """
            SELECT b.*,
                   s.name AS skill_name, s.category,
                   req.name AS requester_name,
                   prov.name AS provider_name
            FROM bookings b
            JOIN skills s       ON b.skill_id      = s.skill_id
            JOIN users  req     ON b.requester_id  = req.user_id
            JOIN users  prov    ON b.provider_id   = prov.user_id
            WHERE
            """ + whereClause;
    }

    private List<SessionBooking> executeAndMap(PreparedStatement ps) throws SQLException {
        List<SessionBooking> list = new ArrayList<>();
        try (ResultSet rs = ps.executeQuery()) {
            while (rs.next()) list.add(mapRow(rs));
        }
        return list;
    }

    /** Maps a ResultSet row to a SessionBooking. */
    private SessionBooking mapRow(ResultSet rs) throws SQLException {
        Skill skill = new Skill(
            rs.getInt   ("skill_id"),
            rs.getString("skill_name"),
            rs.getString("category")
        );
        SessionBooking booking = new SessionBooking(
            rs.getInt   ("booking_id"),
            rs.getInt   ("requester_id"),
            rs.getInt   ("provider_id"),
            skill,
            LocalDate.parse(rs.getString("session_date")),
            LocalTime.parse(rs.getString("session_time")),
            rs.getInt   ("duration_minutes"),
            BookingStatus.valueOf(rs.getString("status")),
            rs.getString("cancel_reason")
        );
        booking.setRequesterName(rs.getString("requester_name"));
        booking.setProviderName (rs.getString("provider_name"));
        return booking;
    }
}
