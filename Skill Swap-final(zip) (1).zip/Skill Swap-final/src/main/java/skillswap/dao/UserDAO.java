package skillswap.dao;

import skillswap.model.Administrator;
import skillswap.model.Student;
import skillswap.model.User;
import skillswap.util.DatabaseException;
import skillswap.util.DatabaseManager;

import org.sqlite.SQLiteException;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

/**
 * OOP CONCEPT: Data Access Object (DAO) pattern.
 * Completely isolates all SQL from the service and UI layers.
 * Uses PreparedStatements only — prevents SQL injection.
 * Uses try-with-resources — prevents connection/statement leaks.
 */
public class UserDAO {

    private final DatabaseManager db = DatabaseManager.getInstance();

    // ----------------------------------------------------------------
    // CREATE
    // ----------------------------------------------------------------

    /**
     * Inserts a new user and returns the generated user_id.
     *
     * @throws DatabaseException if a DB error occurs (including duplicate email)
     */
    public int insertUser(User user, String bio, int creditBalance) {
        String sql = """
            INSERT INTO users
              (name, email, password_hash, role, department, year_of_study, bio, credit_balance, access_level)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
            """;

        // try-with-resources — OOP CONCEPT: automatic resource management
        try (PreparedStatement ps = db.getConnection().prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {

            ps.setString(1, user.getName());
            ps.setString(2, user.getEmail());
            ps.setString(3, user.getPasswordHash());
            ps.setString(4, user.getRole());
            ps.setString(5, user.getDepartment());
            ps.setInt   (6, user.getYearOfStudy());
            ps.setString(7, bio);
            ps.setInt   (8, creditBalance);
            ps.setInt   (9, user instanceof Administrator a ? a.getAccessLevel() : 1);

            ps.executeUpdate();

            try (ResultSet keys = ps.getGeneratedKeys()) {
                if (keys.next()) return keys.getInt(1);
            }
            throw new DatabaseException("Insert succeeded but no generated key returned.");

        } catch (SQLiteException e) {
            // SQLite error code 19 = SQLITE_CONSTRAINT (unique violation)
            if (e.getMessage() != null && e.getMessage().contains("UNIQUE")) {
                throw new DatabaseException("Email already registered: " + user.getEmail());
            }
            throw new DatabaseException("Failed to insert user.", e);
        } catch (SQLException e) {
            if (e.getMessage() != null && e.getMessage().contains("UNIQUE")) {
                throw new DatabaseException("Email already registered: " + user.getEmail());
            }
            throw new DatabaseException("Failed to insert user.", e);
        }
    }

    // ----------------------------------------------------------------
    // READ
    // ----------------------------------------------------------------

    /** Finds a user by their email address (for login). */
    public Optional<User> findByEmail(String email) {
        String sql = "SELECT * FROM users WHERE email = ?";
        try (PreparedStatement ps = db.getConnection().prepareStatement(sql)) {

            ps.setString(1, email.toLowerCase().trim());
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) return Optional.of(mapRow(rs));
            }
        } catch (SQLException e) {
            throw new DatabaseException("Failed to find user by email.", e);
        }
        return Optional.empty();
    }

    /** Finds a user by their primary key. */
    public Optional<User> findById(int userId) {
        String sql = "SELECT * FROM users WHERE user_id = ?";
        try (PreparedStatement ps = db.getConnection().prepareStatement(sql)) {

            ps.setInt(1, userId);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) return Optional.of(mapRow(rs));
            }
        } catch (SQLException e) {
            throw new DatabaseException("Failed to find user by id.", e);
        }
        return Optional.empty();
    }

    /** Returns all users (admin use). */
    public List<User> findAll() {
        List<User> users = new ArrayList<>();
        String sql = "SELECT * FROM users ORDER BY name";
        try (PreparedStatement ps = db.getConnection().prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) users.add(mapRow(rs));

        } catch (SQLException e) {
            throw new DatabaseException("Failed to load users.", e);
        }
        return users;
    }

    /** Returns all students (used by MatchingService). */
    public List<Student> findAllStudents() {
        List<Student> students = new ArrayList<>();
        String sql = "SELECT * FROM users WHERE role = 'STUDENT' ORDER BY name";
        try (PreparedStatement ps = db.getConnection().prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) students.add(mapStudent(rs));

        } catch (SQLException e) {
            throw new DatabaseException("Failed to load students.", e);
        }
        return students;
    }

    /** Returns true if any user row has the given email. */
    public boolean emailExists(String email) {
        String sql = "SELECT COUNT(*) FROM users WHERE email = ?";
        try (PreparedStatement ps = db.getConnection().prepareStatement(sql)) {

            ps.setString(1, email.toLowerCase().trim());
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next() && rs.getInt(1) > 0;
            }
        } catch (SQLException e) {
            throw new DatabaseException("Failed to check email existence.", e);
        }
    }

    // ----------------------------------------------------------------
    // UPDATE
    // ----------------------------------------------------------------

    /** Updates mutable profile fields. */
    public void updateProfile(int userId, String name, String department,
                               int yearOfStudy, String bio) {
        String sql = """
            UPDATE users
            SET name = ?, department = ?, year_of_study = ?, bio = ?
            WHERE user_id = ?
            """;
        try (PreparedStatement ps = db.getConnection().prepareStatement(sql)) {

            ps.setString(1, name);
            ps.setString(2, department);
            ps.setInt   (3, yearOfStudy);
            ps.setString(4, bio);
            ps.setInt   (5, userId);
            ps.executeUpdate();

        } catch (SQLException e) {
            throw new DatabaseException("Failed to update user profile.", e);
        }
    }

    /** Updates the stored password hash (e.g., after a password change). */
    public void updatePasswordHash(int userId, String newHash) {
        String sql = "UPDATE users SET password_hash = ? WHERE user_id = ?";
        try (PreparedStatement ps = db.getConnection().prepareStatement(sql)) {

            ps.setString(1, newHash);
            ps.setInt   (2, userId);
            ps.executeUpdate();

        } catch (SQLException e) {
            throw new DatabaseException("Failed to update password.", e);
        }
    }

    /** Updates the credit balance directly (called by CreditService). */
    public void updateCreditBalance(int userId, int newBalance) {
        String sql = "UPDATE users SET credit_balance = ? WHERE user_id = ?";
        try (PreparedStatement ps = db.getConnection().prepareStatement(sql)) {

            ps.setInt(1, newBalance);
            ps.setInt(2, userId);
            ps.executeUpdate();

        } catch (SQLException e) {
            throw new DatabaseException("Failed to update credit balance.", e);
        }
    }

    // ----------------------------------------------------------------
    // DELETE
    // ----------------------------------------------------------------

    /** Deletes a user account (admin only). Cascades to listings, bookings. */
    public void deleteUser(int userId) {
        String sql = "DELETE FROM users WHERE user_id = ?";
        try (PreparedStatement ps = db.getConnection().prepareStatement(sql)) {

            ps.setInt(1, userId);
            ps.executeUpdate();

        } catch (SQLException e) {
            throw new DatabaseException("Failed to delete user.", e);
        }
    }

    // ----------------------------------------------------------------
    // Row mappers — OOP: private helpers keep mapping in one place
    // ----------------------------------------------------------------

    /**
     * Maps a ResultSet row to either a Student or Administrator
     * depending on the 'role' column.
     * OOP CONCEPT: Polymorphism — returns the abstract User type,
     * but the actual object is the correct subclass.
     */
    private User mapRow(ResultSet rs) throws SQLException {
        String role = rs.getString("role");
        if ("ADMIN".equals(role)) {
            return mapAdmin(rs);
        }
        return mapStudent(rs);
    }

    private Student mapStudent(ResultSet rs) throws SQLException {
        return new Student(
            rs.getInt   ("user_id"),
            rs.getString("name"),
            rs.getString("email"),
            rs.getString("password_hash"),
            rs.getString("department"),
            rs.getInt   ("year_of_study"),
            rs.getString("bio"),
            rs.getInt   ("credit_balance")
        );
    }

    private Administrator mapAdmin(ResultSet rs) throws SQLException {
        return new Administrator(
            rs.getInt   ("user_id"),
            rs.getString("name"),
            rs.getString("email"),
            rs.getString("password_hash"),
            rs.getString("department"),
            rs.getInt   ("year_of_study"),
            rs.getInt   ("access_level")
        );
    }
}
