package skillswap.dao;

import skillswap.model.Skill;
import skillswap.model.SkillListing;
import skillswap.model.SkillListing.ListingType;
import skillswap.model.SkillListing.Proficiency;
import skillswap.util.DatabaseException;
import skillswap.util.DatabaseManager;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

/**
 * DAO for the 'skills' and 'skill_listings' tables.
 * PreparedStatements only — no string concatenation in SQL.
 */
public class SkillDAO {

    private final DatabaseManager db = DatabaseManager.getInstance();

    // ================================================================
    // SKILLS (master catalogue)
    // ================================================================

    /** Returns the full skills catalogue, sorted by category then name. */
    public List<Skill> findAllSkills() {
        List<Skill> list = new ArrayList<>();
        String sql = "SELECT * FROM skills ORDER BY category, name";
        try (PreparedStatement ps = db.getConnection().prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) list.add(mapSkill(rs));

        } catch (SQLException e) {
            throw new DatabaseException("Failed to load skills.", e);
        }
        return list;
    }

    /** Finds a skill by name (case-insensitive). */
    public Optional<Skill> findSkillByName(String name) {
        String sql = "SELECT * FROM skills WHERE LOWER(name) = LOWER(?)";
        try (PreparedStatement ps = db.getConnection().prepareStatement(sql)) {

            ps.setString(1, name.trim());
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) return Optional.of(mapSkill(rs));
            }
        } catch (SQLException e) {
            throw new DatabaseException("Failed to find skill by name.", e);
        }
        return Optional.empty();
    }

    /** Finds a skill by ID. */
    public Optional<Skill> findSkillById(int skillId) {
        String sql = "SELECT * FROM skills WHERE skill_id = ?";
        try (PreparedStatement ps = db.getConnection().prepareStatement(sql)) {

            ps.setInt(1, skillId);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) return Optional.of(mapSkill(rs));
            }
        } catch (SQLException e) {
            throw new DatabaseException("Failed to find skill by id.", e);
        }
        return Optional.empty();
    }

    /** Inserts a new skill into the master catalogue and returns its ID. */
    public int insertSkill(Skill skill) {
        String sql = "INSERT INTO skills (name, category) VALUES (?, ?)";
        try (PreparedStatement ps = db.getConnection().prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {

            ps.setString(1, skill.getName());
            ps.setString(2, skill.getCategory());
            ps.executeUpdate();

            try (ResultSet keys = ps.getGeneratedKeys()) {
                if (keys.next()) return keys.getInt(1);
            }
        } catch (SQLException e) {
            throw new DatabaseException("Failed to insert skill.", e);
        }
        throw new DatabaseException("Skill insert returned no generated key.");
    }

    // ================================================================
    // SKILL LISTINGS
    // ================================================================

    /**
     * Returns all listings (OFFER + WANT) for a given student,
     * joining with the skills table so Skill objects are fully populated.
     */
    public List<SkillListing> findListingsByUser(int userId) {
        List<SkillListing> list = new ArrayList<>();
        String sql = """
            SELECT sl.*, s.name AS skill_name, s.category
            FROM skill_listings sl
            JOIN skills s ON sl.skill_id = s.skill_id
            WHERE sl.user_id = ?
            ORDER BY sl.listing_type, s.name
            """;
        try (PreparedStatement ps = db.getConnection().prepareStatement(sql)) {

            ps.setInt(1, userId);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) list.add(mapListing(rs));
            }
        } catch (SQLException e) {
            throw new DatabaseException("Failed to load skill listings.", e);
        }
        return list;
    }

    /** Returns only OFFER listings for a user. */
    public List<SkillListing> findOfferedByUser(int userId) {
        return findListingsByUserAndType(userId, "OFFER");
    }

    /** Returns only WANT listings for a user. */
    public List<SkillListing> findWantedByUser(int userId) {
        return findListingsByUserAndType(userId, "WANT");
    }

    private List<SkillListing> findListingsByUserAndType(int userId, String type) {
        List<SkillListing> list = new ArrayList<>();
        String sql = """
            SELECT sl.*, s.name AS skill_name, s.category
            FROM skill_listings sl
            JOIN skills s ON sl.skill_id = s.skill_id
            WHERE sl.user_id = ? AND sl.listing_type = ?
            ORDER BY s.name
            """;
        try (PreparedStatement ps = db.getConnection().prepareStatement(sql)) {

            ps.setInt   (1, userId);
            ps.setString(2, type);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) list.add(mapListing(rs));
            }
        } catch (SQLException e) {
            throw new DatabaseException("Failed to load skill listings.", e);
        }
        return list;
    }

    /** Returns all OFFER listings across all students (for matching). */
    public List<SkillListing> findAllOfferListings() {
        List<SkillListing> list = new ArrayList<>();
        String sql = """
            SELECT sl.*, s.name AS skill_name, s.category
            FROM skill_listings sl
            JOIN skills s ON sl.skill_id = s.skill_id
            WHERE sl.listing_type = 'OFFER'
            """;
        try (PreparedStatement ps = db.getConnection().prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) list.add(mapListing(rs));

        } catch (SQLException e) {
            throw new DatabaseException("Failed to load offer listings.", e);
        }
        return list;
    }

    /** Inserts a new listing and returns its generated ID. */
    public int insertListing(SkillListing listing) {
        String sql = """
            INSERT INTO skill_listings
              (user_id, skill_id, listing_type, proficiency, description)
            VALUES (?, ?, ?, ?, ?)
            """;
        try (PreparedStatement ps = db.getConnection().prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {

            ps.setInt   (1, listing.getUserId());
            ps.setInt   (2, listing.getSkill().getSkillId());
            ps.setString(3, listing.getListingType().name());
            ps.setString(4, listing.getProficiency().name());
            ps.setString(5, listing.getDescription());
            ps.executeUpdate();

            try (ResultSet keys = ps.getGeneratedKeys()) {
                if (keys.next()) return keys.getInt(1);
            }
        } catch (SQLException e) {
            if (e.getMessage() != null && e.getMessage().contains("UNIQUE")) {
                throw new DatabaseException(
                    "You already have a " + listing.getListingType() +
                    " listing for " + listing.getSkill().getName() + ".");
            }
            throw new DatabaseException("Failed to insert skill listing.", e);
        }
        throw new DatabaseException("Listing insert returned no generated key.");
    }

    /** Updates proficiency and description for an existing listing. */
    public void updateListing(int listingId, Proficiency proficiency, String description) {
        String sql = "UPDATE skill_listings SET proficiency = ?, description = ? WHERE listing_id = ?";
        try (PreparedStatement ps = db.getConnection().prepareStatement(sql)) {

            ps.setString(1, proficiency.name());
            ps.setString(2, description);
            ps.setInt   (3, listingId);
            ps.executeUpdate();

        } catch (SQLException e) {
            throw new DatabaseException("Failed to update skill listing.", e);
        }
    }

    /** Deletes a listing by ID. */
    public void deleteListing(int listingId) {
        String sql = "DELETE FROM skill_listings WHERE listing_id = ?";
        try (PreparedStatement ps = db.getConnection().prepareStatement(sql)) {

            ps.setInt(1, listingId);
            ps.executeUpdate();

        } catch (SQLException e) {
            throw new DatabaseException("Failed to delete skill listing.", e);
        }
    }

    // ----------------------------------------------------------------
    // Row mappers
    // ----------------------------------------------------------------

    private Skill mapSkill(ResultSet rs) throws SQLException {
        return new Skill(
            rs.getInt   ("skill_id"),
            rs.getString("name"),
            rs.getString("category")
        );
    }

    private SkillListing mapListing(ResultSet rs) throws SQLException {
        Skill skill = new Skill(
            rs.getInt   ("skill_id"),
            rs.getString("skill_name"),
            rs.getString("category")
        );
        return new SkillListing(
            rs.getInt   ("listing_id"),
            rs.getInt   ("user_id"),
            skill,
            ListingType.valueOf(rs.getString("listing_type")),
            Proficiency.valueOf(rs.getString("proficiency")),
            rs.getString("description")
        );
    }
}
