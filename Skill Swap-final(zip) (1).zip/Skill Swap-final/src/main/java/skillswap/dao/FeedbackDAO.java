package skillswap.dao;

import skillswap.model.Feedback;
import skillswap.util.DatabaseException;
import skillswap.util.DatabaseManager;

import java.sql.*;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

/**
 * DAO for the 'feedback' table.
 * The UNIQUE(booking_id, reviewer_id) constraint prevents duplicate reviews.
 */
public class FeedbackDAO {

    private final DatabaseManager db = DatabaseManager.getInstance();

    // ----------------------------------------------------------------
    // CREATE
    // ----------------------------------------------------------------

    /** Inserts a feedback row and returns the generated ID. */
    public int insertFeedback(Feedback fb) {
        String sql = """
            INSERT INTO feedback (booking_id, reviewer_id, reviewee_id, rating, comment)
            VALUES (?, ?, ?, ?, ?)
            """;
        try (PreparedStatement ps = db.getConnection().prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {

            ps.setInt   (1, fb.getBookingId());
            ps.setInt   (2, fb.getReviewerId());
            ps.setInt   (3, fb.getRevieweeId());
            ps.setInt   (4, fb.getRating());
            ps.setString(5, fb.getComment());
            ps.executeUpdate();

            try (ResultSet keys = ps.getGeneratedKeys()) {
                if (keys.next()) return keys.getInt(1);
            }
        } catch (SQLException e) {
            if (e.getMessage() != null && e.getMessage().contains("UNIQUE")) {
                throw new DatabaseException("You have already reviewed this session.");
            }
            throw new DatabaseException("Failed to insert feedback.", e);
        }
        throw new DatabaseException("Feedback insert returned no generated key.");
    }

    // ----------------------------------------------------------------
    // READ
    // ----------------------------------------------------------------

    /** Finds feedback for a specific booking by a specific reviewer. */
    public Optional<Feedback> findByBookingAndReviewer(int bookingId, int reviewerId) {
        String sql = """
            SELECT f.*, rev.name AS reviewer_name, rvw.name AS reviewee_name
            FROM feedback f
            JOIN users rev ON f.reviewer_id = rev.user_id
            JOIN users rvw ON f.reviewee_id = rvw.user_id
            WHERE f.booking_id = ? AND f.reviewer_id = ?
            """;
        try (PreparedStatement ps = db.getConnection().prepareStatement(sql)) {

            ps.setInt(1, bookingId);
            ps.setInt(2, reviewerId);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) return Optional.of(mapRow(rs));
            }
        } catch (SQLException e) {
            throw new DatabaseException("Failed to find feedback.", e);
        }
        return Optional.empty();
    }

    /** Returns all feedback received by a user (they are the reviewee). */
    public List<Feedback> findReceivedByUser(int userId) {
        List<Feedback> list = new ArrayList<>();
        String sql = """
            SELECT f.*, rev.name AS reviewer_name, rvw.name AS reviewee_name
            FROM feedback f
            JOIN users rev ON f.reviewer_id = rev.user_id
            JOIN users rvw ON f.reviewee_id = rvw.user_id
            WHERE f.reviewee_id = ?
            ORDER BY f.created_at DESC
            """;
        try (PreparedStatement ps = db.getConnection().prepareStatement(sql)) {

            ps.setInt(1, userId);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) list.add(mapRow(rs));
            }
        } catch (SQLException e) {
            throw new DatabaseException("Failed to load received feedback.", e);
        }
        return list;
    }

    /** Returns all feedback given by a user (they are the reviewer). */
    public List<Feedback> findGivenByUser(int userId) {
        List<Feedback> list = new ArrayList<>();
        String sql = """
            SELECT f.*, rev.name AS reviewer_name, rvw.name AS reviewee_name
            FROM feedback f
            JOIN users rev ON f.reviewer_id = rev.user_id
            JOIN users rvw ON f.reviewee_id = rvw.user_id
            WHERE f.reviewer_id = ?
            ORDER BY f.created_at DESC
            """;
        try (PreparedStatement ps = db.getConnection().prepareStatement(sql)) {

            ps.setInt(1, userId);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) list.add(mapRow(rs));
            }
        } catch (SQLException e) {
            throw new DatabaseException("Failed to load given feedback.", e);
        }
        return list;
    }

    /** Computes the average rating for a user as a reviewee (0.0 if none). */
    public double getAverageRating(int userId) {
        String sql = "SELECT AVG(rating) FROM feedback WHERE reviewee_id = ?";
        try (PreparedStatement ps = db.getConnection().prepareStatement(sql)) {

            ps.setInt(1, userId);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    double avg = rs.getDouble(1);
                    return rs.wasNull() ? 0.0 : avg;
                }
            }
        } catch (SQLException e) {
            throw new DatabaseException("Failed to compute average rating.", e);
        }
        return 0.0;
    }

    /** Returns true if the reviewer has already reviewed this booking. */
    public boolean hasReviewed(int bookingId, int reviewerId) {
        return findByBookingAndReviewer(bookingId, reviewerId).isPresent();
    }

    /** Deletes a feedback entry (admin moderation). */
    public void deleteFeedback(int feedbackId) {
        String sql = "DELETE FROM feedback WHERE feedback_id = ?";
        try (PreparedStatement ps = db.getConnection().prepareStatement(sql)) {

            ps.setInt(1, feedbackId);
            ps.executeUpdate();

        } catch (SQLException e) {
            throw new DatabaseException("Failed to delete feedback.", e);
        }
    }

    // ----------------------------------------------------------------
    // Row mapper
    // ----------------------------------------------------------------

    private Feedback mapRow(ResultSet rs) throws SQLException {
        String tsStr = rs.getString("created_at");
        LocalDateTime createdAt = tsStr != null
            ? LocalDateTime.parse(tsStr.replace(" ", "T"))
            : LocalDateTime.now();

        Feedback fb = new Feedback(
            rs.getInt   ("feedback_id"),
            rs.getInt   ("booking_id"),
            rs.getInt   ("reviewer_id"),
            rs.getInt   ("reviewee_id"),
            rs.getInt   ("rating"),
            rs.getString("comment"),
            createdAt
        );
        fb.setReviewerName(rs.getString("reviewer_name"));
        fb.setRevieweeName(rs.getString("reviewee_name"));
        return fb;
    }
}
