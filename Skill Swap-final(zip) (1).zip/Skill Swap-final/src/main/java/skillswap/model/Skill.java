package skillswap.model;

/**
 * OOP CONCEPT: Encapsulation — all fields private, accessed via getters/setters.
 *
 * Represents a skill in the master catalogue (e.g., Python, Photoshop).
 * Skills are shared across the platform; individual listings reference them.
 */
public class Skill {

    // --- private fields (Encapsulation) ---
    private int skillId;
    private String name;
    private String category;

    // --- Constructors ---

    /** Full constructor (used when loading from DB). */
    public Skill(int skillId, String name, String category) {
        this.skillId  = skillId;
        this.setName(name);
        this.setCategory(category);
    }

    /** Partial constructor (used when creating a new skill before DB insert). */
    public Skill(String name, String category) {
        this(0, name, category);
    }

    // --- Validated setters (Encapsulation with validation) ---

    public void setName(String name) {
        if (name == null || name.isBlank()) {
            throw new IllegalArgumentException("Skill name cannot be empty.");
        }
        if (name.length() > 100) {
            throw new IllegalArgumentException("Skill name must be 100 characters or fewer.");
        }
        this.name = name.trim();
    }

    public void setCategory(String category) {
        if (category == null || category.isBlank()) {
            throw new IllegalArgumentException("Skill category cannot be empty.");
        }
        this.category = category.trim();
    }

    public void setSkillId(int skillId) {
        this.skillId = skillId;
    }

    // --- Getters ---

    public int    getSkillId()  { return skillId;  }
    public String getName()     { return name;     }
    public String getCategory() { return category; }

    @Override
    public String toString() {
        // Shown in JComboBox and lists
        return name + " (" + category + ")";
    }
}
