package skillswap.model;

import skillswap.util.InvalidRatingException;

/**
 * OOP CONCEPT: Interface — contract for any entity that can be rated.
 * Implemented by SessionBooking (once completed).
 *
 * Interfaces define "what" without "how", supporting polymorphism.
 */
public interface Rateable {

    /**
     * Submit a rating for this entity.
     *
     * @param rating  integer from 1 (poor) to 5 (excellent)
     * @param comment optional written feedback
     * @throws InvalidRatingException if rating is out of range or conditions not met
     */
    void submitRating(int rating, String comment) throws InvalidRatingException;

    /**
     * @return the average rating, or 0.0 if no ratings exist yet.
     */
    double getAverageRating();
}
