package skillswap.model;

import java.time.LocalDateTime;

/**
 * OOP CONCEPT: Encapsulation — immutable value object (no setters).
 * Represents a credit award event tied to a completed teaching session.
 */
public class CreditTransaction {

    // All fields are final — CreditTransaction is effectively immutable
    private final int           txId;
    private final int           userId;
    private final int           bookingId;   // -1 if not linked to a booking
    private final int           amount;
    private final String        reason;
    private final LocalDateTime createdAt;

    public CreditTransaction(int txId, int userId, int bookingId,
                              int amount, String reason, LocalDateTime createdAt) {
        this.txId      = txId;
        this.userId    = userId;
        this.bookingId = bookingId;
        this.amount    = amount;
        this.reason    = reason;
        this.createdAt = createdAt;
    }

    // Getters only — no setters (immutability)
    public int           getTxId()      { return txId;      }
    public int           getUserId()    { return userId;    }
    public int           getBookingId() { return bookingId; }
    public int           getAmount()    { return amount;    }
    public String        getReason()    { return reason;    }
    public LocalDateTime getCreatedAt() { return createdAt; }
}
