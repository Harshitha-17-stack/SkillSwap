package skillswap.model;

/**
 * OOP CONCEPT: Enum — type-safe representation of booking lifecycle states.
 *
 * Valid transitions:
 *   REQUESTED  → CONFIRMED  (provider accepts)
 *   CONFIRMED  → COMPLETED  (session took place)
 *   REQUESTED  → CANCELLED  (either party cancels before confirmation)
 *   CONFIRMED  → CANCELLED  (either party cancels before completion)
 *
 * Terminal states: COMPLETED, CANCELLED (no further transitions allowed).
 */
public enum BookingStatus {
    REQUESTED,
    CONFIRMED,
    COMPLETED,
    CANCELLED;

    /**
     * Returns true if transitioning from this status to `next` is allowed.
     * OOP: encapsulates transition logic inside the enum itself.
     */
    public boolean canTransitionTo(BookingStatus next) {
        return switch (this) {
            case REQUESTED -> next == CONFIRMED || next == CANCELLED;
            case CONFIRMED -> next == COMPLETED || next == CANCELLED;
            // Terminal states: no further transitions
            case COMPLETED, CANCELLED -> false;
        };
    }

    /** Human-readable label used in the UI. */
    public String getLabel() {
        return switch (this) {
            case REQUESTED  -> "Pending";
            case CONFIRMED  -> "Confirmed";
            case COMPLETED  -> "Completed";
            case CANCELLED  -> "Cancelled";
        };
    }
}
