package skillswap.model;

import skillswap.util.InvalidBookingException;

/**
 * OOP CONCEPT: Interface — contract for any entity that can be cancelled.
 * Implemented by SessionBooking.
 *
 * Demonstrates interface-based design: the UI/service layer can treat
 * any Cancellable the same way without knowing the concrete type.
 */
public interface Cancellable {

    /**
     * Cancel this entity with an optional reason.
     *
     * @param reason description of why the entity is being cancelled
     * @throws InvalidBookingException if the current state does not allow cancellation
     */
    void cancel(String reason) throws InvalidBookingException;

    /**
     * @return true if this entity has already been cancelled.
     */
    boolean isCancelled();
}
