package skillswap.model;

/**
 * OOP CONCEPT: Abstract Class — cannot be instantiated directly.
 *
 * Defines the shared state and behaviour for ALL users (Students and Admins).
 * Abstract method displayDashboard() forces every subclass to provide
 * its own dashboard implementation (polymorphism).
 *
 * Encapsulation: all fields private, accessed only through validated setters.
 */
public abstract class User {

    // ----------------------------------------------------------------
    // Private fields — Encapsulation
    // ----------------------------------------------------------------
    private int    userId;
    private String name;
    private String email;
    private String passwordHash;   // BCrypt hash — never plain text
    private String department;
    private int    yearOfStudy;
    private String role;           // "STUDENT" or "ADMIN"

    // Session state (not persisted in DB)
    private boolean loggedIn = false;

    // ----------------------------------------------------------------
    // Constructor
    // ----------------------------------------------------------------
    protected User(int userId, String name, String email,
                   String passwordHash, String department,
                   int yearOfStudy, String role) {
        this.userId       = userId;
        this.setName(name);
        this.setEmail(email);
        this.passwordHash = passwordHash;
        this.department   = department;
        this.yearOfStudy  = yearOfStudy;
        this.role         = role;
    }

    // ----------------------------------------------------------------
    // Concrete methods — shared behaviour for all subclasses
    // ----------------------------------------------------------------

    /**
     * Marks the user as logged in.
     * OOP: concrete method inherited by Student and Administrator.
     */
    public void login() {
        this.loggedIn = true;
        System.out.println("[Auth] " + name + " logged in.");
    }

    /**
     * Marks the user as logged out and clears any session state.
     */
    public void logout() {
        this.loggedIn = false;
        System.out.println("[Auth] " + name + " logged out.");
    }

    /**
     * Updates mutable profile fields.
     * Subclasses may override to update additional fields.
     * OOP: method overriding demonstrated in Student.
     */
    public void updateProfile(String name, String department, int yearOfStudy) {
        this.setName(name);
        this.department = department;
        this.yearOfStudy = yearOfStudy;
    }

    // ----------------------------------------------------------------
    // Abstract method — MUST be overridden by each subclass
    // OOP CONCEPT: Abstract method / Polymorphism
    // ----------------------------------------------------------------
    /**
     * Each user type shows a different dashboard.
     * The UI calls this polymorphically without knowing the concrete type.
     */
    public abstract void displayDashboard();

    // ----------------------------------------------------------------
    // Validated setters — Encapsulation
    // ----------------------------------------------------------------

    public void setName(String name) {
        if (name == null || name.isBlank()) {
            throw new IllegalArgumentException("Name cannot be empty.");
        }
        if (name.length() > 150) {
            throw new IllegalArgumentException("Name is too long (max 150 chars).");
        }
        this.name = name.trim();
    }

    public void setEmail(String email) {
        if (email == null || !email.matches("^[\\w._%+\\-]+@[\\w.\\-]+\\.[a-zA-Z]{2,}$")) {
            throw new IllegalArgumentException("Invalid email address: " + email);
        }
        this.email = email.toLowerCase().trim();
    }

    public void setPasswordHash(String passwordHash) {
        if (passwordHash == null || passwordHash.isBlank()) {
            throw new IllegalArgumentException("Password hash cannot be empty.");
        }
        this.passwordHash = passwordHash;
    }

    public void setDepartment(String department) {
        this.department = department;
    }

    public void setYearOfStudy(int yearOfStudy) {
        if (yearOfStudy < 0 || yearOfStudy > 10) {
            throw new IllegalArgumentException("Year of study must be between 0 and 10.");
        }
        this.yearOfStudy = yearOfStudy;
    }

    // ----------------------------------------------------------------
    // Getters
    // ----------------------------------------------------------------
    public int    getUserId()      { return userId;       }
    public String getName()        { return name;         }
    public String getEmail()       { return email;        }
    public String getPasswordHash(){ return passwordHash; }
    public String getDepartment()  { return department;   }
    public int    getYearOfStudy() { return yearOfStudy;  }
    public String getRole()        { return role;         }
    public boolean isLoggedIn()    { return loggedIn;     }

    /** Returns initials for the avatar circle in the UI. */
    public String getInitials() {
        if (name == null || name.isBlank()) return "?";
        String[] parts = name.trim().split("\\s+");
        if (parts.length == 1) return parts[0].substring(0, 1).toUpperCase();
        return (parts[0].substring(0, 1) + parts[parts.length - 1].substring(0, 1)).toUpperCase();
    }

    @Override
    public String toString() {
        return name + " <" + email + ">";
    }
}
