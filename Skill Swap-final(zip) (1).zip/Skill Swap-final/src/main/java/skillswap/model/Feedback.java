package skillswap.model;

import java.time.LocalDateTime;

/**
 * OOP CONCEPT: Encapsulation — immutable value object.
 * Represents a rating + comment left by one student for another
 * after a completed session.
 */
public class Feedback {

    private final int           feedbackId;
    private final int           bookingId;
    private final int           reviewerId;
    private final int           revieweeId;
    private final int           rating;       // 1–5
    private final String        comment;
    private final LocalDateTime createdAt;

    // Reviewer/reviewee names — populated by DAO joins for display
    private String reviewerName;
    private String revieweeName;

    public Feedback(int feedbackId, int bookingId, int reviewerId, int revieweeId,
                    int rating, String comment, LocalDateTime createdAt) {
        if (rating < 1 || rating > 5) {
            throw new IllegalArgumentException("Rating must be between 1 and 5.");
        }
        this.feedbackId = feedbackId;
        this.bookingId  = bookingId;
        this.reviewerId = reviewerId;
        this.revieweeId = revieweeId;
        this.rating     = rating;
        this.comment    = comment;
        this.createdAt  = createdAt;
    }

    // Mutable display-name fields (set after DB join)
    public void setReviewerName(String name) { this.reviewerName = name; }
    public void setRevieweeName(String name) { this.revieweeName = name; }

    // Getters
    public int           getFeedbackId()  { return feedbackId;  }
    public int           getBookingId()   { return bookingId;   }
    public int           getReviewerId()  { return reviewerId;  }
    public int           getRevieweeId()  { return revieweeId;  }
    public int           getRating()      { return rating;      }
    public String        getComment()     { return comment;     }
    public LocalDateTime getCreatedAt()   { return createdAt;   }
    public String        getReviewerName(){ return reviewerName;}
    public String        getRevieweeName(){ return revieweeName;}
}
