package skillswap.model;

import java.util.ArrayList;
import java.util.List;

/**
 * OOP CONCEPT: Inheritance — Student EXTENDS the abstract User class.
 *
 * Student adds domain-specific state:
 *   - bio, creditBalance
 *   - offeredSkills and wantedSkills (Collections — ArrayList)
 *
 * Student also OVERRIDES the abstract displayDashboard() method.
 * Additional methods demonstrate Student-specific behaviour.
 */
public class Student extends User {

    // ----------------------------------------------------------------
    // Student-specific private fields — Encapsulation
    // ----------------------------------------------------------------
    private String bio;
    private int    creditBalance;

    /**
     * OOP CONCEPT: Collections — ArrayList stores skill listings.
     * Association: Student HAS-A list of SkillListings.
     */
    private final List<SkillListing> offeredSkills = new ArrayList<>();
    private final List<SkillListing> wantedSkills  = new ArrayList<>();

    // ----------------------------------------------------------------
    // Constructor
    // ----------------------------------------------------------------
    public Student(int userId, String name, String email,
                   String passwordHash, String department,
                   int yearOfStudy, String bio, int creditBalance) {
        // Calls the parent (User) constructor — super()
        super(userId, name, email, passwordHash, department, yearOfStudy, "STUDENT");
        this.bio           = bio;
        this.creditBalance = creditBalance;
    }

    // ----------------------------------------------------------------
    // OOP CONCEPT: Method Overriding — required by abstract parent
    // ----------------------------------------------------------------
    @Override
    public void displayDashboard() {
        // In the real app the UI renders the dashboard panel;
        // this console output is here to satisfy the contract and for testing.
        System.out.println("=== Student Dashboard: " + getName() + " ===");
        System.out.println("Credits : " + creditBalance);
        System.out.println("Offering: " + offeredSkills.size() + " skill(s)");
        System.out.println("Wanting : " + wantedSkills.size()  + " skill(s)");
    }

    // ----------------------------------------------------------------
    // OOP CONCEPT: Method Overriding — extends parent updateProfile()
    // ----------------------------------------------------------------
    @Override
    public void updateProfile(String name, String department, int yearOfStudy) {
        super.updateProfile(name, department, yearOfStudy); // Calls parent version
        // Student-specific update handled via setBio()
    }

    // ----------------------------------------------------------------
    // Skill management methods
    // ----------------------------------------------------------------

    /**
     * Adds a skill listing to the appropriate list.
     * OOP CONCEPT: Encapsulation — external code never touches the ArrayList directly.
     */
    public void addSkill(SkillListing listing) {
        if (listing == null) throw new IllegalArgumentException("Listing cannot be null.");
        if (listing.getListingType() == SkillListing.ListingType.OFFER) {
            offeredSkills.add(listing);
        } else {
            wantedSkills.add(listing);
        }
    }

    /**
     * Removes a skill listing by its ID.
     */
    public boolean removeSkill(int listingId) {
        boolean removed = offeredSkills.removeIf(l -> l.getListingId() == listingId);
        if (!removed) {
            removed = wantedSkills.removeIf(l -> l.getListingId() == listingId);
        }
        return removed;
    }

    /**
     * Returns a view of currently active potential matches.
     * Actual matching logic lives in MatchingService (separation of concerns).
     * This method just prints — real navigation is done by the UI.
     */
    public void viewMatches() {
        System.out.println("[Student] Navigate to 'Find Matches' screen to see matches.");
    }

    /** View session history — navigates to Booking History screen in the UI. */
    public void viewSessionHistory() {
        System.out.println("[Student] Navigate to 'Booking History' screen.");
    }

    /** View credit balance and transaction history. */
    public void viewCredits() {
        System.out.println("[Student] Credits: " + creditBalance);
    }

    // ----------------------------------------------------------------
    // Credit management
    // ----------------------------------------------------------------

    /** Adds credits (e.g., after completing a teaching session). */
    public void addCredits(int amount) {
        if (amount <= 0) throw new IllegalArgumentException("Credit amount must be positive.");
        this.creditBalance += amount;
    }

    /** Deducts credits (future: spending credits feature). */
    public void deductCredits(int amount) {
        if (amount <= 0) throw new IllegalArgumentException("Amount must be positive.");
        if (amount > creditBalance) throw new IllegalArgumentException("Insufficient credits.");
        this.creditBalance -= amount;
    }

    // ----------------------------------------------------------------
    // Setters & Getters
    // ----------------------------------------------------------------

    public void setBio(String bio)               { this.bio = bio; }
    public void setCreditBalance(int balance)    { this.creditBalance = balance; }

    public String            getBio()            { return bio;           }
    public int               getCreditBalance()  { return creditBalance; }
    public List<SkillListing> getOfferedSkills() { return offeredSkills; }
    public List<SkillListing> getWantedSkills()  { return wantedSkills;  }
}
