package skillswap.model;

/**
 * OOP CONCEPT: Composition — a SkillListing HAS-A Skill.
 * Encapsulation — all fields private with validated setters.
 *
 * Represents one "I can teach X at level Y" or "I want to learn X" entry
 * for a specific student.
 */
public class SkillListing {

    /** Whether this listing is an offer to teach or a desire to learn. */
    public enum ListingType { OFFER, WANT }

    /** Proficiency levels for offered skills. */
    public enum Proficiency { BEGINNER, INTERMEDIATE, ADVANCED }

    // --- private fields ---
    private int         listingId;
    private int         userId;
    private Skill       skill;          // Composition: HAS-A Skill
    private ListingType listingType;
    private Proficiency proficiency;
    private String      description;

    // --- Constructors ---

    public SkillListing(int listingId, int userId, Skill skill,
                        ListingType listingType, Proficiency proficiency,
                        String description) {
        this.listingId   = listingId;
        this.userId      = userId;
        this.skill       = skill;
        this.listingType = listingType;
        this.proficiency = proficiency;
        this.description = description;
    }

    /** New listing before DB insert. */
    public SkillListing(int userId, Skill skill, ListingType listingType,
                        Proficiency proficiency, String description) {
        this(0, userId, skill, listingType, proficiency, description);
    }

    // --- Setters ---

    public void setListingId(int listingId)     { this.listingId   = listingId;   }
    public void setDescription(String desc)     { this.description = desc;        }
    public void setProficiency(Proficiency p)   { this.proficiency = p;           }

    // --- Getters ---

    public int         getListingId()   { return listingId;   }
    public int         getUserId()      { return userId;      }
    public Skill       getSkill()       { return skill;       }
    public ListingType getListingType() { return listingType; }
    public Proficiency getProficiency() { return proficiency; }
    public String      getDescription() { return description; }

    @Override
    public String toString() {
        return listingType + ": " + skill.getName() + " [" + proficiency + "]";
    }
}
