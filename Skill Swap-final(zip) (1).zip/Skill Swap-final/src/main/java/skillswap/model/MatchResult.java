package skillswap.model;

/**
 * OOP CONCEPT: Composition — a MatchResult HAS-A matched Student.
 * Value object returned by MatchingService.findMatches().
 *
 * Captures the "why" of a match so the UI can display a plain-English explanation.
 */
public class MatchResult {

    public enum MatchType {
        STRONG,   // Mutual: A teaches what B wants AND B teaches what A wants
        PARTIAL   // One-way: only one direction matches
    }

    // ----------------------------------------------------------------
    private final Student   matchedStudent;
    private final MatchType matchType;
    private final int       compatibilityScore; // 0–100
    private final String    explanation;        // Human-readable reason

    // The specific skills driving the match
    private final String    theyOffer;   // What the matched student offers (you want)
    private final String    youOffer;    // What you offer (they want) — may be null for PARTIAL

    // ----------------------------------------------------------------
    public MatchResult(Student matchedStudent, MatchType matchType,
                       int compatibilityScore, String explanation,
                       String theyOffer, String youOffer) {
        this.matchedStudent     = matchedStudent;
        this.matchType          = matchType;
        this.compatibilityScore = compatibilityScore;
        this.explanation        = explanation;
        this.theyOffer          = theyOffer;
        this.youOffer           = youOffer;
    }

    // Getters
    public Student   getMatchedStudent()     { return matchedStudent;     }
    public MatchType getMatchType()          { return matchType;          }
    public int       getCompatibilityScore() { return compatibilityScore; }
    public String    getExplanation()        { return explanation;        }
    public String    getTheyOffer()          { return theyOffer;          }
    public String    getYouOffer()           { return youOffer;           }

    @Override
    public String toString() {
        return matchType + " match with " + matchedStudent.getName()
             + " (" + compatibilityScore + "%) — " + explanation;
    }
}
