package skillswap.model;

import java.util.List;

/**
 * OOP CONCEPT: Inheritance — Administrator EXTENDS the abstract User class.
 *
 * Administrator has a higher accessLevel and extra management methods
 * not available to regular Students.
 *
 * Demonstrates:
 * - Inheritance (extends User)
 * - Method Overriding (displayDashboard)
 * - Polymorphism (UI can hold a User reference but call the right dashboard)
 */
public class Administrator extends User {

    // ----------------------------------------------------------------
    // Admin-specific private field — Encapsulation
    // ----------------------------------------------------------------
    private int accessLevel;  // e.g., 1 = moderator, 5 = super-admin

    // ----------------------------------------------------------------
    // Constructor
    // ----------------------------------------------------------------
    public Administrator(int userId, String name, String email,
                         String passwordHash, String department,
                         int yearOfStudy, int accessLevel) {
        super(userId, name, email, passwordHash, department, yearOfStudy, "ADMIN");
        this.setAccessLevel(accessLevel);
    }

    // ----------------------------------------------------------------
    // OOP CONCEPT: Method Overriding (mandatory abstract method)
    // ----------------------------------------------------------------
    @Override
    public void displayDashboard() {
        System.out.println("=== Admin Dashboard: " + getName() + " ===");
        System.out.println("Access Level: " + accessLevel);
        System.out.println("Role: Administrator");
    }

    // ----------------------------------------------------------------
    // Admin-specific business methods
    // ----------------------------------------------------------------

    /**
     * Placeholder for user management logic.
     * Actual implementation delegates to UserService in Phase 2.
     */
    public void manageUsers(List<User> users) {
        System.out.println("[Admin] Managing " + users.size() + " user(s).");
    }

    /**
     * Review reported content / flagged listings.
     * Real logic lives in AdminService (separation of concerns).
     */
    public void reviewReports() {
        System.out.println("[Admin] Reviewing reports...");
    }

    /**
     * Moderate or remove feedback that violates platform rules.
     */
    public void moderateFeedback(int feedbackId, String action) {
        System.out.println("[Admin] Feedback #" + feedbackId + " → " + action);
    }

    // ----------------------------------------------------------------
    // Setter with validation
    // ----------------------------------------------------------------

    public void setAccessLevel(int accessLevel) {
        if (accessLevel < 1 || accessLevel > 10) {
            throw new IllegalArgumentException("Access level must be between 1 and 10.");
        }
        this.accessLevel = accessLevel;
    }

    public int getAccessLevel() {
        return accessLevel;
    }
}
