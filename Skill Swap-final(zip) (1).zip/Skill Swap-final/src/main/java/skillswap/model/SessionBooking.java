package skillswap.model;

import skillswap.util.InvalidBookingException;
import skillswap.util.InvalidRatingException;

import java.time.LocalDate;
import java.time.LocalTime;

/**
 * OOP CONCEPT: Interface implementation — SessionBooking implements BOTH
 *   Rateable  (can be rated after completion)
 *   Cancellable (can be cancelled with a reason)
 *
 * Also demonstrates:
 * - Encapsulation: all fields private
 * - Association: HAS-A Skill, references two User IDs
 * - Enum usage: BookingStatus for type-safe state
 */
public class SessionBooking implements Rateable, Cancellable {

    // ----------------------------------------------------------------
    // Private fields — Encapsulation
    // ----------------------------------------------------------------
    private int           bookingId;
    private int           requesterId;  // The learner (student who booked)
    private int           providerId;   // The teacher
    private Skill         skill;        // Composition: HAS-A Skill
    private LocalDate     sessionDate;
    private LocalTime     sessionTime;
    private int           durationMinutes;
    private BookingStatus status;
    private String        cancelReason;

    // Display-only fields populated from DB joins
    private String requesterName;
    private String providerName;

    // Ratings cached after DB load (for Rateable implementation)
    private double averageRating = 0.0;

    // ----------------------------------------------------------------
    // Constructor
    // ----------------------------------------------------------------
    public SessionBooking(int bookingId, int requesterId, int providerId,
                          Skill skill, LocalDate sessionDate, LocalTime sessionTime,
                          int durationMinutes, BookingStatus status, String cancelReason) {
        this.bookingId       = bookingId;
        this.requesterId     = requesterId;
        this.providerId      = providerId;
        this.skill           = skill;
        this.sessionDate     = sessionDate;
        this.sessionTime     = sessionTime;
        this.durationMinutes = durationMinutes;
        this.status          = status;
        this.cancelReason    = cancelReason;
    }

    // ----------------------------------------------------------------
    // OOP CONCEPT: Rateable interface implementation
    // ----------------------------------------------------------------

    /**
     * Validates and records a rating for a completed session.
     * Actual DB persistence is done via FeedbackService.
     *
     * @throws InvalidRatingException if rating out of 1–5, or session not completed
     */
    @Override
    public void submitRating(int rating, String comment) throws InvalidRatingException {
        // Business rule: only completed sessions can be rated
        if (status != BookingStatus.COMPLETED) {
            throw new InvalidRatingException(
                "Cannot rate a session that is not COMPLETED. Current status: " + status);
        }
        // Business rule: rating must be 1–5
        if (rating < 1 || rating > 5) {
            throw new InvalidRatingException("Rating must be between 1 and 5, got: " + rating);
        }
        // Actual persistence done by FeedbackService; this validates the domain rule.
        System.out.println("[Rating] Session #" + bookingId + " rated " + rating + "/5");
    }

    @Override
    public double getAverageRating() {
        return averageRating;
    }

    // ----------------------------------------------------------------
    // OOP CONCEPT: Cancellable interface implementation
    // ----------------------------------------------------------------

    /**
     * Cancels the booking if the current status allows it.
     *
     * @throws InvalidBookingException if the session is already completed or cancelled
     */
    @Override
    public void cancel(String reason) throws InvalidBookingException {
        // Delegate to the enum's transition logic
        if (!status.canTransitionTo(BookingStatus.CANCELLED)) {
            throw new InvalidBookingException(
                "Cannot cancel a session with status: " + status.getLabel() +
                ". Only REQUESTED or CONFIRMED sessions can be cancelled.");
        }
        this.status       = BookingStatus.CANCELLED;
        this.cancelReason = reason;
    }

    @Override
    public boolean isCancelled() {
        return status == BookingStatus.CANCELLED;
    }

    // ----------------------------------------------------------------
    // Status transition helper
    // ----------------------------------------------------------------

    /**
     * Transitions to the given status if the transition is valid.
     * OOP: delegates rule-checking to BookingStatus enum.
     *
     * @throws InvalidBookingException if transition is not allowed
     */
    public void transitionTo(BookingStatus newStatus) throws InvalidBookingException {
        if (!status.canTransitionTo(newStatus)) {
            throw new InvalidBookingException(
                "Invalid transition: " + status.getLabel() + " → " + newStatus.getLabel());
        }
        this.status = newStatus;
    }

    // ----------------------------------------------------------------
    // Setters
    // ----------------------------------------------------------------
    public void setBookingId(int id)             { this.bookingId = id;           }
    public void setStatus(BookingStatus status)  { this.status = status;          }
    public void setCancelReason(String reason)   { this.cancelReason = reason;    }
    public void setRequesterName(String name)    { this.requesterName = name;     }
    public void setProviderName(String name)     { this.providerName = name;      }
    public void setAverageRating(double avg)     { this.averageRating = avg;      }

    // ----------------------------------------------------------------
    // Getters
    // ----------------------------------------------------------------
    public int           getBookingId()       { return bookingId;       }
    public int           getRequesterId()     { return requesterId;     }
    public int           getProviderId()      { return providerId;      }
    public Skill         getSkill()           { return skill;           }
    public LocalDate     getSessionDate()     { return sessionDate;     }
    public LocalTime     getSessionTime()     { return sessionTime;     }
    public int           getDurationMinutes() { return durationMinutes; }
    public BookingStatus getStatus()          { return status;          }
    public String        getCancelReason()    { return cancelReason;    }
    public String        getRequesterName()   { return requesterName;   }
    public String        getProviderName()    { return providerName;    }

    @Override
    public String toString() {
        return "Booking #" + bookingId + " [" + status.getLabel() + "] "
             + skill.getName() + " on " + sessionDate + " " + sessionTime;
    }
}
